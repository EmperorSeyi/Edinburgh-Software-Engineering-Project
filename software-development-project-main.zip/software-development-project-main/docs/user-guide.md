# Scotch Broth Prototype User Guide

> This document contains the complete user guide for the Scotch Broth prototype app. It covers multi-platform prerequisites check and installation, story creation example, step-by-step instructions, full list of available commands with detailed explanations, troubleshooting, use tips and data privacy policy. Also, it is written for both tech fans and non tech-savvy end users.


**Purpose: To create an interactive character timeline web page, with happiness and fun!**

----

## Table of Contents 

#### To Set UP:

- [Prerequisites and Installation](#1-prerequisites-and-installation)
- [Accessing the Scotch Broth Prototype App](#2-accessing-the-scotch-broth-prototype-app)

#### Start Your Creation:

- [Quick Start!](#i-quick-start)
- [Step by Step Instructions](#ii-step-by-step-instructions)
- [Example Walkthrough](#iii-example-walkthrough)
- [Troubleshooting](#iv-troubleshooting)
- [All Commands Review](#v-all-commands-review)
- [Tips for Your Creation Journery](#vi-tips-for-your-creation)
- [What's Next?](#vii-whats-next) 
- [Privacy Statement](#viii-privacy-statement)


**Quick Navigation:**

- [Jump to Step by Step Instructions](#ii-step-by-step-instructions)
- [Jump to Example Walkthrough](#iii-example-walkthrough)
- [Jump to Troubleshooting](#iv-troubleshooting)
- [Jump to Tips for Your Creation Journery](#vi-tips-for-your-creation)
- [Jump to Privacy Statement](#viii-privacy-statement)

----

#### To Set Up

## 1. Prerequisites and Installation
**[↑ Back to Top](#scotch-broth-prototype-app-user-guide)** | **[Next: Accessing the Scotch Broth Prototype App →](#2-accessing-the-scotch-broth-prototype-app)**

The prerequisites to run the Scotch Broth prototype are:

- **Docker** + **Docker compose** (to spin up the prototype containers)
- **git** (to clone the Scotch Broth repository)

Note: you must have access to the Scotch Broth GitLab to be able to clone the repo.

This prototype works on any platform that meets the above requirements including Windows, MacOS, Linux and the Scotch Broth EIDF VM. The architecture has been tested with the following containers versioning:

```bash
Docker version 29.0.0, build 3d4129b
Docker Compose version v2.40.3
Git version 2.43.0
```

**Note: if running inside the Scotch Broth EIDF VM, then all requirements are already setup and working.** For more information about this as well as about the containerization architecture, please refer to the [developer-guide](/docs/software/developer-guide.md).

----

#### Installing Docker and Docker Compose

The best way to get Docker and Docker Compose is by downloading Docker Desktop that ships both:

[https://www.docker.com/products/docker-desktop/](https://www.docker.com/products/docker-desktop/)

Choose the right client for your platform, download the installer and follow in screen instructions. Once installed, both Docker and Docker Desktop are set in the system's path. 

**Alternative routes:**

- In MacOS you can get Docker and Docker Desktop via [homebrew](https://brew.sh/)

```bash
brew install docker
brew install docker-compose
```

- In Linux you can get **Docker** and **Docker Compose** using the packages manager of the running distribution. Instructions for Red-Hat can be found in the [developer-guide](/docs/software/developer-guide.md).

----

#### Installing Git

Instructions on how to install Git for Windows, MAcOS and Linux can be found in the [Git website](https://git-scm.com/install/windows).

#### Cloming the Scotch Broth repository

Instructions on how to clone locally the Scotch Broth repo are available in the [Developer guide](/docs/software/developer-guide.md).


- To check installed prerequisites run the following commands on terminal:

```bash
docker version
docker compose version
git version
```

If a version number is printed you are all set.

----

## 2. Accessing the Scotch Broth Prototype App
**[↑ Back to Top](#scotch-broth-prototype-app-user-guide)** | **[← Previous: Prerequisites and Installation](#1-prerequisites-and-installation)** 


#### Option 1: using the command line

1. Open a terminal in your platform
2. Navigate to the docker directory of the cloned repo: /software-development-project/docker
3. Run the following command to spin up the two containers:

```bash
docker compose up -d
```

4. Wait until the build process of the two containers is completed then run:

```bash
docker compose ps
```

5. The output should look like below:

```bash
[+] Running 2/2
 ✔ Container prototype-mongodb  Started                                                                                                                                    0.1s 
 ✔ Container prototype-app      Started 
```

**Note:** If Docker Desktop has been installed, it may need to be launched first before running the above command. 

6. Run the following command to enter the prototype app in bash mode:

```bash
docker exec -it prototype-app bash
```

7. You should land in the `/app` directory of the container. Refer to the following sections for instructions on how to run the app.

----

#### Option 2: using the Docker Desktop GUI

1. Launch Docker Desktop

2. Open the embedded terminal by clicking the arrow at the bottom-right of the window.

3. Navigate to the docker directory of the cloned repo: /software-development-project/docker

4. Run the following command to spin up the two containers:

```bash
docker compose up -d
```

5. Wait until the build process of the two containers is completed. Once terminated, click on the "Containers" tab from the menu on the left of the window.

6. The two containers (prototype-mongodb and prototype-app) should be visible and running (green status icon)

7. Click on the "prototype-app" container and in the new windows select the "exec" tab.

8. You should land in the `/app` directory of the container. Refer to the following sections for instructions on how to run the app.

----

#### Start Your Creation

## I. Quick Start
**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** | **[Next: Step-by-Step Instructions →](#ii-step-by-step-instructions)**

#### Prerequisites, Installation And Accessing The App

For the details of installation and running the prototype, please see: →[User Guide: Prerequisites And Installation](user-guide-prerequisites-and-installation.md)

#### Start Story Creation (After staring the prototype)

- Run the command: `python -m src.main run-timeline-demo`
- Input Your **Story ID** (your story Name)
- Set Up Your **Character Name and Bio**
- Create Events and Descriptions- **Reminder**: assign the index numbers to the events chronologically
- Make Changes:

```
  Event 0 (Character Initial State): {e.g., main class: "Naughty child", age: 12, trait: "Rebellious", skill: "Wind Fire Wheels"}
         ↓    Apply "change" (e.g., trait → "Soul without body")
  Event 1: {e.g., main class: "Naughty child", age: 12, trait: "Soul without body", skill: "Wind Fire Wheels"}
         ↓    Apply "change" (e.g., age: 12 → 14)
  Event 2: {e.g., main class: "Naughty child", age: 14, trait: "Soul without body", skill: "Wind Fire Wheels"}
```
- Type "python -m src.main list-data" (-> list current stories and associated characters with respective character IDs, **Reminder:** use the character ID to output the character timeline html page, more details in the following sections);
- Type "python -m src.main export-html --character character_id", hit 'Enter';
- Open the directory, find the HTML page, and view the HTML page in any browsers or your default browser.


#### Simple User-Facing Usage Flow:

```

┌───────────────────────────────────────────────────────────────┐
│            Start Commandline Interface Input                  │
└───────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                        **Creation**                             │
│      • To Creat The First Character For Your Story              │
│      • Create Two Events Along With Two Attribute Changes       │
└─────────────────────────────────────────────────────────────────┘
                              ↓
                      Click Enter (Data Input)
              ┌───────────────┴───────────────┐
              ↓                               ↓
┌──────────────────────────┐    ┌──────────────────────────┐
│  Choose Your Character   │    │   Output All Stories     │
│   Via The Command        │    │    Use The Command       │
│ `--character char_id`.   │    │        `--all`           │ 
├──────────────────────────┤    ├──────────────────────────┤
│        use the           │    │ output all characters'   │
│      Character ID        │    │      timeline pages      │
└──────────────────────────┘    └──────────────────────────┘
              ↓                               ↓
              │                               │
              │                               │                     
              ↓                               ↓
    ┌──────────────────┐           ┌──────────────────────┐
    │    name.html     │           │ Characters' Timeline │
    │                  │           │     HTML Files       │
    └──────────────────┘           └──────────────────────┘
              ↓                               ↓
┌─────────────────────────────────────────────────────────────────┐
│         Copy/Save The Static HTML Page(s) To                    │
│     Your Local Folder And Open Them In Any Browsers             │
└─────────────────────────────────────────────────────────────────┘       
                             ↓     
┌─────────────────────────────────────────────────────────────────┐
│  Interact With The Story Cards And View Timeline Details        │
└─────────────────────────────────────────────────────────────────┘

```

---

## II. Step-by-Step Instructions
**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** | **[← Previous: Quick Start](#i-quick-start)** | **[Next: Example Walkthrough →](#iii-example-walkthrough)**

### Setp 1: Create Your Story Character

```bash
python -m src.main --help

```

You will see the list of availabvle commands. Common commands like `run-timeline-demo`, `list-data`, `export-html --all`, `export-html --character` (more details of this are in following sections).


- Start the application:

```bash
python -m src.main run-timeline-demo

```

- What you will see:

``` 
Welcome to the Scotch Broth character timeline demo!

First, let's create your character.

Story ID:

```

Note: Type your story name after "Story ID". And you will be asked to input a character's name, and bio information including: `main_class`, `age`, `trait`, `skill` (All bio attributes can not be empty).


#### Notice for Understanding The Bio Attributes & Operations:


| Attributes You Can Change | Attribute Type | Description | Examples |
| ---------------- | -------------- | ------------------ | ---------- |
| `main_class` | Text | Character's role/profession | Wizard, Warrior, Rogue |
| `age` | Number | Character's age in years | 17, 25, 43 |
| `trait`| Text | Defining personality trait | Determined, Cunning, Noble |
| `skill` | Text | Key ability or expertise | Fire magic, Swordsmanship |

---
### Step 2: Add Events To The Story And Changes To The Character

After input your story ID, character name, character bio attributes, and then to add two events in total, with one change to the character per event. 


Note-1: when asked for the **"order index"** (1 to 10 inclusive), it should align with the event itself chronologically.


After the events and changes input, what you will see:

```bash

Saving to database...

✓ Saved successfully!
```

Before exporting (To view the Character ID for your character):

- So, to see what data you have (All of your data are stored in the mongodb container), use the command:

```bash
python -m src.main list-data

```

- What you will see:

```
=== Database Contents ===

  Story: your story id/name appears here (1 character(s))
      - char_id1: character_name1

  Story: your story id/name appears here (2 character(s))
      - char_id2: character_name2
      - char_id3: character_name3

```

Note-2: The output will list current stories with their associated character ID(s) and character name(s). If no story has been created so far, no data will be shown.

---- 

### Step 3: Export to the Intreactive HTML Page

#### Three Options to Use

##### Option 1: Export a single character (use the character ID)

- To use the character ID from last step, and then input:

```bash
python -m src.main export-html --character char_id1

```

- What you will see:

```bash
 ✓ Export complete! Files saved to exports/char_id1.html

```


Note: An `exports/` folder is created inside the `/app` directory that contains the output HTML file(s) saved as "character_name.html".


##### Option 2: Export All Characters

```bash
python -m src.main export-html --all

```

- What you will see:

```bash
Exporting X character(s)... 

Timeline exported to: exports/character_name1.html
✓ Character_name1 → exports/character_name1.html 
Timeline exported to: exports/character_name2.html
✓ Character_name2 → exports/character_name2.html

✓ Export complete! Files saved to 'exports/'

```

Note: "exports/" is the output folder (by default).

##### Option 3: Custom Export Directory

- To custom your output directory, use the command:

```bash
python -m src.main export-html --all --output-dir /path-to-your-custom-dir
```

Note: Remember to start with the "/" for the path to your custom output directory.


- What you will see:

```bash
Exporting X character(s)...

Timeline exported to: /path-to-your-custom-dri/character_name.html
✓ Character_name → /path-to-your-custom-dri/character_name.html

✓ Export complete! Files saved to '/path-to-your-custom-dir'

```

----

### Step 4: Saving/downloading the exported html file(s) from Docker to local

##### Option 1: Using The Command Line

1. Open a terminal
2. run the following command:

```bash
docker cp prototype-app:/app/exports/character_name.html /path-to-local-dir

```

The HTML file will be saved in the chosen local directory.


##### Option 2: Using the Docker Desktop GUI:

1. Click on the prototype-app container

2. Click on the "Files" tab in the new window (see the figure below, "Files" tab in the dashed frame)

![save-html-page-to-local](/docs/save-html-page-to-local.png)

3. As the figure shown, navigate to the /app/exports/ directory

4. Find the html file (with your chosen character name), right click on the selected HTML file and choose "Save" (the red arrow pointed position as shown in the figure) then choose a local directory to save the html file.


##### Viewing Your HTML Page:

1. Open your chosen local directory,

2. Double-click and open the `character_name.html`,

3. View the timeline you created in your default browser.


##### What you will see:

- The character name and story descriptions in detail;
- The flip cards showing character's updated states (front-face) and event descriptions and changes applied (back-face);
- Read the story and check all the details on the timeline page, and enjoy the "elegant purple" reading vibe!

Note: You can share the html page with your friends, or take a screenshot to let them view your creation!

--- 

## III. Example Walkthrough
**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** | **[← Previous: Step By Step Instructions](#ii-step-by-step-instructions)** | **[Next: Troubleshooting →](#iv-troubleshooting)**

Let's create a character timeline with an example from scratch to complete!

### Step 1: Create Your Story Timeline

**Input** 

```bash
python -m src.main run-timeline-demo

```

**You will see:** 

```

Welcome to the Scotch Broth character timeline demo!

First, let's create your character.

Story ID: security-chronicles
Character name: Zara
Short character bio: A seasoned security consultant specializing in corporate threat assessment.
Main class (e.g., Wizard, Warrior): Security Consultant
Age (years, > 0): 25
Key trait: Analytical
Key skill: Risk Assessment

```

---

### Step 2: Create Events And Changes

##### Continue Creation

```
Now let's define Event 1.
Event 1 name: Cyber breach investigation
Event 1 order index (1–10): 1
Event 1 description: Zara uncovers a sophisticated insider threat during a routine security audit.

Now define the Change caused by 'Cyber breach investigation'.
Attribute to change [main_class/age/trait/skill]: skill
Operation for non-age attributes is 'set' (replacing the old value).
New value for trait: Digital Forensics

Now let's define Event 2.
Event 2 name: Promotion for advanced performance
Event 2 order index (1–10): 2
Event 2 description: After successfully preventing a major data breach, Zara is promoted to lead the entire security division at her 29.

Now define the Change caused by 'Promotion for advanced performance'.
Attribute to change [main_class/age/trait/skill]: age
Operation for age [set/increment]: increment
How many years should age increase by?: 4

Saving to database...

✓ Saved successfully!
```


##### To obtain the character ID(s) for your character(s)

**Input**

```bash
python -m src.main list-data

```

**You will see:**

```
=== Database Contents ===

  Story: security-chronicles (1 character(s))
      - char_id123: zara

  Story: another story id appears here (2 character(s))
      - char_id5: character_name5
      - char_id6: character_name6

```

---

### Step 3: Export to HTML

**Input** 

```bash
python -m src.main export-html --character char_id123

```

**You will see:**

```
Exporting 1 character(s)...

Timeline exported to: exports/zara.html
✓ Zara → exports/zara.html

✓ Export complete! Files saved to 'exports/'
```

---

### Step 4: View Timeline In Browser

- 1. Save/copy the output files to your local directory (Follow the steps from the last section [Saving Your HTML File To Local Directory](#step-4-savingdownloading-the-exported-html-files-from-docker-to-local))
- 2. Open the file "zara.html" in browser
- 3. You will see:
  - The character timeline with the story name and character description
  - **3 flip cards** presented chronologically
  - Each flip card shows the character updated status (front-face) and the related event description with the change applied (back-face)
- 4. Hover over the card to check all the details
- 5. Share your html page with your friends or take a screenshot of your creation!
 
--- 

## IV. Troubleshooting
**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** | **[← Previous: Example Walkthrough](#iii-example-walkthrough)** | **[Next: All Commands Review →](#v-all-commands-review)**

#### Problem: "Please enter a non-empty value"
**Cause:** You pressed Enter without typing anything

**Solution:** Type something before pressing Enter

---

#### Problem: "Please enter a whole number (integer)"
**Cause:** You entered text when a number was expected (e.g., "fifty" instead of "50")

**Solution:** Enter digits only: `50`, not `fifty`

---

#### Problem: "Please input a number bigger than 0"
**Cause:** You entered 0 or a negative number for age

**Solution:** Enter a positive number: `1`, `25`, `100`

---

#### Problem: "'sword' is not a valid attribute"
**Cause:** You typed an invalid attribute name

**Solution:** Use exactly one of:
- `main_class`
- `age`
- `trait`
- `skill`

(Case doesn't matter for the prototype: `AGE`, `age` or `Age` all work)

--- 

#### Problem: "Error: Character 'xyz' not found"
**Cause:** The character ID doesn't exist in database

**Solution:**
1. Run `list-data` to see all character IDs
2. Copy the exact ID from the output
3. Use that ID in your export command

---

#### Problem: HTML file opens but looks broken
**Cause:** Browser can't find the CSS/JavaScript

**Solution:** Make sure you're opening the `.html` file directly (double-click it), not copying its contents 

---

#### Problem: MongoDB connection error

**Cause:** MongoDB unable to spin up and talk with the app container

**Solution:** Make sure both containers were built correctly, rebuild via docker compsoe up -d. Open Docker Desktop if installed and try again.


**Reminder**: Ensure the Docker is running during your use!

--- 

## V. All Commands Review
**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** | **[← Previous: Troubleshooting](#iv-troubleshooting)** | **[Next: Tips For Your Creation →](#vi-tips-for-your-creation)**

### Commands Overview

#### For Helper

```bash
# List the main commands availabe
python -m src.main --help
```

#### Creation

```bash
# To run Scotch Broth app
python -m src.main run-timeline-demo

```

#### Exporting

```bash
# View / list all stories and characters exist in current database
python -m src.main list-data

# Export a single character
python -m src.main export-html --character character-id

# Export all characters
python -m src.main export-html --all

# Export to custom directory
python -m src.main export-html --all --output-dir /path-to-your-dir

```

### Valid Attribute Names
- `main_class` - Character's role (Wizard, Warrior, etc.)
- `age` - Character's age in years
- `trait` - Personality trait (Brave, Cunning, etc.)
- `skill` - Special ability or skill

### Valid Operations
- `set` - Replace with new value (works for all attributes)
- `increment` - Add to current value (only for `age`)

### Order Index Range
- Minimum: `1`
- Maximum: `10`
- Lower numbers happen first in timeline

---

## VI. Tips for Your Creation 
**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** | **[← Previous: All Commands Review ](#v-all-commands-review)** | **[Next: What's Next? →](#vii-whats-next)**

#### Before your creation:
- Outline your story architecture
- List main characters and their journey
- Define key events and turning points
- Decide which attributes to evolve

**And:**

✅ **DO:**
- Use descriptive names for events
- Keep the event order indexes/indices chronologically organized (1, 2, 3... or 1, 5, 10...)
- Use "list-data" command to view the character ID
- Save or Remember character IDs somewhere if you plan to export later

❌ **DON'T:**
- Leave any field empty
- Use the same order index for multiple events
- Use same character name (use different character names in story creation)
- Use same story name (use different stroy name for each story)

---

## VII. What's Next?
**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** | **[← Previous: Tips For Your Creation Journey ](#vi-tips-for-your-creation)** | **[Next: Privacy Statement →](#viii-privacy-statement)**

After creating and exporting your timeline files:

1. **View HTML files** in your browser - they're interactive!
2. **Hover over flip cards** to see event descriptions and the changes' details.
3. **Export everything** with `--all` to see all timelines.
4. **Share your creation with your friends** share the html page or take a screenshot of your creation!

---

## VIII. Privacy Statement 
**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** | **[← Previous: What's Next? ](#vii-whats-next)**

This Privacy Statement applies to the CLI-Based Stoch Broth storytelling Prototype (the "Prototype"), a command-line interface tool designed for creating interactive stories, characters, events, and changes. The Prototype is intended for personal or developmental use and operates entirely by yourself. We are committed to protecting your privacy and ensuring transparency about how your data is handled.

This statement outlines the types of data processed by the Prototype, how it is used, stored, and protected. By using the Prototype, you agree to the practices described herein. If you do not agree, please do not use or contact us for specific requirements.

#### Data Collected and Processed
The Prototype does not collect personal data from users in the traditional sense (e.g., no online tracking, user accounts, or transmission to external servers). All operations are safe. However, the following types of data may be generated, stored, or processed during use:

1. **Story and Character Data**: This includes user-generated content such as:
   - Story IDs, titles, and descriptions.
   - Character details (e.g., names, bios, attributes like age, traits).
   - Events and changes (e.g., event names, descriptions, order indices, attribute modifications).
   - Timelines and states derived from applying changes to characters.

   These are created by you through CLI commands and are stored in the databases.

2. **System-Generated Data**: Temporary or derived data, such as:
   - Sorted lists of events and changes for timeline building.
   - Calculated character states at specific points in the story.
   - Export data (e.g., template data for views or reports, including export dates).

3. **No Personal Identifiable Information (PII)**: The Prototype does not require or collect PII such as email addresses, IP addresses, location data, or payment information. If you choose to include sensitive personal details in your story content (for example, real names or biographies), that is at your discretion.

4. **Usage Logs (Optional)**: If enabled via configuration, the Prototype may log CLI interactions (like commands executed, errors) for debugging purposes. These logs do not include sensitive content unless explicitly inputted by you.

#### How Data is Used
All data is used to support the core functionality of the Prototype:

1. **Story Creation and Management**: Data is used to build and maintain story timelines, apply changes to character states, and generate views or exports. For example:
   - Sorting changes by event order to calculate progressive character states.
   - Grouping changes by event ID to enrich timeline views.
   - Preparing data for display or export in formats.

2. **Debugging and Improvement**: Local logs (if enabled) help diagnose issues during prototype development. No data is sent to third parties without your explicit action.

3. **No Analytics or Marketing**: The Prototype does not track usage for analytics, advertising, or any commercial purposes. It is a non-commercial prototype focused on the functionality.

4. **Exports and Sharing**: If you export data (for instance, the template_data), it may include story elements and timestamps. You can control any further sharing of these exports.

#### Data Storage and Security

All user-generated data (stories, characters, timelines) is collected and stored securely within the MongoDB container, with easy access but basic security.

No cloud/remote sync: Data remains isolated in the container — nothing is transmitted externally unless you manually export it.

**Best practices:**
- Avoid input sensitive personal content.
- Sanitize sensitive content before sharing.

#### Your Rights and Controls
- **Access and Control**: You have full access to all data stored. 
- **Opt-Out**: Since no data is collected externally, there is no need to opt-out. Simply uninstall or stop using the Prototype.
- **Updates to This Statement**: As a prototype, this statement may evolve. Check the documentation for updates.

#### Contact Us
If you have questions about this Privacy Statement or data handling, please refer to the Prototype's documentation or contact the developer through the provided channels.

This Privacy Statement is provided for informational purposes and does not create a legal contract.

--- 

#### Thank you for being with Scotch Broth, and enjoy building your story timelines! 📖✨ 

**Quick Navigation:**
- [Jump to Quick Start!](#i-quick-start)
- [Jump to Example Walkthrough](#iii-example-walkthrough)
- [Jump to Troubleshooting](#iv-troubleshooting)
- [Jump to Tips for Your Creation Journery](#vi-tips-for-your-creation)

**[↑ Back to Top](#scotch-broth-prototype-user-guide---user-facing-usage)** 

