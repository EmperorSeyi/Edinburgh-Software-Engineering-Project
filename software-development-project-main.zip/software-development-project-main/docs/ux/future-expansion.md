## Future Expansion Development

> This document describes **future expansion ideas only**.
> None of the features outlined here are implemented as part of the MVP;
> they represent a long-term product vision informed by wireframes and client discussions.

## Relationship to UX and Architecture Documentation

This document focuses on **future product expansion from a UX and feature perspective**,
including workflows, interaction concepts, and staged capability growth.

This separation ensures that **user experience design** and **technical architecture**
are clearly distinguished, while still describing the same long-term product vision.


Author: Cahty
Ownership: Stoch Broth

---- 

Evolving from a CLI tool (which generates static exports like a character status review html page) to a fully interactive web-based system (some of the functions are presented on the wireframes: timeline page with events and collaborator comments/notes, sidebar navigation, project management, world map page with "pins", and character details with relationships/photos, etc.) will further be developed through a structured, iterative approach. And the future web version is designed for multi-user collaboration, real-time updates, plagiarism checker, add-on accessibility feature, persistent data, and dynamic UI, and so forth.



#### Future Expansion Visualization:

#### The Three "Entry" Pages (click pictures to view details)
| **Future Expansion Pages** | **Visual View**  |
|------------------------|--------------|
| **Story Timeline View**  | ![Timeline View](/docs/ux/future-expansion/01-timeline-view.png) |
| **Character Timeline View**  | ![Character View: Timeline](/docs/ux/future-expansion/02-character-view.png) |
| **World Map View**  | ![World Map View](/docs/ux/future-expansion/03-map-view.png) |

---

## Evolvement Phases

#### Stage 1 Planning

**Goal:** Maximize end-user adoption by enriching the feature set, building directly upon the existing prototype foundation. To take a glance of the future end user cases, See: [User Stories (Future Expansion)](/docs/ux/user-stories-future-expansion.md)

   - Analyze the CLI: Extract core logic (e.g., event sequencing, character status calculation, export generation). Map to wireframes (e.g., timeline events → flip cards with front/back; character panel → editable forms).
   - Plan auth (login/signup), roles (owner/collaborator), data validation.
   - Migrate CLI logic to server-side (e.g., timeline computation as API endpoints).
   - Implement database schema for persistent storage (replace CLI's in-memory/temp files).
   - Build basic APIs: CRUD for projects, characters, events, locations; endpoints for timeline generation, map pins, collaboration (e.g., POST note).
   - Add file upload for media (photos, artifacts).
   - Enhance CLI export to generate dynamic data (e.g., JSON) that the web app can import as a starting point for existing stories.

#### Stage 2 Frontend Development

   - Start with sidebar navigation, toggle among Dashboard (project list with view/delete/add), Character panel (list with details/edit/delete, photo uploads), Timeline (interactive points with flip cards, drag-reorder events), World Map (interactive pins, popups for conflicts), Collaboration (real-time notes), Media Upload. [See the wireframes overview for future expansion](/docs/ux/future-expansion/wireframes/wireframes-overview.md)
   - Implement hover effects (darken/show labels) and responsive design.
   - Use the CLI-export html page as a base for the timeline view: Enhance flip cards with editable back sides (e.g., to add edit/delete buttons).
   - Connect UI to APIs: E.g., fetch timeline data on load, update on event add/edit.
   - Add forms: Character creation (role dropdown, description, relationships as links), event addition (order, changes affecting characters).
   - Handle state management: Track character locations over time, resolve conflicts (e.g., alert if two characters claim the same spot).

   **Basic Enhanced Interactivities**
   - **Timeline:** Like story plots by viewers, leave real-time comments, collaborater mode, edit/delete function.
   - **Map:** Drag pins, auto-save locations.
   - **Projects:** List with "View" loading full story, "Delete / Request" for collaboraters and effective story project management, version control, etc.


#### Stage 3 Advanced Features

**3.1 Real-Time Collaboration**:
   - Add multi-user support: Invite collaborators, role-based permissions (e.g., owners approve deletes).
   - Real-time updates: Use websockets for live notes, event changes (e.g., see "Collaborator Sam" suggestions).
   - Conflict resolution: Pop-ups for location overlaps, version history for events management.

**3.2 Enhance Media and Visualization**:
   - Media Upload: Store images (character photos, artifacts), display in grids.
   - Export/Import: Allow downloading full project as ZIP (HTML timeline + data), import from CLI exports.

**3.3 User Profile and Help**:
   - Profile: Settings for themes, notifications.
   - Help: In-app tooltips/tutorials based on wireframes (hover explanations).

**3.4 Plagiarism Checker**
   - Integrate a lightweight plagiarism detection feature to help writers ensure originality of story text, character descriptions, and event notes.
   - Core functionality:
     - Text comparison against internal project content (self-plagiarism detection across events/characters).
     - Optional external checks via API (e.g., small-subset queries to public plagiarism services like Copyleaks or Grammarly API — subject to privacy & cost review).
   - UI integration:
     - "Check Originality" button on character/event edit forms and full project export.
     - Highlight matching phrases with color-coded results (e.g., green = original, yellow = similar internal content, red = potential external match).
   - Privacy-first design:
     - No full-text upload to external services without explicit user consent.
     - Option to run fully offline/internal-only mode.
   - Future extension: Similarity scoring + suggestion of rephrasing (using lightweight language models if feasible).

**3.5 Accessibility**

For the web-based application, the accesibilty feature is widely recognized as essential for creating inclusive digital experiences that serve all users, regardless of their abilities or disabilities. And makes our application align with WCAG (Web Content Accessibility Guidelines) standards. **(See: [Accessibility Example: Nezha Timeline](/docs/ux/future-expansion/nezha-accessibility.html))**

- Accessibility Features Included:
  - High Contrast Mode: Black background with white text
  - Large Text Mode: Increases all font sizes by 25%
  - Reduce Motion: Disables animations for users with motion sensitivity
  - Enhanced Focus: Yellow outline on focused elements
  - Skip to Content: Screen reader link to jump to main content
  - System Preferences: Automatically detects OS-level accessibility settings

#### Stage 4 Testing, Deployment, Opitimization

   - Unit/Integration: Test APIs, UI components (e.g., timeline rendering).
   - End-to-End: Simulate multi-user sessions, edge cases (e.g., large timelines).
   - Usability: Beta test with writers for feedback on wireframe features.
   - Performance: Optimize timeline rendering (virtualize long lists), cache map data.
   - Security: Input sanitization, auth tokens, HTTPS.
   - Add analytics: Track usage (e.g., event adds), error logging.
   - Iterate: Post-launch updates based on further user feedback.

---

#### Future Expansion System UX Flow (note: the three main "entry points" are: '**Character View**', '**Timeline View**' and '**World Map View**') 

(Download the svg file of the UX flow: [Future expansion user flow diagram](/docs/ux/future-expansion/future-expansion-user-flow.svg))

| **UX Flow (Future Expansion)** | 
|----------------------------|
| ![Future Expansion User Flow Diagram](/docs/ux/future-expansion/future-expansion-user-flow.svg) |

----

The corresponding **future technical system architecture** (components, data flow,
deployment considerations) is documented separately in:

→ [`docs/design/future/`](../design/future/)


----

[↑ Back To Top](#future-expansion-development)