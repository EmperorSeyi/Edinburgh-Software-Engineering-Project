# User Stories

By the exploration of "user stories", helping Scotch Broth team capture the actual user needs effectively, to understand what users truly want and how they intend to interact with the system, rather than assuming based on technical or business perspectives alone. Without this exploration, there is a risk of developing features that don't address pain points, leading to low adoption or lose popularity in the market. 

----

## User Voices
---

| No. | Our Users | User Stories | Pain Points | Scotch Broth Solution For Enhanced User Satisfaction |
|-----|-----------|--------------------------|-------------------------|-----------------------------|
| 1 | Writer | As a passionate writer, I want a seamless rich text editor to effortlessly add, edit, and refine story elements like vivid scenes and dynamic dialogues, so I can immerse myself in building strong narrative stories without technical hurdles. | Struggles with clunky text tools that disrupt creative flow; needs quick editing for scenes and dialogues to maintain momentum. | Scotch Broth can provide an intuitive, feature-rich editor with real-time autosave, formatting options, and AI-assisted suggestions, ensuring writers feel empowered and productive, leading to higher satisfaction through uninterrupted creativity. |
| 2 | Multimedia Artist | As a visionary multimedia artist, I want to easily upload and seamlessly integrate videos, audio clips, or images into story sections, so multimodal elements vividly enhance the immersive storytelling experience. | Difficulty in incorporating media files without compatibility issues or workflow interruptions; requires smooth integration to enrich contents. | Scotch Broth offers drag-and-drop media uploads with automatic optimization, preview modes, and easy embedding, delighting artists by making multimedia fusion effortless and resulting in polished, engaging stories that boost user satisfaction. | 
| 3 | Fantasy Author | As a creative fantasy author, I want to generate or embed interactive maps for world-building, such as plotting story locations with pins and paths, so spatial elements come alive through collaborative visualization. | Lacks tools for visual world-building | With built-in interactive map generators supporting custom layers, zoomable views, and real-time team edits, Scotch Broth transforms world-building into a fun, shared adventure, increasing satisfaction by making complex spatial storytelling accessible and collaborative. |
| 4 | House-wife | As a busy housewife, I want a storytelling tool that lets me quickly jot down ideas, organize plots, and auto-suggest character developments, so I can weave my imaginative tales in snatched moments—like during a quiet coffee break—saving precious hours. | With endless chores, family meals, and school runs, an effective storytelling tool can reignite the passion for writing as a refreshing escape that helps housewives energized and fulfilled after a long day. | Housewives may have a wealth of ideas and Scotch Broth makes it simple to share without needing technical skills, allowing them to publish quickly during nap times or quiet moments. Also, the beginner-friendly platform plus the solo creator mode help all non-professional “writers” to publish easily. |
| 5 | Student | As a creative student, I want templates for story structures, character archetypes, and plot outlines, integrated with educational tips, so I can learn storytelling fundamentals while building my own tales efficiently. | Overwhelmed by blank pages and lack of guidance, making it hard to start or structure assignments. | With pre-built templates and in-app tutorials, Scotch Broth empowers students to experiment confidently, enhancing learning outcomes and enjoyment. |
| 6 | Science Fiction Enthusiast | As a passionate science fiction enthusiast, I want AI-powered tools to generate futuristic worlds, alien species, and tech gadgets with customizable parameters, including a unique world-building canvas that integrates interactive timelines, relationship maps, and lore databases, so I can effortlessly build immersive sci-fi narratives without getting stuck on idea generation. | Struggles with brainstorming unique sci-fi elements and maintaining consistency across complex worlds, leading to creative blocks and repetitive tropes in stories. | Scotch Broth's AI-driven sci-fi generators, featuring an exclusive world-building canvas as a unique asset for visualizing and organizing lore in real-time, provide endless inspiration with adjustable details, sparking creativity and allowing enthusiasts to focus on storytelling, enhancing enjoyment and producing more original, engaging tales. |
| 7 | 'Beta' Reader | As a detail-oriented 'beta' reader, I want to add in-line comments, thoughtful suggestions, and constructive feedback directly on any text, image, video, or other multi-modal element, so iterative improvements feel intuitive and efficient. | Challenges in providing targeted feedback across diverse media; requires inline tools to streamline revisions without scattered notes. | Featuring inline annotation tools with threading, resolvations. |
| 8 | Book Club Member | As an enthusiastic book club member, I want real-time co-editing features for shared stories, including simultaneous text changes and chat integration, so our group can brainstorm and refine narratives together without version conflicts. | Difficulty in coordinating group writing activities leads to fragmented ideas and lost contributions during meetings. | Scotch Broth's live collaboration tools enable seamless group creativity, boosting enjoyment and satisfaction by turning casual writing sessions into an engaging, interactive experience for friends. |
| 9 | Returning User | As a loyal returning user, I want seamless single-sign-on integration with services like Google or CTS accounts, so onboarding is instant, secure, and friction-free every time. | Frustration with repeated logins and password management; needs quick access to reduce barriers and enhance user retention. | One-click login and secure session persistence ensures users feel welcomed and unhindered, fostering loyalty and high satisfaction by prioritizing convenience and data security in every session. |
| 10 | Company Administrator (The Creative Transformation Support) | As the insightful administrator for The Creative Transformation Support, I want comprehensive analytics on story outputs, including engagement metrics like views, interactions, and completion rates, so we can quantitatively measure and optimize the tool's profound impact on creative processes. | Limited visibility into tool effectiveness; needs data-driven insights to evaluate ROI and guide improvements for organizational growth. | Scoth Broth's advanced analytics dashboards with customizable reports, visualizations, and export options provide administrators with actionable insights, boosting satisfaction by demonstrating clear value and enabling data-informed enhancements to creative workflows. |

----

## Scotch Broth Solution

The real needs from the target users form the prioritized features of our full system design, and provide us the idea of developing a user-centered product roadmap that emphasizes iterative development, starting with a minimum viable product (MVP) to validate assumptions early and incorporate feedback for continuous refinement. Hence, to ensure higher user satisfaction and market relevance by aligning the system's architecture, functionality, and scalability with authentic pain points and goals. 

### What will we build to enhance the creation journey and provide satisfaction with safety? 

**Prioritised features of full product design (the achieved MVP features can be viewed through the links):**
- Story creation via one click, anytime, anywhere
- Character development over timeline [See web page demo](/docs/ux/future-expansion/02-character-view.png), or [See example web page with accessibility feature](/docs/ux/future-expansion/nezha-accessibility.html)
- Characters relationship page [See the wireframe image of character relationship view](/docs/ux/future-expansion/wireframes/08-character-relationship-view.jpg)
- Interactive activities (i.e. likes, save, comment, share, etc.)
- World map exploration
- Story creation tutorial for new users
- Plagiarism-check / intellectual property protection
- Multimedia upload
- Project export and sharing
- Gamification (bages, awarded points, level upgrade, etc.)
- Collaboration panel
- Consistency / logic track 

----

- **More Details see: [Future Expansion Development](/docs/ux/future-expansion.md)**
- **Wireframes For Future Expansion Overview See: [Wireframes Overview](/docs/ux/future-expansion/wireframes/wireframes-overview.md)**


[Back To Top](#user-stories)