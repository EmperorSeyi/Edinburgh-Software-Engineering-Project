# UX Rationale — Scotch Broth

---

## 1. Purpose of This UX Design
The UX design for *Scotch Broth* supports two core project goals:

### 1) Provide a full end-to-end design vision  
(required by the course — even though not fully implemented).  
This demonstrates how the complete storytelling tool will function across characters, timelines, and world-building.

### 2) Justify a narrow, high-quality MVP slice  
focused on **character development over a timeline**, matching the client requirement and realistic team capacity.

**Why:**  
The client brief emphasizes validating the concept, not building the full product. The UX must therefore show scalability while ensuring the coded prototype remains achievable. This document explains the *reasoning* behind each UX choice.

---

## 2. UX Principles & Reasoning

### 2.1 Three Primary Entry Points
- Character View  
- Timeline View  
- World Map View  

**Why:**  
These three reflect the core mental model of storytellers: narratives are built through *characters*, *events*, and *locations*. Anchoring navigation around these reduces cognitive load and aligns with user stories from writers, students, fantasy authors, and more.

---

### 2.2 Progressive Disclosure (MVP → Full Product)
We intentionally distinguish:

- **MVP:** CLI-only, minimal, delivered in code.  
- **Full product UI:** visual wireframes showing future expansion.

**Why:**  
This satisfies the assessment requirement for system-wide design while preventing feature creep in the prototype. It shows ambition without sacrificing quality.

---

### 2.3 Low Cognitive Load & Flow Preservation
- Fixed left-side navigation  
- Clean screens with one major task each  
- No nested menus or modal-heavy design  

**Why:**  
Creative users lose productivity when interfaces are noisy or unpredictable. Simplifying navigation protects their writing flow and reduces confusion.

---

### 2.4 Transparency and Control Over Story Structure
The system emphasizes visibility into:
- character lists  
- their relationships  
- events across time  
- locations across space  

**Why:**  
The core requirement is tracking *how characters evolve across events*. A transparent UX helps authors maintain logic, pacing, and coherence.

---

## 3. Mapping User Needs → UX Decisions

| User Need | UX Decision | Why |
|----------|-------------|------|
| Managing many characters | Persistent character list | Quick switching without losing context |
| Understanding story progression | Horizontal timeline with event cards | Humans intuitively read time left → right |
| World-building | Map with pins and character locations | Supports fantasy/sci-fi spatial storytelling |
| Fast onboarding | Minimal homepage with two choices | Reduces early friction and decision fatigue |
| Collaboration (future) | Comment-only permissions on timeline | Protects story integrity during co-creation |
| Multimedia support | Separate Media Upload view | Prevents clutter in writing and timeline views |

---

## 4. Information Architecture (IA) & Reasoning

Project Information Architecture (ASCII-safe)

Log In / Sign Up
        |
        v
 Homepage
   |                 \
   |                  \
   v                   v
Open Project     Create New Project
        |                  |
        v                  |
  Project List Page <------ 
        |
        v
  Project Dashboard
     /       |        \
    v        v         v
Character   Timeline   World Map
    |         |           |
    v         v           v
Details     Events     Locations
Relations   Plots      Movement

**Why this IA works:**
- No dead-end screens  
- Mirrors natural creative workflow  
- Maintains clear hierarchy: project → content views  
- Reduces navigation complexity for writers  

---

## 5. Rationale for Each Major View

### 5.1 Homepage
Two main choices:
- Create New Project  
- Open Existing Project  

**Why:**  
Writers often experience decision overload. A calm, minimal homepage encourages them to start quickly and reduces friction during login or project creation.

---

### 5.2 Project Dashboard
Displays:
- recent activity  
- collaborators  
- progress  
- navigation to Character / Timeline / World Map  

**Why:**  
A dashboard gives authors situational awareness, which is essential in long-form storytelling and collaboration.

---

### 5.3 Character View
Two tabs:
- **Character Details** (attributes, notes, photos)  
- **Character Relationships** (network map)  

**Why:**  
Writers think of “who the character is” and “how they relate to others” as two distinct tasks. Splitting the view reduces cognitive load and makes editing clearer.

---

### 5.4 Timeline View
Shows:
- horizontal timeline  
- events  
- character involvement  
- optional collaborator comments (future feature)  

**Why:**  
Events are the backbone of narrative logic. A clear horizontal timeline helps users visualize pacing, plot gaps, and character arcs. This matches the **MVP timeline computation logic**, ensuring future UI aligns with the backend.

---

### 5.5 World Map View
Contains:
- map view  
- pins  
- character list  

**Why:**  
Spatial storytelling is crucial for fantasy/sci-fi authors. A map provides necessary context for movement, lore, and setting consistency.

---

### 5.6 Media Upload View
Dedicated drag-and-drop area.

**Why:**  
Separating media from core writing views keeps the UI uncluttered and supports multimedia artists without overwhelming writers.

---

## 6. Navigation Rationale (Consistency & Reasoning)

You previously standardized navigation by:
- keeping the same left sidebar on every screen  
- consistent icon order (Dashboard → Character → Timeline → World Map → Collaboration → Media → Profile → Help)  
- clear hover tooltips  
- consistent spacing and alignment  

**Why:**  
Consistency reduces error rates and increases learnability. Creative tools must feel stable and predictable, especially during collaborative work.

---

## 7. MVP vs. Full Product: UX Reasoning

### MVP (CLI Only)
Includes:
- character creation  
- event creation  
- timeline logic  
- HTML export  

**Why:**  
This is the smallest possible slice that still demonstrates the core concept:  
**tracking character evolution over time.**  
It fits the team’s technical skills and ensures a complete, testable pipeline.

---

### Full Product (Wireframes)
Includes:
- accounts  
- dashboards  
- character tools  
- timeline UI  
- world map  
- media uploads  
- collaboration panel  

**Why:**  
The assessment requires a full-system design. These wireframes demonstrate long-term value and show how the MVP naturally expands into a comprehensive storytelling platform.
