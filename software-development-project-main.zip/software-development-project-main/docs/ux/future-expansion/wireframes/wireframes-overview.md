# Future Expansion Wireframes Overview

This document contains the wireframe individual pages, serving as the visual foundation and reference for the construction of future web-based system.


---- 

### 🌐 Dashboard

| **Dashboard Page** | 
|----------------------------|
|  ![Dashboard Page](04-dashboard.jpg) |

----

### 👥 User Login And Sign-up

| **Login** | 
|----------------------------|
|  ![Login](02-login.jpg) |

| **Sign-up** | 
|----------------------------|
|  ![Sign-up](03-signup.jpg) |

----

### 👤 Character Panel
**Central place to manage characters**

- Searchable list of characters
- Card view: character photo, name, info. (e.g., main class, age, key trait, etc.)
- Click to open **detail/edit view** (modal or full page)
- Actions: select multiple → delete / export
- Drag-to-reorder (optional priority / importance)
- Photo upload + cropper support

| **Character Panel** | 
|----------------------------|
|  ![Character Panel](07-character-list-view.jpg) |

----

### 💼 Story Project Management

- List of all projects/stories with title, and basic information
- Quick actions: **+Create Project**, **View**, **Delete**
- Simple stats: total characters, key actions, collaborators
- Search & filter by name / last modified

| **Project List View** | 
|----------------------------|
|  ![Project List View](05-project-list.jpg) |


----

### 🕰️ Timeline
**Interactive chronological view of character/story events**

- Horizontal or vertical timeline (can custom)
- Flip cards: front = summary, back = full description + changes
- Color-coded for readability
- Drag & drop reordering of events
- Zoom / scroll + year/age markers
- Click event → show affected characters & attribute changes
- Filterig feature

| **Timeline View** | 
|----------------------------|
|  ![Timeline View](13-timeline-view-2.jpg) |

----

### 🗺️ World Map
**Geographic visualizatino & conflict checker**

- Interactive map feature
- Custom pins for locations with custom icons
- Popup on click: location name, description
- Filter: show only locations with active conflicts and linked conflicts/events/characte

| **World Map Viewe** | 
|----------------------------|
|  ![World Map](10-map-view.jpg) |

----

### 📤 Media Upload
**Central asset manager for images, maps, reference photos**

- Drag-and-drop upload zone
- Tagging & search by filename / tag / upload date
- storage space for different level of subscription users
- Delete / download function

| **Media Uplad** | 
|----------------------------|
|  ![Media Upload](12-media-upload.jpg) |

----

### ✍️ Collaboration Channel
**Real-time shared comments / notes and collaborations**

- Threaded comments attached to project, character, event or timeline point (Advanced feature)
- @mentions and notifications
- Real-time collaborative editing
- Version control feature
- Sidebar chat or activity stream

---- 
**Scotch Broth Team:** Olivia Heale (PM) · Cathy Xia (UX) · Gabriele Dalla Torre (Infra) · Kangsu Lee (Backend) · Oluseyi Olaniyi (QA)  

[Back To Top](#future-expansion-wireframes-overview)
