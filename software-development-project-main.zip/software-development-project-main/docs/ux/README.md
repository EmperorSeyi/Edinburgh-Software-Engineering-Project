# 🎨 UX Documentation Overview

**Project:** Scotch Broth — Software Development Project (2025–26)  
**Folder:** `docs/ux/`

This directory contains **user experience (UX) and interaction design documentation**
for **future expansions** of the *Scotch Broth* product.

These UX documents are intentionally complementary to the future system design
documentation found in:

→ [`docs/design/future/`](../design/future/)

The distinction is:

- **docs/design/future/** focuses on *technical system design*, including architecture,
  data flow, and component-level considerations for a future web-based platform.

- **docs/ux/** focuses on *user interaction and experience*, including workflows,
  usability rationale, user stories, and visual wireframes.

Both describe the same future product vision from different perspectives and are kept
separate to avoid conflating technical design with user-facing interaction design.

User interaction for the **implemented MVP prototype** (a CLI-based system) is
documented directly in the MVP design and architecture files under:

→ [`docs/design/mvp/`](../design/mvp/)

---

## 📂 Folder Structure

- [`ux-rationale.md`](ux-rationale.md)  
- [`user-stories-future-expansion.md`](user-stories-future-expansion.md)  

- [`future-expansion/`](future-expansion/)  
  - [`future-expansion.md`](future-expansion/future-expansion.md)   
  - [`future-expansion-user-flow.svg`](future-expansion/future-expansion-user-flow.svg)  

- [`wireframes/`](future-expansion/wireframes/)  
  - [`01-homepage.jpg`](future-expansion/wireframes/01-homepage.jpg)  
  - [`02-login.jpg`](future-expansion/wireframes/02-login.jpg)  
  - [`03-signup.jpg`](future-expansion/wireframes/03-signup.jpg)  
  - [`04-dashboard.jpg`](future-expansion/wireframes/04-dashboard.jpg)  
  - [`05-project-list.jpg`](future-expansion/wireframes/05-project-list.jpg)  
  - [`06-create-project.jpg`](future-expansion/wireframes/06-create-project.jpg)  
  - [`07-character-list-view.jpg`](future-expansion/wireframes/07-character-list-view.jpg)  
  - [`08-character-web-view.jpg`](future-expansion/wireframes/08-character-web-view.jpg)  
  - [`09-create-character.jpg`](future-expansion/wireframes/09-create-character.jpg)  
  - [`10-map-view.jpg`](future-expansion/wireframes/10-map-view.jpg)  
  - [`11-timeline-view-1.jpg`](future-expansion/wireframes/11-timeline-view-1.jpg)  
  - [`12-media-upload.jpg`](future-expansion/wireframes/12-media-upload.jpg)  
  - [`13-timeline-view-2.jpg`](future-expansion/wireframes/13-timeline-view-2.jpg)

---

## 🎯 Purpose of This Directory

This folder provides **future-facing UX artefacts** that illustrate how the current
CLI-based MVP prototype could evolve into a **full, web-based collaborative
storytelling platform**.

It intentionally separates:

- **Implemented MVP UX**  
  (documented in [`docs/design/mvp/`](../design/mvp/))

- **Future product UX**  
  (documented in this directory)

This separation reflects the project’s **scoped, prototype-first approach** and avoids
conflating conceptual design with implemented functionality.

---

## 📘 Contents Overview

### UX Rationale
**File:** [`ux-rationale.md`](ux-rationale.md)

Explains high-level UX principles, scope constraints and boundaries, and how interaction decisions
align with the client brief and the deliberately narrow MVP scope.

---

### User Stories (Future Expansion)
**File:** [`user-stories-future-expansion.md`](user-stories-future-expansion.md)

Describes future user needs and interaction goals that inform long-term product
design. These user stories are **not implemented** in the MVP.

---

### Future Expansion Overview
**File:** [`future-expansion/future-expansion.md`](future-expansion/future-expansion.md)

Outlines a staged roadmap for evolving the CLI prototype into a collaborative,
web-based system. All features described are **out of scope** for the MVP.

---

### Future Expansion User Flow
**Files:**

- [`future-expansion/future-expansion-user-flow.svg`](future-expansion/future-expansion-user-flow.svg)

Provide an overview of intended navigation and interaction flow for the future
web-based system

---

### Wireframes
**Folder:** [`future-expansion/wireframes/`](future-expansion/wireframes/)

Contains visual wireframes illustrating future UI concepts such as:

- authentication  
- dashboards  
- character views  
- timelines  
- maps  
- media upload  

These wireframes support the **future UX vision only**.

---

## 📝 Notes for Assessors

- The **MVP prototype is CLI-based** and intentionally minimal.  
- All **MVP interaction details** are documented in [`docs/design/mvp/`](../design/mvp/).  
- This UX folder documents **future design thinking**, not implemented features.  

The structure reflects a **dual-track approach**:

- **Build a working prototype now**  
- **Design for future expansion later**

