# 🧪 Test Plan — Scotch Broth Prototype

This document outlines the overall testing strategy for the Scotch Broth story-structure prototype, covering unit testing, functional testing, and usability testing.

---

## 1. 🎯 Purpose

The purpose of this test plan is to ensure the prototype is:

- Functionally correct  
- Usable by target storytellers  
- Stable and consistent across key features  
- Ready for Milestone 2 assessment  

The testing strategy follows a lightweight approach appropriate for an MVP-scale prototype.

---

## 2. 📦 Scope of Testing

### **In Scope (Milestone 2 Prototype)**
- Character creation and editing (CLI)
- Event creation and editing
- Ordered timeline computation
- Snapshot of character state at a given event index
- Exporting story state to static HTML
- Basic persistence using MongoDB or JSON
- Usability of the CLI-based workflow

### **Out of Scope (Future or Non-MVP)**
- Web-based user interface  
- Real-time collaboration  
- Multiple collaborators editing simultaneously  
- Advanced map or relationship views  
- Authentication or accounts  
- Rich media support  

---

## 3. 🧪 Types of Testing

### **3.1 Unit Testing**
Automated tests validating individual Python functions and Pydantic models.

Covers:
- Character model
- Event model
- Change model
- Timeline query logic
- Edge cases (e.g. empty timelines, missing fields)

Detailed in a separate document:  
[`unit-testing.md`](./unit-testing.md)

---

### **3.2 Functional Testing (Manual)**
Manual checks performed by team members to verify that CLI commands behave as intended:

- Creating characters  
- Creating events  
- Assigning changes  
- Querying the timeline  
- Exporting output  

A simple checklist is used to keep the scope manageable and consistent.

---

### **3.3 Usability Testing**
**Goal:** Ensure the interaction flow (CLI tasks → output → understanding) is intuitive for target users.

Usability testing is documented separately:
- [`usability-test-plan-summary.md`](./usability/usability-test-plan-summary.md)
- [`moderator_script.md`](./moderator_script.md)

Core tasks include creating characters and events, linking them, and interpreting exported output.

---

## 4. 🗂️ Items to Be Tested

### **Modules**

| Component | Description |
|----------|-------------|
| `src/models/models.py` | Pydantic domain models (Character, Event, Change) |
| `src/timeline/core.py` | Timeline logic (event ordering, applying changes, computing state over time) |
| `src/persistence/database.py` | Persistence layer providing CRUD operations (MongoDB with JSON fallback) |
| `src/presentation/html_export.py` | Static HTML export for presenting story timelines |
| `src/cli/commands.py` | User-facing CLI commands implemented with

---

## 5. 🧭 Test Approach

### **Unit Tests**
- Written using `pytest`
- Run locally and/or inside Docker
- Focus on correctness of core logic rather than full coverage

### **Functional Tests**
- Executed by team members on local machines
- Checklist used to ensure consistency
- Issues discovered are logged in GitLab Issues

### **Usability Tests**
- Conducted with 1–5 participants, appropriate for an MVP-stage prototype
- Tasks include:
  - Creating a character
  - Creating an event
  - Linking a character to an event
  - Viewing exported timelines
- Feedback recorded and analysed qualitatively

---

## 6. 🔧 Test Environment

- **Python:** 3.x  
- **Dependencies:** Defined in `environment.yml`  
- **Database:** Local MongoDB (Docker volume) or JSON fallback  
- **Execution:** Local machine or Docker container (`docker compose run`)  

---

## 7. 👥 Responsibilities

| Area | Owner |
|------|-------|
| Unit testing | Gabriele, Kangsu |
| Functional testing | Entire team |
| Usability testing | Oluseyi (lead), Olivia (coordination) |
| Documentation | Olivia (PM), supported by each owner |

---

## 8. 📅 Schedule (Milestone 2)

| Week | Activity |
|------|----------|
| Week 8–9 | Begin writing unit tests |
| Week 9 | Conduct usability pilot testing |
| Week 10 | Finalise unit tests and functional checks |
| Week 10 | Produce usability summary |
| Milestone 2 | Submit testing evidence |

---

## 9. 📊 Reporting and Evidence

- Unit test results recorded via terminal output, screenshots, or notes  
- Usability results summarised in `usability-test-plan-summary.md`  
- Major issues tracked using GitLab Issues  
- Final testing summary included in the final submission  

---