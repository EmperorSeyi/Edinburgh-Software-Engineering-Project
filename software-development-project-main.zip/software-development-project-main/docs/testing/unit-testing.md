# Unit Test Plan

**Team:** Scotch Broth  
**Version:** 1.0

## 1. Introduction

### 1.1 Purpose
This document defines the unit testing strategy for the Scotch Broth prototype, following Wilson et al.'s *"Plan for Mistakes"* principle and overall coding standards. Our unit testing approach focuses on:

- Defensive programming through assertions and validation, including error handling strategies
- Off-the-shelf testing framework: `pytest`
- Regression testing by converting bugs into test cases
- Test-driven confidence in our five-layer architecture (CLI, models, persistence, timeline, presentation)

Unit tests were written and executed iteratively by team members alongside development of their respective components.

### 1.2 Testing Philosophy
According to Wilson et al. (2014), "assertions can make up a sizeable fraction of the code in well-written applications." Accordingly, the purpose of our unit testing is:

- Executable documentation that explains system behaviour
- Safety nets that catch errors early
- Design drivers that encourage testable, modular code
- Function-oriented testing, where each function executes a single task and has associated unit test coverage

### 1.3 Scope
This plan covers unit tests for the Scotch Broth prototype across all five architectural layers:

- Application Layer A (CLI interface)
- Domain Layer B (Pydantic models)
- Persistence Layer C (MongoDB operations)
- Timeline Logic Layer D (core logic, event/query processing)
- Presentation Layer E (HTML/visual export)

Out of scope: Integration tests, end-to-end tests, and performance testing.

## 2. Testing Framework and Tools

### 2.1 Primary Framework: `pytest`
Rationale: `pytest` is the standard Python testing framework, offering:

- Simple, readable test syntax
- Rich assertion introspection
- Excellent flexibility to handle many types of problems

Basic usage:

    # Run all tests
    pytest

    # Run a specific test file
    pytest tests/test_models.py

    # Run tests matching a pattern
    pytest -k "test_character"

### 2.2 Test Organisation
All unit tests are placed in the `tests/` folder and grouped by architectural layer. Each Python file contains unit tests for functions in that specific component.

    tests/
    ├── __init__.py
    ├── test_cli.py          # application layer functions
    ├── test_models.py       # models domain layer functions
    ├── test_persistence.py  # persistence layer functions
    ├── test_timeline.py     # timeline logic functions
    ├── test_export.py       # output exporter functions

Tests are designed to be run locally during development and to support repeatable execution in reviewer or CI environments.