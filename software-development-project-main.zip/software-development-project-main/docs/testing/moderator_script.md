# Usability Test Moderation Script  
**Story Structure Prototype (Characters, Events, Links, Timeline, Character Profile)**

This script was used to conduct moderated usability testing sessions for the Scotch Broth prototype. It ensures consistency across sessions while allowing participants to think aloud and explore the system naturally.

## 1. Introduction (2–3 minutes)

### Welcome and purpose
> “Thank you for taking part in this usability study. Today, we’re testing an early prototype of a storytelling tool that allows users to create characters, events, and timelines. Our goal is to understand how intuitive the design is — not to test your skills.”

### Reassurance
> “There are no right or wrong answers. If something is confusing, that’s important for us to learn.”

### Consent
> “Before we begin, I want to confirm that you’re happy to participate and that it’s okay for me to take notes during the session.”

*(Wait for confirmation.)*

### Think-aloud reminder
> “As you complete tasks, please say your thoughts out loud — what you expect to happen, what you’re looking for, and what confuses you. This helps us understand your reasoning.”

## 2. Background Questions (2 minutes)

> “Before starting, I have a few quick questions:”

- “Have you used any storytelling, writing, or timeline tools before?”
- “How comfortable do you feel using digital tools in general?”
- “Have you ever created characters or story events for any project?”

*(Keep this brief — context gathering only.)*

## 3. Task-Based Testing

### Instructions
> “I will give you one task at a time. Please complete each task to the best of your ability using the interface, and remember to think aloud as you go.”

### Task 1 — Create a character (3–5 minutes)
> “Please create a new character with a name and a short description.”

**Observation focus:**
- Can the participant find the “Create Character” action?
- Do they understand the fields (name, bio, tags)?
- Do they successfully save the character?

### Task 2 — Create an event (3–5 minutes)
> “Now please create a new event with a title, timepoint, and summary.”

**Observation focus:**
- Do they understand the concept of a timepoint?
- Can they locate the event creation flow easily?

### Task 3 — Link a character to an event (3–5 minutes)
> “Please link the character you just created to the event. You may choose any relationship, such as presence or state change.”

**Observation focus:**
- Do users understand the linking concept?
- Can they complete the task without guidance?

### Task 4 — View the timeline (3–5 minutes)
> “Please navigate to the timeline view.”

**Observation focus:**
- Do events appear in the intended chronological order?
- Do users understand the layout (list or visual)?
- Are linked characters visible or discoverable?

### Task 5 — View a character profile (3–5 minutes)
> “Please open the character profile and review their event history.”

**Observation focus:**
- Is the character arc clear?
- Does the event history display correctly?

### Task 6 — Edit or delete an entry (3 minutes)
> “Please edit or delete either the character or the event.”

**Observation focus:**
- Can users locate editing tools?
- Do they understand the confirmation process?

### Task 7 — Add a comment (2–3 minutes)
> “Please add a comment to either the character or the event.”

**Observation focus:**
- Do users understand where comments are stored?
- Is the notes or comment interaction clear?

## 4. Post-Test Questions (3–5 minutes)

Ask verbally:
- “How easy was it to learn and use the prototype?”
- “Was anything confusing or unexpected?”
- “Which part of the workflow felt easiest?”
- “Which part felt hardest or most frustrating?”
- “If you could change one thing, what would it be?”

## 5. Closing (1 minute)

> “Thank you for your feedback — it’s extremely valuable and will help us improve the system. This concludes the session.”