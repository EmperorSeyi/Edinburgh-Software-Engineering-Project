# 🧪 Testing Results & Interpretation (CLI MVP)

**Project:** Scotch Broth — Creative Transformation Support (CTS)  
**Prototype:** CLI MVP (characters, events, timeline, HTML export)

This document summarises testing carried out on the Scotch Broth CLI prototype and
interprets what the results indicate about prototype quality, limitations, and
next steps.

It complements:
- the [Usability Test Plan](usability-test-plan-summary.md), and  
- the [Usability Findings report](usability-findings.md).

The testing scope was derived directly from the
[MVP requirements](../design/mvp/mvp-requirements.md),
focusing on validating the timeline–character integration, core creation workflows,
and export functionality defined as in scope for the prototype.

---

## 1. Overview of Testing Performed

Testing focused on two areas:

1. **Usability testing** to assess how users interact with the CLI and understand
   core concepts.
2. **Automated software testing** to validate correctness and robustness of the
   domain model and CLI execution.

The goal was not exhaustive coverage, but validation of the core prototype slice
and identification of high-impact risks appropriate to an MVP.

---

## 2. Usability Testing Results and Interpretation

### 2.1 Testing Approach

Usability testing was conducted in two stages:

#### Internal pilot walkthrough
- Conducted by the project lead (technical background)
- Used to surface early usability and conceptual issues

#### Moderated usability session (P1)
- One external, non-technical participant  
- Remote session on a laptop (Seattle, USA)

Testing focused on:
- understanding of CLI prompts and terminology  
- ability to create characters and events  
- applying attribute changes  
- interpreting the resulting timeline output  

Given the MVP scope, a small participant set was appropriate for identifying major
usability barriers rather than measuring fine-grained usability metrics.

---

### 2.2 Key Usability Findings

#### What worked well

Participants responded positively to:
- guided prompts that supported creative thinking  
- freedom to invent characters and story elements  
- ability to enter events out of chronological order  
- clear and visually engaging HTML timeline output  
- clear signalling that the prototype is an early MVP  

**Interpretation**

These results indicate that the prototype successfully communicates its core value
proposition: supporting character- and event-driven story development with a
tangible timeline output.

---

#### Key usability issues and their implications

**Onboarding and terminology**
- The *Story ID* prompt caused immediate hesitation.
- Users were unsure what the ID represented or why it was required.

*Implication:*  
This introduces friction at first interaction and risks early abandonment. The
issue is conceptual rather than technical and suggests a need for clearer naming
or automatic ID generation.

---

**Attribute meaning and guidance**
- Attribute labels (e.g. traits, skills, class) lacked clear guidance.
- The term *class* felt overly RPG-specific for general storytelling.

*Implication:*  
Domain terminology is not yet well aligned with a non-technical, non-gaming
audience, increasing the likelihood of incorrect inputs.

---

**Event ordering**
- The `order_index` concept caused confusion.
- Users expected automatic ordering or a simpler reordering mechanism.

*Implication:*  
Although the temporal model is flexible, its mental model is not easily
discoverable through the CLI.

---

**Unsupported changes and validation**
- Users attempted to modify unsupported attributes.
- Users adapted story ideas to fit system constraints.

*Implication:*  
This highlights the need for stronger validation and clearer documentation of
supported functionality.

---

**Reliability issue**
- A save failure occurred during an attribute update, preventing task completion.
- This also prevented full evaluation of the timeline in that session.

*Implication:*  
Reliability issues strongly influence perceived quality and should be prioritised
over UX refinements.

This issue was **resolved prior to final submission** and did not recur in
subsequent testing.

---

### 2.3 Usability Severity Summary

| Issue                         | Severity | Impact                     |
|------------------------------|----------|----------------------------|
| Story ID terminology         | Medium   | Disrupts onboarding        |
| Attribute meaning unclear    | High     | Causes confusion and errors|
| Event ordering model         | Medium   | Reduces discoverability    |
| Unsupported attribute edits  | Medium   | Increases user friction    |
| Save failure                 | High     | Blocks task completion     |
| RPG-centric terminology      | Low      | Narrows audience unnecessarily |

---

## 3. Automated Software Testing Results

### 3.1 Domain Model Unit Tests

**What was tested:**  
Core domain models and data transformations.

**Execution:**  
Tests located in `tests/test_models.py` and executed using `pytest`.

**Issues encountered and resolutions**
- Initial failures due to missing imports and environment dependencies  
- Fixed by importing models from `src/models/models.py`  
- Required dependency (`pydantic`) installed locally  
- One assertion error in `test_event_to_dict`  
  - `order_index` compared as a string instead of an integer  
  - Assertion updated accordingly  

**Final result:**  
✅ 12 / 12 tests passing

**Observations**
- Pydantic deprecation warnings were observed but did not affect outcomes.
- Manual dependency installation highlighted the need for clearer dependency
  documentation.

---

### 3.2 CLI Smoke Testing

A CLI smoke test for the `run-timeline-demo` command initially failed due to a
`StopIteration` error, resulting in a non-zero exit code.

**Resolution**
- Introduction of a mock database to allow CLI testing without MongoDB  
- Correction of assertions related to state changes  
- Fixes submitted via merge request and reviewed  

**Interpretation**

These changes improve testability and support repeatable execution in reviewer
and CI environments.

---

## 4. Limitations of Current Testing

- Usability testing involved a small participant set and is not statistically
  generalisable.
- Automated tests focus primarily on the domain model layer; integration coverage
  is limited.
- Some functionality depends on external services, constraining full automation.

These limitations are appropriate given the prototype scope and timeframe.

---

## 5. Planned Improvements (Not Yet Implemented)

Based on testing results, future work includes:
- improving onboarding language and Story ID handling  
- refining attribute terminology for non-RPG storytelling  
- introducing clearer event ordering or reordering mechanisms  
- strengthening validation and error messaging  
- expanding dependency documentation and integration testing  
- resolving remaining reliability edge cases  

A key lesson from testing is that **conceptual clarity and reliability have a
greater impact on perceived quality than additional features** in early-stage
creative tools.

---

## 6. Conclusion

Testing demonstrates that the Scotch Broth CLI prototype effectively communicates
its core concept and supports creative story-development workflows. Usability
testing identified high-impact issues related to terminology, onboarding, and
reliability, while automated tests confirm correctness of core domain logic.
Overall, the results indicate a conceptually strong MVP that would benefit most
from reliability hardening and UX clarification in a subsequent iteration.