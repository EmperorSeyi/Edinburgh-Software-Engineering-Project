# 🧪 Testing Documentation

This directory contains all **testing-related documentation** for the *Scotch Broth*
Software Development project.

Together, these documents demonstrate a **complete, proportionate testing approach**
appropriate for an **MVP-scale prototype**, balancing automated verification of core
logic with qualitative evaluation of usability.

---

## 📂 Contents

### 1️⃣ Unit Testing
**File:** [`unit-testing.md`](unit-testing.md)

Describes the unit testing strategy for the prototype, including:

- testing philosophy and scope  
- use of `pytest` for automated tests  
- organisation of tests across the project’s architectural layers  

Unit tests validate the **correctness and robustness** of core domain logic and
supporting components.

---

### 2️⃣ Overall Test Plan
**File:** [`test-plan.md`](test-plan.md)

Provides a high-level overview of the testing strategy for the project, covering:

- unit testing  
- manual functional testing  
- usability testing  

This document defines **what is in scope for testing** at Milestone 2 and how
different testing activities relate to one another.

---

### 3️⃣ Usability Testing Design
**Files:**

- [`usability-test-plan-summary.md`](usability-test-plan-summary.md)  
- [`moderator_script.md`](moderator_script.md)

These documents describe how usability testing was **designed and conducted**,
including:

- test objectives and success criteria  
- participant profile and recruitment considerations  
- task design  
- moderation approach for usability sessions  

They establish the **rationale and structure** for evaluating usability of the
CLI-based prototype.

---

### 4️⃣ Usability Findings
**File:** [`usability-findings.md`](usability-findings.md)

Summarises observations from usability testing, highlighting:

- what worked well  
- key usability issues  
- severity and impact of identified problems  

This document focuses on **observed user behaviour**, rather than proposing
solutions.

---

### 5️⃣ Testing Results and Interpretation
**File:** [`testing-results-and-interpretation.md`](testing-results-and-interpretation.md)

Synthesises results from:

- usability testing  
- automated unit testing  
- CLI smoke testing  

It interprets what these results indicate about the **current quality,
limitations, and future improvement areas** of the prototype.

---

## 🧾 Summary

Taken together, these documents demonstrate:

- **systematic planning** of testing activities  
- **appropriate testing methods** for an MVP prototype  
- **evidence-based evaluation** of usability and correctness  
- **clear articulation of limitations and next steps**