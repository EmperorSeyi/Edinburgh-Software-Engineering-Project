# Usability Test Findings  
**Scotch Broth – CLI MVP**

This document reports findings from usability testing conducted on the Scotch Broth CLI prototype. It complements the Usability Test Plan Summary by describing observed user behaviour, points of confusion, and aspects that worked well during testing.

Together, the test plan and findings demonstrate a complete usability process: planning → testing → evaluation.

## Scope and approach
Usability testing was conducted in two stages:

- An internal pilot walkthrough by the project lead to surface early issues
- A moderated usability test with one external participant

Testing focused on:
- Clarity of CLI prompts
- Understanding of character and event concepts
- Ability to complete key tasks
- Interpretation of timeline output

## Participants
- **Pilot walkthrough:** Project lead (technical background)
- **External test (P1):** Non-technical user, remote session on laptop (Seattle, USA)

Given the MVP scope, a small number of participants was sufficient to identify major usability issues.

## Tasks tested
Participants attempted to:
- Create a character
- Create events
- Apply attribute changes
- Interpret the resulting timeline output

## Findings from pilot walkthrough
Several usability issues were identified early:

**Story ID unclear**  
It was not obvious what should be entered, or why an ID was required.

**Attribute meaning ambiguous**  
Users were unsure what values were expected for attributes such as trait, skill, or class.

**Skills not cumulative**  
Adding a new skill replaced the previous one, which conflicted with user expectations.

**Environment setup interrupted flow**  
Installing dependencies disrupted the testing experience.

**“Class” assumed a role-playing context**  
The term felt restrictive for non–D&D-style storytelling.

These issues informed the focus of the external usability test.

## Findings from external test (P1)

### Character creation
- User hesitated immediately at the Story ID prompt.
- The bio prompt appeared too early; the user expected more structured fields (e.g. age) first.
- Attribute labels lacked sufficient guidance.

### Event creation and ordering
- The `order_index` concept caused confusion.
- The user expected automatic ordering or an easier way to reorder events.
- Scrolling to review earlier inputs caused loss of context.

### Applying changes
- The user attempted to change an unsupported attribute (“constitution”).
- The user was unsure how to classify certain changes and asked for clarification.
- The user adapted their story idea to fit system limitations.
- A save failure during an age update prevented task completion.

### Timeline output
- Non-chronological event entry was appreciated.
- HTML output was clear and visually engaging.
- The save failure prevented full evaluation of the timeline.

## Impact assessment (consolidated)

| Issue                     | Severity | Why it matters                  |
|---------------------------|----------|---------------------------------|
| Story ID terminology      | Medium   | Disrupts onboarding             |
| Attribute meaning unclear | High     | Causes confusion and errors     |
| Non-cumulative attributes | Medium   | Conflicts with user expectations|
| Save failure              | High     | Blocks task completion          |
| Environment assumptions   | Medium   | Raises entry barrier            |
| RPG-centric terminology   | Low      | Narrows audience unnecessarily |

## What worked well
Users responded positively to:
- Guided prompts that supported creativity
- Freedom to invent characters
- Ability to enter events out of order
- Clear and visually appealing HTML output
- Clear signalling that the prototype is an early MVP

## Changes made after testing
Following testing, small usability improvements were implemented:
- Clarified `order_index` prompts
- Blocked invalid attribute inputs
- Improved prompt wording for clarity
- Documented environment assumptions more explicitly

## Conclusion
The prototype effectively demonstrates the core character–timeline concept. Most usability issues stem from terminology, conceptual framing, and setup assumptions rather than interaction flow.

Future iterations could address these concerns more fully as the prototype matures.