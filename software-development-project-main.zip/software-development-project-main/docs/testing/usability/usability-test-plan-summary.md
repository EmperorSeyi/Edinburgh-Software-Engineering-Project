# Usability Test Plan — Story Structure Prototype

## 1. Purpose of the Test
This usability test evaluates whether users can successfully navigate and complete the prototype’s core workflow: creating characters and events, linking them, and interpreting story flow via the timeline and character views. The results will inform prioritised refinements for the MVP.

## 2. Success Criteria
- Users can create and view characters, events, and their links.
- The timeline displays events in the intended chronological order.
- Character profiles show a consistent event history.
- Users can edit and delete entries without confusion.
- Users can locate and use comments or notes.
- Overall user satisfaction is **≥ 4 / 5** on a Likert scale.

## 3. Test Objectives
- Assess how efficiently users navigate between character, event, timeline, and character-view features.
- Validate whether users understand relationships between story elements.
- Identify interface elements that cause confusion or errors.
- Evaluate whether the workflow supports realistic story-building tasks.

## 4. Test Participants
- **Target users:** Writers, narrative designers, role-playing storytellers, creative practitioners, or students.
- **Number of participants:** 5–8 (sufficient to surface major usability issues).
- **Experience level:** Mixed (some familiar with story-structure tools, some not) to assess learnability.

## 5. Test Methodology
- **Type:** Moderated usability test (remote or in-person).
- **Format:**
  - Introduction and warm-up
  - Task-based interaction using a think-aloud protocol
  - Post-test survey
- **Duration:** 30–45 minutes per participant.

## 6. Test Tasks

### Task 1 — Create a Character
- **Goal:** Assess whether users understand the character creation flow.
- **Success indicator:** User creates a character (name, short bio, and tags) without assistance.

### Task 2 — Create an Event
- **Goal:** Test clarity around entering title, timepoint, and summary.
- **Success indicator:** Event is created and appears in the timeline as intended.

### Task 3 — Link a Character to an Event
- **Goal:** Evaluate whether users understand and can apply link types (e.g. presence, knowledge, state change).
- **Success indicator:** Link is created and visible in both event and character views.

### Task 4 — View the Timeline
- **Goal:** Ensure the timeline is readable and correctly ordered.
- **Success indicator:** User identifies earliest and latest events and associated characters.

### Task 5 — View a Character Profile
- **Goal:** Confirm clarity and consistency of the character’s event history.
- **Success indicator:** User can describe character progression across events.

### Task 6 — Edit or Delete an Entry
- **Goal:** Measure how intuitive editing and deletion actions are.
- **Success indicator:** User completes edit or delete actions without confusion.

### Task 7 — Add a Comment to a Character or Event
- **Goal:** Test clarity of the note-taking or comment feature.
- **Success indicator:** User adds, views, and edits a comment successfully.

## 7. Metrics to Collect

### Quantitative
- Task completion rate (%)
- Task time (seconds or minutes)
- Error count (mis-clicks, backtracking, incorrect navigation)
- User satisfaction per task (1–5 Likert scale)
- Overall usability rating (SUS score or equivalent)

### Qualitative
- Think-aloud remarks
- Observed confusion points
- User expectations versus actual behaviour

## 8. Test Materials
- Prototype access link
- Task sheet
- Observation notes template
- Post-test questionnaire (SUS and short custom questions)

## 9. Exit Questions
- How easy was it to learn and navigate the prototype?
- Were any terms, prompts, or buttons unclear?
- Was the timeline easy to interpret?
- Did the character view help you understand story progression?
- What was the most confusing or frustrating part?