# Final Evaluation Report  
**Software Development Project:** Scotch Broth Storytelling Prototype  
**Submission Time:** January 2026

## Table of Contents
1. Introduction  
2. Evaluation of the Prototype vs. Original Design  
3. Evaluation of the Project vs. Original Plan  
4. Testing Outcomes & Key Findings  
5. Lessons Learned  
6. Future Work & Recommendations  
 

---

## Abstract

This report presents a team evaluation of the Scotch Broth software development project commissioned by Creative Transformation Support (CTS). The client’s broader vision is a collaborative, multi-modal storytelling platform for building complex fictional worlds over long timelines; however, given the fixed time and budget constraints of a single-semester course (~200 team hours), the team deliberately prioritised a narrow, end-to-end prototype slice.

The delivered prototype is a Dockerised, CLI-based tool implemented in Python 3.11. It enables users to create characters and events, record attribute changes over time, query a character’s state at a selected point in the timeline, and export the current story state as a static HTML summary. The system is structured into modular layers (CLI, validated domain models, persistence, timeline logic, and presentation), with MongoDB used for persistence to support portability and future extensibility.

The evaluation assesses (1) how well the implemented prototype matches the original design in terms of technology choices, architectural intent, and overall quality; (2) how the project progressed relative to the original plan and constraints; and (3) what testing outcomes indicate about correctness, usability, and limitations. Key findings emphasise strong alignment with the intended architecture and technology stack, alongside process and codebase consistency challenges typical of team development under tight constraints. Finally, the report outlines lessons learned and proposes future work focused on demonstrating product value and usability through a web-based prototype that better supports visual workflows and collaboration.

---

## Authors

| Section Owners | Section |
|---|---|
| Olivia | Introduction (what the project is and what was delivered) |
| Gabriele | Evaluation of the prototype vs design |
| Kangsu | Evaluation of the project vs plan |
| Oluseyi | Testing outcomes & what they showed |
| Cathy | Lessons learned |
| Kangsu | Future Work |

---

# 1. Introduction

This report presents a team evaluation of the Scotch Broth software development project commissioned by Creative Transformation Support (CTS), following the completion of an initial command-line interface (CLI) prototype. After introducing the project context and the delivered prototype, this report will:

Evaluate the submitted prototype against the original design  
Assess how the project progressed relative to the initial project plan  
Summarise testing outcomes and what they demonstrate  
Reflect on lessons learned during development  
Outline potential directions for future work  
Consider how the submission aligns with the assessment criteria  

The project was undertaken for Creative Transformation Support (CTS), whose brief focused on supporting the planning and development of complex fictional worlds over long periods of time. The broader product vision encompassed collaborative, multi-modal storytelling features, including shared world-building, timelines, characters, and future extensibility to additional media formats. Given the fixed time and budget constraints of a single-semester course (200 hours shared evenly among five team members), the team deliberately prioritised a narrow, high-quality prototype rather than attempting to implement a complete system.

The delivered prototype focuses on character development over a timeline and implements a small but complete end-to-end slice of the overall design. Interaction is provided through a command-line interface, allowing users to create characters and events, apply changes that affect character attributes over time, and export the resulting narrative structure as a static summary. The prototype is implemented in Python using validated domain models, persisted via a lightweight database, and fully containerised using Docker to ensure reproducibility and portability for testing and assessment.

The sections that follow evaluate the prototype against the original design, assess project execution against the project plan, analyse testing outcomes, and reflect on lessons learned and potential future work.

---

# 2. Evaluation of prototype vs design

The design of the Scotch Broth prototype aims to meet the client’s requirements (character development over a timeline) and to fit within our chosen narrow scope, prioritizing high quality standards in terms of technology, architecture and codebase. Accordingly, the following sections will evaluate the final prototype against all the three components of the initial design.

## 2.1 Technology
The working prototype shows nearly perfect match with the chosen technology stack (see technology-exploration). It is written using Python3.11 and the five layers (cli, models, persistence, timeline and presentation) deploy the chosen libraries as summarized in the environment files (see environment.yml). Likewise, the whole tool is containerized with Docker as of original design. The persistence (database) underwent minor technology change. In early design stages, we were considering to use simple JSON files to store our story data entities. However, interaction with the client allowed to identify MongoDB as the optimal database solution to be integrated within our architecture.

Pros: Chosen technologies proved to be reliable and stable among different components, no integration, consistency or incompatibility issues in the final prototype.

Cons: No major concerns, in some cases deployment of chosen tools within the codebase (e.g. docker-compose orchestration) was slightly more complex than initially speculated.

Takeaways: Importance of gathering feedback and interacting with the client (specially when it is an expert), difficulty to remain within scope when chosen technologies bring unexpected implementation complexities.

## 2.2 Architecture
The final prototype is generally in good agreement with the architecture (outlined in prototype-architecture-overview.md. The main features are maintained: a command-based user interface (cli layer), three story entities (character, events and changes) with data types validation (models layer) and stored in a Mongo database (persistence layer), a state computation algorithm (timeline layer) and an HTML generated output file (presentation layer), all shipped to end users via Docker. However, some minor features initially included in scope have not been implemented due to lack of time/budget. Examples are a missing single story multi-character timeline visualization feature, per-story characters listing cli feature, per-characters events listing cli feature, a real date/time timeline visualization feature and others.

Pros: Core architecture features were implemented matching original design. No structural, integration or production issues in working prototype. Stable data flow and output generation, no performance concerns.

Cons: Some minor features (in scope) that may improve user experience could not be implemented due to time/budget constraints. While working, integration between the different modules was more challenging than initially estimated (not enough time/budget allocated to code integration tasks).

Takeaways: In future, allocate additional (buffer) time/budget to code integration and testing. Reduce the amount of nice-to-have features in the initial scope. Consider starting with simpler initial modules and, once working, enhance capabilities towards design scope.

## 2.3 Quality
High quality was prioritized in terms of coding standards (including testing), end user documentation, development and version control best practices to meet industry standards, as outlined in coding-standards. The final prototype only partly meets this goal. The code is not entirely homogeneous due to different coding styles among developers. There are some Python classes, not only functions, as of Wilson et al standard. Not all functions perform a single task. Unit tests do not cover all edge cases and, in some cases, they are more integration tests than unit ones. Considering version control, branching has not always been linear and there has not been a clear naming consensus; reviewing prior to merge requests was not always followed by comments and commits did not always clearly reference the related issue. The development process often suffered from different habits and experience, only in part mitigated by refactoring, leading to difficulties in code readability, interpretation and integration. On the positive side, the code respects the design modularization scope, although in some cases the overall volume is bigger than initial estimation. There is extensive error handling and data types validation, to ensure robustness. Documentation, including docstrings, is clear and extensive and covers docs, user guide, developer guide, README files, in-code comments. Bugs and errors were extensively reported and documented via gitlab issues and an automated testing pipeline was implemented using CI/CD tooling.

Pros: Extensive documentation, code follows design modularization, issues report via gitlab.

Cons: Low code homogeneity, non-linear branching, communication between developers not optimal, unit tests not covering all edge cases, Wilson et al guidelines only partly followed.

Takeaways: Optimal and well-established processes among developers are actually more important, and much harder to achieve, than code itself to guarantee high quality output. Continuous reviewing, from early stage development, is also a key ingredient to ensure proper evolution of the codebase and avoid overbudget due to prolonged refactoring campaigns.

## 2.4 Overall summary
The final prototype is overall in very good agreement with the initial design, confirming the reliability and robustness of initial choices. The main strong points rely on the technology stack and architecture of the tool whereas the weaknesses are mostly found in the coding side. However, it is important to highlight that these code issues can be entirely alleviated by means of extensive refactoring rather than re-designing. Likewise, this prototype design can be scaled up to a more complex product by means of the same technique, without involving critical design changes, thus attesting the overall quality of the developed building block.

---

# 3. Evaluation of the Project vs. Original Plan
## 3.1. Constraint
Our team consists of members with no formal technical or software engineering background. At the start of the project, we had limited experience in planning the development in general.

As a result, our primary challenge was not implementing advanced features, but identifying a feasible and reliable way to validate the core idea of the prototype within the given time and skill constraints.

## 3.2. Early Design Decisions
At the early stage, we identified that the most critical risk of the project was not user interface design, but whether:

* Characters, events, and changes could be represented consistently
* Timeline-based state computation could be performed correctly
* Story information could be reconstructed at any point in time
* To reduce complexity, we deliberately chose a command-line interface (CLI) rather than a web-based UI.
  * This allowed us to focus on core logic and data flow rather than frontend development.

Allowed us to focus on logic and data flow rather than frontend development

## 3.3. Initial Plan for Data IO: JSON

Our original plan was to:

* Store characters, events, and changes in local JSON files
* Load and overwrite files on each operation

This approach was chosen because:
* JSON files are easy to understand and inspect
* No additional infrastructure is required

It fit our early mental model of “saving story data”

## 3.4. Change of Plan for Data IO: MongoDB
As the key feature of the product is to solve the following question:

Can multiple users collaboratively construct a coherent story world by defining characters, events, and changes over time, and can the system reliably compute and present that evolving state?

We altered the plan to use MongoDB that helps solve in comparison to JSON:
* Difficulty managing concurrent updates
* Risk of accidental data overwrite
* Inefficient querying for time-based operations
* Increasing complexity as data volume grew

## 3.5. Evaluation

Recognising our own technical limitations encouraged us to focus on consolidating the system’s core logic. This approach provided a stable foundation, enabling us to adjust implementation details when necessary without significant deviation from the original plan.

---

# 4. Testing Outcomes & Key Findings

The following findings are the key outcomes of the usability, model units and CLI smoke testing.

The prototype passed the success criteria set for the usability testing with tangible outputs. Various characters and events were successfully created and linked with timelines.
Although, few issues such as disruptive onboarding due to story ID, confusion due to unclear attributes and unsupported features, save failure, etc, were identified, they are issues commonly associated with a prototype version and will be corrected in the full product implementation.  

We recorded a perfect outcome for the domain model test with a score of 12/12. The test satisfied the success criteria. The identified issues such as initial failures, required dependency and one assertion error were all resolved successfully. 


Finally, some of the limitations of the usability test includes small number of participants, limited integration coverage and functionality constraint due to dependence on external services. However, all of these can be improved upon in the implementation of the full version. 

--- 

# 5. Lessons learned

Despite the challenges, several aspects of the project highlighted effective practices that contributed to early progress and partial successes.


### Early Planning and Collaboration:

**What Went Right:**

The initial stage was going well. Meeting scheduling was smoothing, weekly meetings and meeting facilitator rotation mechanism worked effectively, and almost all team members were engaging, with high attendance and productive discussions, whilst group brainstorming sessions specifically fostered creativity. Also, task breakdown was meticulous, with line-by-line assignments based on individual strengths. This led to a solid prototype design ahead of schedule.

**Where need to improve:**

While the initial planning phase was largely successful, improvements could be made in risk anticipation and contingency planning. Some dependencies between tasks were identified later than ideal, which occasionally caused delays. Introducing earlier risk assessment sessions and clearer documentation of decision rationales could further strengthen coordination. Additionally, encouraging more balanced contributions among team members could enhance inclusivity and idea diversity.


### Implementation Processes:

**What Went Right:**

The prototype emphasized user-centered principles, incorporating wireframes, architecture design and feedback iterations (from our client) that resulted in a practical solution for the development at an early stage. And implementation benefiting from modularized programming, and allowing the software easier to build, understand, test, maintain, and evolve. 

**Where need to improve:**

Although modularized programming improved maintainability and clarity, some modules initially lacked standards and documentation, this made the integration slightly more time-consuming. Establishing stricter coding standards, or, shared design conventions earlier in the development process would improve effectiveness and consistency. 


### Evaluation and Adaptability

**What Went Right:**

During the post-implementation evaluation stage, the team collected valuable data and derived meaningful insights. Unit tests, usability tests, and CI/CD tooling were applied to validate the correctness, stability, and safety of the prototype, as well as its alignment with the client’s requirements.

**Where Improvement Is Needed:**

Although multiple testing approaches were used, some tests were introduced later in the development cycle than optimal (e.g. team member examples). Expanding automated unit and integration/system testing earlier would have helped identify issues sooner and reduced later rework.

In addition, earlier and more explicit consideration of budget and time constraints would have supported better prioritisation. Limited time ultimately restricted deeper fine-tuning, scalability discussions, and the implementation of more robust workflow mechanisms. Addressing these constraints earlier could improve overall project effectiveness in future work.


### Process & Governance Insights

**What Went Right:**

As the project progressed, the team benefited from informal coordination and decision-making structures that helped maintain momentum and resolve ambiguity, particularly as scope and technical complexity increased. The gradual adoption of issue tracking and CI/CD tooling also improved visibility of work and stability of the codebase in later stages.

**Where Improvement Is Needed:**

One key lesson learned is the value of structured walkthroughs at multiple points in the project lifecycle, including early architecture reviews and detailed design walkthroughs before significant implementation effort. This technique was introduced later in the course, after much of the core code had already been written, but would likely have helped identify design inconsistencies and integration issues earlier, reducing refactoring effort.

Similarly, establishing a clear and consistent system for issue tracking and ownership from the outset would have improved coordination and accountability, rather than introducing these practices midway through development. Finally, while an informal leadership structure emerged organically and proved helpful for streamlining decisions, explicitly defining a coordination or project-lead role earlier could further improve efficiency and clarity in future team projects, without detracting from collaborative contribution.

---

# 6. Future Work & Recommendations

## 6.1. Reframe as the Website Prototype

Current CLI prototype proves technical feasibility. Whereas, a website prototype should prove product value and usability.

Users might well cherish in the website-format prototype in :
- Intuitive usability
- Collaboration
- Instant visualisation

, but not in:
- Full scalability
- Perfect performance
- Complete feature set

It helps the client
* practically see how teams would actually use this
* imagine onboarding writers / students / creators
* decide in 
  * Buy-in from non-technical stakeholders
  * Budget approval
  * Roadmap discussions

Core functions would be such as following.

## 6.2 Visual Story Workspace

What to include

* A main screen showing:
  * Characters
  * Events
  * Timeline (linear or branching)

Why
* Story building is inherently visual
* Users think in relationships and sequences, not input fields

Benefits
* Users: Instantly understand the story state
* Client: Can see differentiation from plain document tools

## 6.3 Structured Input Forms (Instead of Free Text)

What to include

Forms for:
* Character creation (name, role, traits)
* Event creation (time, description, involved characters)
* Dropdowns / autocomplete for existing entities

Why
* Prevents messy or inconsistent data
* Matches how non-technical users expect to interact

Benefits
* Users: Faster input, fewer mistakes
* Client: Cleaner data → easier future features

## 6.4 Team Collaboration Basics (Minimal but Visible)

What to include
* Multi-user login (even fake/demo accounts)

Indicators like:
* “Alice added this event”
* “Bob edited this character”

Why
* The platform’s core value is collaborative storytelling
* Even simple attribution creates trust

Benefits
* Users: Feel ownership and teamwork
* Client: Clearly demonstrates collaboration value to stakeholders

## 6.5 Real-Time or Near-Real-Time Feedback

What to include
* Auto-refresh or “Update Story” button
* Basic change notifications

Why
* Makes collaboration feel alive
* Avoids “submit and wait” UX

Benefits
* Users: Engaging, game-like experience
* Client: Stronger emotional impact in demos

## 6.6 Timeline Navigation & Filtering

What to include
* Filters by:
  * Character
  * Time range
  * Event type
  * Click an event → highlight related characters

Why
* Stories get complex very quickly
* Navigation is essential, not “nice to have”

Benefits
* Users: Can manage complex narratives without confusion
* Client: Shows scalability potential without building everything now

---


The End.