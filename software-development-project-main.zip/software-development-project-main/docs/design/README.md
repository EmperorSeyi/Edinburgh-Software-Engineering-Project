# 🧩 Design Documentation Overview

This directory contains the **design documentation** for the *Scotch Broth* software development project.

The documentation is organised to clearly separate:

- the **implemented MVP prototype**, and  
- the **future product vision**,  

in line with the project’s **scoped, prototype-first approach**.

---

## ✅ MVP Design (`design/mvp/`)

These documents define the **scope, requirements, and architecture** of the implemented
CLI-based MVP prototype.

- [`mvp-requirements.md`](mvp/mvp-requirements.md)  
  Defines the official MVP scope, functional requirements, constraints, success criteria,
  and traceability to user stories.

- [`prototype-architecture-overview.md`](mvp/prototype-architecture-overview.md)  
  Describes the MVP’s layered architecture, core timeline logic, data model, and key
  technical design decisions.

- [`mvp.png`](mvp/mvp.png)  
  High-level diagram showing the overall MVP structure and components.

- [`timeline-function-architecture.png`](mvp/timeline-function-architecture.png)  
  Detailed diagram illustrating the **timeline and state-computation logic**, which forms
  the core value of the MVP.

---

## 🚀 Future Design Vision (`design/future/`)

These documents describe how the MVP could evolve into a **full, collaborative,
web-based storytelling platform**.

They are **not implemented** as part of the MVP and are kept separate intentionally
to avoid scope confusion during assessment.

- [`future-architecture-overview.md`](future/future-architecture-overview.md)  
  High-level future system architecture and conceptual user workflows, with explicit
  rationale and clear MVP boundaries.

- [`epic-user-stories.md`](future/epic-user-stories.md)  
  Full-product epics and user stories that inform long-term design decisions and MVP
  scoping.

---

## 💡 Ideation (`design/ideation/`)

Early-stage design thinking and brainstorming material used during **requirements
exploration**.

- [`product-brainstorming.md`](ideation/product-brainstorming.md)  
  Initial conceptual notes and idea exploration.

---

## 🔁 Design Traceability

The design documentation follows a clear and intentional progression:

**Epic User Stories**  
→ **MVP Requirements**  
→ **MVP Architecture**  
→ **Prototype Implementation**

Future design materials are intentionally separated to ensure the MVP remains
**clearly scoped, testable, and assessable**.

---

## 🎨 UX & Interaction Design

User experience (UX) rationale, future interaction design, and wireframes are
documented separately to avoid conflating **design intent** with **prototype
implementation**.

→ See [`docs/ux/`](../ux/)