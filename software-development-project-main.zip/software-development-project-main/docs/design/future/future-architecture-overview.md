# 1. Future Architecture Overview (High-level)

> This document describes a **future web-based system vision** for the Scotch Broth product.
> It is intentionally **not implemented** as part of the MVP due to time, budget, and scope constraints.
> The purpose of this document is to demonstrate how the current CLI-based prototype
> could evolve into a collaborative, multi-user platform without requiring a fundamental redesign.

For the architecture of the implemented MVP prototype, see:
→ [Prototype Architecture Overview (MVP)](../mvp/prototype-architecture-overview.md)

*	Frontend server: Django templates or Django + React, containerized
*	DB: MongoDB Atlas (cloud)
*	CI/CD: GitHub Actions deploys updated Docker images to the cloud
*	Users interact via web browser → frontend → backend → DB

<p align="center">

![Future system architecture](./Overall_Architecture.png)

</p>

## Relationship to MVP Architecture and UX Documentation

This document focuses on the **future technical architecture** of a web-based
Scotch Broth system (components, data flow, and deployment).

- The **implemented CLI-based MVP architecture** is documented separately in:
  → [`docs/design/mvp/prototype-architecture-overview.md`](../mvp/prototype-architecture-overview.md)

- The **future user experience and interaction design** for the same system is
documented in:
  → [`docs/ux/`](../../ux/)

These documents describe a single future product vision from complementary
technical and UX perspectives, while keeping the MVP scope clearly defined.


2. Conceptual User Workflows (Future System)

The following workflows are illustrative and conceptual.
They are not API specifications and are intended to communicate
interaction flow rather than implementation detail.

## 2.1. User logs in
*	User enters login info on the frontend (Django page).
*	Frontend sends a login request to the backend authentication service.
*	Backend checks credentials in MongoDB → users collection.
*	If correct: Backend issues a JWT token (or session cookie).
*	Frontend stores token in(session cookie, or local storage)
*	Future requests include that token → user stays logged in.

## 2.2. User creates a story
*	UI shows “Create story” form (title, tags, genre, etc.).
*   User submits → Frontend sends a request to create a new story.
*	Backend validates the token → identifies the user.
*	Backend inserts a new document in:
*	Backend returns story ID → frontend redirects to editor page.

## 2.3. User chooses a story from accessible stories
*	Frontend queries backend with GET.
*	Backend queries MongoDB
*	Backend returns a list of stories.
*	Frontend displays them.
## 2.4. User views the written story (timely, multi-character, scripts)
*	Frontend requests.
*	Backend fetches relevant story data (characters, events, timelines).
*	Backend returns JSON to frontend. (story metadata, all characters, all scripts, sorted by timestamp)
*	UI renders. (Character list, Script timeline, Scene/keyframe-based layout)
*		
## 2.5. User saves a working story
*	UI sends a request to save changes to the current story.
*	Backend inserts document into story_scripts.
*	Backend returns success.

## 2.6. User logs out
*   Frontend sends a logout request → backend invalidates the session token.
*	Or simply deletes JWT in browser.
*	User redirected to login page.

This architecture reflects the client’s long-term goals for collaborative,
multi-user storytelling while intentionally deferring implementation to
focus the MVP on validating core timeline logic.

