# 🧩 Epic User Stories — Scotch Broth (Full Product Vision)

**Version:** Markdown conversion from original XLSX  
**Purpose:** Provide traceability between epics → user stories → requirements → MVP decisions.

---

## Epic 1 — Character Management

### User Stories
- **Create Character**  
  *As a user, I want to create a new character with a name, bio, and tags so that I can begin building my story’s cast.*

- **Edit Character**  
  *As a user, I want to update a character’s name, bio, or tags so that I can refine or correct their information.*

- **Tag Management**  
  *As a user, I want to assign or remove tags from characters so that I can categorise them (e.g., “antagonist”, “ally”).*

- **View Character Details**  
  *As a user, I want to view a character’s full profile so I can quickly understand their role in the story.*

---

## Epic 2 — Event Management

### User Stories
- **Create Event**  
  *As a user, I want to create new events with a title, timepoint, and summary so I can build the story timeline.*

- **Edit Events**  
  *As a user, I want to modify event details so I can improve the accuracy of my narrative.*

- **Sort Events**  
  *As a user, I want events to automatically order themselves by timepoint so the timeline stays coherent.*

- **Add Event Metadata**  
  *As a user, I want to add optional metadata (e.g., location) so events have richer context (future-ready).*

---

## Epic 3 — Character–Event Linking

### User Stories
- **Character–Event Link**  
  *As a user, I want to associate a character with an event so I can indicate who was involved.*

- **Create Link Type**  
  *As a user, I want to specify how a character interacts with an event (presence, knowledge, state change) so that the story logic is clear.*

- **Update Link**  
  *As a user, I want to update or delete a character–event link to reflect corrections in the story.*

---

## Epic 4 — Timeline View

### User Stories
- **Visual Timeline**  
  *As a user, I want to see a chronological list or visual representation of all events so I can understand story flow.*

- **Link Characters on Timeline**  
  *As a user, I want each event in the timeline to show associated characters so I can quickly see who is involved.*

- **Navigate Timeline**  
  *As a user, I want to scroll or move through the timeline so I can explore story progression easily.*

---

## Epic 5 — Character View

### User Stories
- **View Character Archive**  
  *As a user, I want to see a list of events connected to a character in chronological order so I understand their journey.*

- **Highlight State Changes**  
  *As a user, I want state-change events to be emphasised so I can track how the character evolves.*

- **Open Event from Character View**  
  *As a user, I want to click an event in the character arc and open its details so navigation is smooth.*

---

## Epic 6 — Commenting System

### User Stories
- **Add Comment**  
  *As a user, I want to add a comment to an event or character so I can store ideas or reminders.*

- **Edit Comment**  
  *As a user, I want to update my notes to keep them accurate.*

- **Personal Comments**  
  *As a user, I want comments designed for personal use so the system remains simple.*