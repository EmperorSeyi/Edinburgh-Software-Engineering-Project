# 🌍 Resources & Inspiration

A collection of existing tools and platforms that inspired the **Creative Transformation Support (CTS)** project design.  
These examples illustrate how current world-building, storytelling, and collaboration systems approach creativity and teamwork.

---

## 🧩 World-Building & Story Development Tools

| Tool | Description | Key Features / Relevance |
|------|--------------|--------------------------|
| **World Anvil** | A platform for writers and RPG creators to build and manage fictional worlds. | Timelines, characters, geography, articles, map integration, and collaboration. |
| **Campfire Write / Campfire Blaze** | Modular tool for writers to develop stories and worlds. | Character sheets, relationships, maps, timelines, and story structure management. |
| **Plottr** | Visual outlining tool for novelists. | Drag-and-drop timelines, scenes, and character arcs. Great for timeline visualization ideas. |
| **Scrivener** | Professional writing software used by novelists and screenwriters. | Document organization, research notes, hierarchical project structure. |
| **Notebook.ai** | Online AI-assisted worldbuilding and character tracking tool. | Supports characters, universes, items, and interlinked information. |
| **Twine** | Open-source tool for creating nonlinear interactive stories. | Story nodes, branching logic, visual mapping — useful for narrative structure ideas. |

---

## 🤝 Collaboration & Creative Workflow Platforms

| Platform | Description | Key Features / Relevance |
|-----------|--------------|---------------------------|
| **Miro** | Online collaborative whiteboard for teams. | Visual brainstorming, system mapping, live collaboration, zoom-based presentation mode. |
| **Notion** | Workspace for documentation, notes, and collaboration. | Databases, templates, version control, integrated content management. |
| **Figma / FigJam** | Design and collaboration platform with interactive prototype mode. | Visual interface design, wireframes, collaborative editing, real-time commenting. |
| **Google Docs / Sheets** | Real-time collaborative editing tools. | Version control, live comments, simultaneous co-authoring. |
| **Milanote** | Visual board tool for organizing creative projects. | Image boards, notes, and creative moodboard layouts. |
| **Pitch** | Modern collaborative presentation platform. | Clean visual design and live editing — good for project storytelling. |

---

## 💡 Key Takeaways

- Most **world-building tools** (e.g., World Anvil, Campfire, Plottr) focus on **individual creators**, not multi-user collaboration.  
- **Collaboration platforms** (e.g., Miro, Notion, Figma) excel at teamwork but lack narrative-specific structure.  
- The **CTS project** aims to **bridge these gaps** — combining storytelling depth (characters, timelines, world logic) with collaborative flexibility and feedback.


# Our Ideas

**Olivia:** 
- ability to leave comments on people's work
- different views: timeline view, vs. character view, vs. map view? (obviously not all for prototype--some just in larger design)
- give each user a little personality (e.g. icon, username) to make it personalized. also maybe they get collab points for the more they contribute, including commenting on other people's ideas?
- make sure it can handle multimedia inputs (e.g. photos, text, audio clips, video, etc.)
- maybe when you zoom on a character it creates like a web map around them with these different aspects, or can you change to list view to just see their attributes categorized by audio, visual, story, etc.
- make it visually appealing even as a base. so each little character that's created is automatically given a colorful or random design (ngl I think fortnite haha) until customized (using ai?)
- when you log in, there are different "spaces" you have access to, each with a different team. e.g. if you have multiple projects with different teams.
- i can get creative, but i think it's more important to ask: technically what's feasible? or, we create a design, and then decide scope based on technical feasibility?
- should we do some kind of interview or focus group discussion? i have several creative friends that i could run these ideas by them if we wanted but not sure if that's in project scope.
- name idea: storyboarder, splash, arthub, michelangelo, davincia

**Kangsu:** 
- enables working individually and collaboratively.
- enables versionings
- enables the security setting(public as well as private)

**Oluseyi:** 
- database that stores 
- table for each story
- link tables together, to make what we need (relational database-JSON?)

**Cathy:** 
- web-browser based application, and to be compatible on mobile-end (need to confirm a bit)
- "inconsistency alert" (for the story plots) built-in function?
- suggest the spiral model as project development method (having more spaces for changes and risk management)
- how to present the "tutorial" function? A note for the end user
- need to have a feature list of the application

**Gabriele:** 
- started from technical point of view (great! balancing out olivia lol)
- needs to be python
- CLI (command-line user interface), JSON file initial info about characters e.g. id, attributes, behavior, HTML output for visual timeline.
- Note: Potential workflow outline in Prototype_Scope.md


---

> 📝 *This list is for inspiration and reference only — it’s not exhaustive but highlights features and design patterns relevant to CTS’s goals.*
