# 🧩 MVP Requirements — Scotch Broth Prototype (v0)

**Last updated:** 07 Jan 2026  
**Owner:** Olivia Heale  
**Status:** Reviewed

The MVP implements a small, high-quality, end-to-end slice of the broader CTS
storytelling platform. It demonstrates the core narrative engine: how characters
evolve over time through events.

This MVP directly corresponds to:

- [MVP Architecture Overview](prototype-architecture-overview.md)
- [Epic User Stories (Ideation)](../future/epic-user-stories.md)

The goal is to build only the essential foundation approved by the client and that
fits within the chosen narrow scope and high-quality focus, given time and budget
constraints.

---

## 1. 🎯 Purpose of the Prototype

The MVP must demonstrate:

- ✔️ Creating characters  
- ✔️ Creating events  
- ✔️ Applying changes to characters over time  
- ✔️ Linking events to characters  
- ✔️ Computing character “state at time T”  
- ✔️ Rendering a chronological timeline  
- ✔️ Exporting a static HTML summary  

This aligns with the client’s top priorities:

- Character development  
- Timelines  

(Confirmed in client meetings on 23 Oct, 29 Oct, 5 Nov, 27 Nov.)

---

## 2. 🔧 Functional Requirements

All features must be implemented via a Python Typer CLI, backed by MongoDB,
following the architecture described in
[prototype-architecture-overview.md](prototype-architecture-overview.md).

---

### 2.1 Character Management

**Why:** Characters are the core narrative entities. Everything else builds on them.

The system must allow:

- Create character (name, bio, optional tags)
- View character
- Edit one character’s attribute
- List all characters

**Constraints:**

- No images, roles, or relationships  
- No collaboration logic  

---

### 2.2 Event Management

**Why:** Events anchor the timeline and determine how characters evolve.

The system must allow:

- Create event (title, order index, summary)
- Print events in a story
- Automatic chronological sorting

**Constraints:**

- No multimedia, locations, maps, branching timelines  

---

### 2.3 Character–Event Linking

**Why:** Links define who is involved in each event, enabling state computation.

The system must allow:

- Link character to event
- Optional simple descriptor (e.g. “present”, “state-change”)

---

### 2.4 Timeline Computation

**Why:** This is the core value of the entire MVP.

The system must:

- Apply changes to characters in chronological order
- Compute character’s state at any “time T”
- Provide chronological view of a character’s arc

**Optional support for queries such as:**

- “What has changed so far?”  
- “What does this character know at event X?”  

---

### 2.5 Static HTML Export

**Why:** Client needs a portable, readable view without running code.

The system must:

- Generate a static HTML summary page containing:
  - One character
  - All events
  - Final timeline including attribute changes
- Use Jinja2 templates

**Constraints:**

- No PDF / EPUB  
- No interactive UI  
- Minimal styling  

---

## 3. ⛔ Out of Scope (Not Included)

To avoid scope creep:

- User accounts, authentication, roles  
- Collaboration, comments, real-time updates  
- World maps, location models, multimedia  
- Storyboards, scene graphs  
- Full web UI  
- Advanced exports  
- Notifications  
- AI features  

**Full product vision:**  
→ [Future Web Architecture (Not MVP)](../future/future-web-architecture.md)

---

## 4. 🧱 Technical Requirements

| Component | Choice        | Rationale                              |
|---------|---------------|----------------------------------------|
| Language | Python 3.x    | Team skillset & maintainability        |
| Models  | Pydantic v2   | Validation + clean domain layer        |
| CLI     | Typer         | Simple UX, auto `--help`               |
| DB      | MongoDB       | Flexible schema for evolving data      |
| Export  | Jinja2        | Lightweight static HTML                |
| Deploy  | Docker        | Reproducible development               |

**Reference:**  
→ [prototype-architecture-overview.md](prototype-architecture-overview.md)

---

## 5. ✔️ Success Criteria

The MVP is considered successful if:

- Users can create characters, events, and links via CLI without errors  
- Timeline ordering is correct  
- State computation produces correct results during testing  
- HTML export works on a clean machine within 10 minutes setup  
- Usability testers can complete core tasks without guidance  
- Code quality aligns with architecture and best practices  

---

## 6. 🔗 Traceability to User Stories

| MVP Feature              | Epic → User Story                  |
|-------------------------|------------------------------------|
| Create character        | Epic 1 — Character Management      |
| Edit character          | Epic 1                             |
| Create event            | Epic 2 — Event Management          |
| Order events            | Epic 2                             |
| Link character ↔ event  | Epic 3                             |
| View timeline           | Epic 4                             |
| Character arc view      | Epic 5                             |
| Basic comments (opt.)   | Epic 6 (subset)                    |
| HTML export             | Internal MVP requirement           |

**User stories:**  
→ [epic-user-stories.md](../future/epic-user-stories.md)

---

## 7. 🧭 Assumptions & Dependencies

- Single-user environment  
- No login or authentication  
- Small dataset (course project scale)  
- All features accessed via CLI  
- HTML is static (non-interactive)  
- Docker available for testing  

---

## 8. 🧨 Risks & Mitigation

| Risk                              | Impact | Likelihood | Mitigation                    |
|----------------------------------|--------|------------|-------------------------------|
| Scope creep                      | High   | Medium     | Strict MVP definition         |
| Code/design misalignment         | Medium | Medium     | Weekly reviews                |
| Timeline logic ambiguity         | Medium | Medium     | Clarified in architecture docs|
| Confusion around linking model   | Medium | Low        | Examples + tests              |

---

## 9. 📎 Related Documents

- [MVP Architecture Overview](prototype-architecture-overview.md)  
- [Future Web Architecture (Not MVP)](../future/future-web-architecture.md)  
- [Epic User Stories](../future/epic-user-stories.md)  
- [Product Brainstorming](../ideation/product-brainstorming.md)