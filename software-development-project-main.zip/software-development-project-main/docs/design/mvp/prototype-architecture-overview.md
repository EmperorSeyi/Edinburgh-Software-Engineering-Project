# Prototype Architecture Overview (MVP – Scotch Broth)

**Project:** Creative Transformation Support (CTS) – “Scotch Broth”
**Focus:** Character development over timelines (MVP)
**Last updated:** 2026-01-02

---

Note: This document describes the **implemented MVP architecture only**.
The broader, future-facing system architecture is documented separately in:

→ [Future Architecture Overview](../future/future-web-architecture.md)

## 1. MVP Scope (Milestone 2 → Final)

For the prototype, we are focusing on a **narrow, end-to-end slice**:

- Manage **characters**
- Manage **events** linked to characters
- Show a **per-character timeline** of events
- Export the current state to a **static HTML summary**

Out of scope for the MVP:

- User accounts / auth / roles
- Real-time collaboration
- Rich web UI / SPA
- Plagiarism / similarity detection
- Maps, media, or non-textual assets

---

## 2. High-Level architecture

* **A: Application Layer:** Command line-based user interface (CLI)
    - Project management commands                       
    - Character/Event/Change operations                 
    - Timeline queries and export

* **B: Domain Layer:** Data models.
    - Character, Event, Change entities                 
    - Validation and type safety       

* **C: Persistence Layer:** Lightweight storage database (MongoDB).
    - MVP: Simple synchronous pymongo                          
    - Final product: Asynchronous SQL-based aenterprise solutiuon    

* **D: Timeline Layer:** Core business logic and algorithm implementation 
    - State computation at time T                       
    - Changes/events aggregation and ordering                   
    - Temporal query resolution 

* **E: Presentation Layer:** Static HTML export with a simple timeline visual and character sheets.
    - Timeline visualization                            
    - Character sheets with attribute evolution     

* **F: Docker Containerization:** To ensure full MVP reproducibility and portability..
    - Docker volume for the database (persistence)
    - Dockerfile for the Python MVP framework

**Reasoning: This end-to-end slice outlines design depth while keeping implementation small, in line with the MVP scope. A modular approach based on different layers is in agreement with the guidelines of Wilson et al ([see](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/software/coding-standards.md?ref_type=heads)) and critical to allow the implementation of the different prototype features. Indeed, this solution is optimal for future improvement or scaling up of specific features, refactoring and redesigning without affecting other core features.**

---

![Prototype architecture diagram](mvp.png)

## 3. Component Details

**Note:** details and reasoning for each technology choice is provided [here:](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/software/Technology-exploration.md?ref_type=heads) 

### A. Application Layer (CLI)

**Responsibilities**

* Provide user-facing commands for all operations
* Coordinate between domain, persistence, and timeline layers
* Validate user inputs - error handling of invalid inputs
* Provides a simple visual summary of the generated timeline

**Chosen Technology:** Typer

**Design Principles:**
1. **Progressive/procedural flow:** Basic commands simple, advanced options via flags
2. **Consistency:** All commands follow verb-noun pattern
3. **Discoverability:** `--help` at every level
4. **Error handling:** Always confirm actions with output and prevent wrong input types without crashing

**CLI Layer dependencies:**

* Persistence Layer (storage operations): MongoDB reads/writes
* Timeline Layer (query operations): State computation
* Export Layer (presentation generation): HTML rendering


**Reasoning: A simple command line-based UX fits with the prototype scope,  the team's skillset and the client's requirements. This layer allows the end user to easily create their own stories and to get a visual summary output.**

---

### B. Domain Layer & Data Model

**Responsibilities**

* Define core entities: `Character`, `Event`, `Change`
* Enforce data validation and type safety
* Provide serialization/deserialization for persistence
* Remain persistence-agnostic and UI-independent

**Chosen Technology:** Pydantic v2

**Key Models:** Example of basic structure

```python
# Character: Represents a story character
class Character(BaseModel):
    id: Optional[ObjectId] = None
    name: str
    bio: str
    created_at: datetime
    initial_attribute1: Any  # Starting state1() data type depends on attribute
    initial_attribute2: Any  # Starting state2() data type depends on attribute

# Event: A point in the timeline
class Event(BaseModel):
    id: Optional[ObjectId] = None
    name: str
    order_index: int  # For temporal ordering
    timestamp: Optional[datetime] = None  # Optional real-world time
    description: str

# Change: Records attribute modifications at a given event
class Change(BaseModel):
    id: Optional[ObjectId] = None
    character_id: ObjectId
    event_id: ObjectId
    attribute_name: str
    new_value: Any # depends on attribute data type
    operation: Literal["set", "increment", "append"]  # depend on attribute data type
```

**Scope:** for the mvp we set to create a timeline based on 1 character, 2 events and 2 (same or different) attribute changes, for a timeline composed of 3 states (Initial, event1 and event2).

**Reasoning: Pydantics data models is an industry standard data type validation approach that aligns with the client's requirements of a character development over a timeline mvp. This layer is critical for critically organizing the chose data dypes and story entities (characters, events and changes) to allow a proper integration with the other layers.** 


---

### C. Persistence Layer (Storage)

**Responsibilities**

* Store and retrieve Characters, Events, and Changes
* Maintain data integrity and referential consistency
* Support efficient timeline queries
* Provide portability through containerization

**Chosen Technology:** MongoDB

**Data Model (Collections Structure):**

MongoDB will have three collections:

```
persistency layer (database)
  ├── characters (collection)
  ├── events (collection)
  └── changes (collection)
```

**Data Portability:**
- MongoDB data files are binary (not human-readable)
- Docker volumes ensure consistency across environments
- JSON export available for review/debugging

**Reasoning: a simple Mongo database based on pymong is the most suitable choice to store story entities: it is simple, it integrates well with the other Python-based layers and it is portable via Docker. This database can also be easily customized and scaled up for the final product, introducting asynchronous data fetching strategies to align with the collaborative storytelling requirement of the client.**

---

### D. Timeline Layer (Core Business Logic for MVP)

**Responsibilities:**
- Compute character state at any point in the timeline
- Aggregate changes in correct temporal order
- Handle edge cases (no changes, overlapping events, etc.)

**Conceptual Approach:**

The timeline layer provides the **core value** of the prototype: answering "What did Character X look like at Event Y?"

**Simple State Computation Algorithm (Conceptual Flow):**

```
INPUT: character_id, target_event_order
OUTPUT: computed_state (attribute dictionary)

PROCESS:

$ scotch-broth-prototype init                                       # connect to MongoDB
$ scotch-broth-prototype timeline query character_id --at-order 10  # query chatacter at given time

1. Fetch initial state:
    - Retrieve character document
    - Copy initial attribute(s) as initial point 

2. Query applicable changes                     
    - Join changes with events (get order_index) 
    - Filter: event.order_index ≤ target         
    - Sort by event.order_index (ascending)  

3. Apply changes sequentially                   
    FOR EACH change IN sorted_changes:          
    - Apply operation to state                 
    - (set/increment/append)      

4. Return computed state                        
    - Final attribute dictionary 

```

**Data Flow Diagram:**

![Timeline logic flow diagram](timeline-function-architecture.png)

**Key Design Decisions:**

* Temporal Ordering Strategy:
    - **Primary:** Integer `order_index` or 'time_index' field on events
    - **Rationale:** Simple, explicit, user-controlled ordering
    - **Limitation:** different Events at same index affecting the SAME ATTRIBUTE have undefined order (acceptable in scope for MVP)
    - **Alternative considered:** Real-world timestamps (adds complexity, sophisticated story logic, out of scope for mvp)

* Immutable Stories:
    - **Primary:** Changes are never updated or deleted - rather, they are appended
    - **Rationale:** Easier to implement, no user/story conflicts, all changes are kept (story issue tracking), timeline is reproducible
    - **limitations**: Requires more storage, can be confusing if same change has many modifications
    - **Alternative considered:** mutable changes, adds coding complexity (if time permits)

**Reasoning: This simple algorithm based on integer events ordering allows to create a basic three points timelines with different characters attributes, aligning with the narrow scope of the prototype and with the client's requirement. Many more features can can be implemented in this layer, including real time ordering-indexing, multi-characters stories and reversible (mutable) changes om existing stories. We set to limit events indexing to a range of 1-10 for the sake of maximum simplicity; as we are using an agile development approach, the goal is to get a working prototype at an early stage so that to add/improve features at a latter stage according to bugs, usability and scope.**

---

### E. Presentation Layer (Static HTML Exporter)

**Responsibilities:**
* Generate a single-page HTML timeline visualization
* Display character attribute evolution
* Provide portable demo artifact for client and testers

**Chosen Technology:**
* **Jinja2:** Template rendering engine

**Reasoning: the presentation layer is the output generation component of the prototype architecture. It feteches the timeline dictionary data generated  from layer D and generates a static HTML file that can be opened and visualized with any browser. This is meant to showcase the capabilities of the mvp to the client, i.e. how our tool can evolve a character over a user-defined timeline of events. The choice of an HTML file is meant to allow future scalability towards a web-based collaborative storytelling product, so that to limit the amount of refactoring and avoid redesigning of the core structure of the tool.**

---

## F. Docker Containerization for Portability

**Scope:** 

* Package the MVP prototype with MongoDB in a reproducible, portable environment that works on the EIDF VM and reviewers' machines.

### Architecture

```
docker-compose.yml
    ├── sctch-broth-prototype  (Application container)
    │   - Python CLI (official python 3.11 image)
    │   - Dependencies Dockerfile (environment.yml file exported from developers' miniforge env)
    │   - Source code
    └── mongodb          (Database container)
        - MongoDB (official mongoDB image)
        - Persistent volume for data
        - Exposed on localhost:27017 (standard port)
```

- **Application Container:** Dockerfile (custom image with source code) + docker-compèose.yml (configure)
- **Database Container:** docker-compose.yml (configure only)
- The docker-compose.yml file also contains the configuration to orchestrate the two containers. More info on this can be found [here:](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/software/developer-guide.md?ref_type=heads).

**Reasoning: containerization is an industry gold standard to allow reproducibility and portability of dev environments. Docker is an optimal choice according to the team's skillset to easily spin up in a basic Python environment all libraries and dependencies that have been created in the shared conda environment to develop the prototype in the VM. In this way, we prevent any complexities related to a local installation of our conda environment as well as any multiple Python related issues. The main shortcoming of having such an isolated containerized environment is that the Mongo database is always local, meaning that any story data generated elsewhere will not be present when working on a different machine.**

## User interaction and MVP workflow (CLI)

The MVP is operated via Typer CLI commands in a simple, procedural flow:

1. Create a character (name, bio, optional attributes/tags)
2. Create events (title, order_index, summary)
3. Link characters to events and record changes
4. Query a character’s state at time T (by event/order)
5. Export a static HTML summary for review

Note: Editing/deletion is intentionally limited in the MVP (see mvp-requirements.md scope constraints).