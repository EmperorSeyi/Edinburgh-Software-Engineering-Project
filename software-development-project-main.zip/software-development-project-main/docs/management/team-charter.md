# 🥣 Scotch Broth – Team Charter

**Project:** Creative Transformation Support (CTS)  
**Course:** Software Development (2025–2026), MSc DSTI    

---

## 🎯 1. Purpose

This charter defines how our team collaborates, communicates, and manages development to deliver a high-quality MVP: a narrative engine that supports character creation, temporal changes, and timeline reasoning.

Our structure is designed to handle:
- evolving client requirements  
- technical uncertainty (timeline logic + data model)  
- distributed time zones  

---

## 👥 2. Team Roles & Responsibilities (with rationale)

### 2.1 Summary Table

| Role | Name | Key Responsibilities | Why this role matters |
|------|------|----------------------|------------------------|
| **Project Manager & CLI Lead** | **Olivia Heale** | Planning, milestones, repo structure, CLI/app layer, integration, progress tracking | The CLI orchestrates all components; strong PM/CLI leadership keeps the system coherent and the team aligned. |
| **DevOps & Data Model** | **Gabriele Dalla Torre** | Env setup (Docker/env), repo scaffold, data model co-design, code review, integration support | Stable infrastructure and a consistent data model reduce integration risk across time zones. |
| **Backend & Persistence** | **Kangsu Lee** | MongoDB repo layer (CRUD), schema alignment, backend integration, timeline logic contributor | Centralising DB ownership prevents schema drift and ensures reliable state management. |
| **UX & Presentation** | **Cathy Xia** | Wireframes, UX flows, HTML export (Jinja2 templates), usability input | MVP success depends on clear workflows and understandable output for users. |
| **Testing & Risk Management** | **Oluseyi Olaniyi** | Test Plan and strategy, Risk Register, process documentation, evaluation support | Dedicated focus on testing and risk is essential given complex timeline logic and distributed development. |

---

## 🧭 3. Development Model (Agile, Iterative)

The project followed a **lightweight Agile development approach**, using **iterative
cycles aligned to milestone deliverables**. This model was appropriate given the
project’s exploratory nature, evolving client understanding, and fixed academic
time and budget constraints.

Key characteristics of the approach included:

- Incremental development of a working prototype
- Regular review and refinement of scope
- Early validation of technically complex components (e.g. timeline logic and data model)
- Continuous integration and testing via GitLab

Weekly team meetings and GitLab Issues/Merge Requests were used to plan work,
track progress, and incorporate feedback. Technical uncertainty was addressed
through early experimentation and iterative refinement rather than upfront
over-design.

This Agile, iterative approach supported steady progress while allowing the team
to adapt to emerging insights from development and client interaction.

---

## 📡 4. Communication & Collaboration

**Channels**
- **Microsoft Teams:** weekly calls, client meetings, urgent messages  
- **GitLab Issues & MRs:** task tracking, async updates, decision log  
- **`/docs` folder:** structured documentation and minutes  
- Optional: Google Docs / Figma for early sketches

**Expectations**
- Notify the team at least **24 hours in advance** if you cannot attend a meeting.  
- Summarise important calls in `/docs/minutes`.  
- Use `@mentions` in GitLab only when a response or review is needed.  

**Typical response times**
- Urgent (blocking/client-critical): ≤ 24 hours  
- Normal: 1–2 days  
- Low priority/FYI: by the next scheduled meeting  

**Conflict resolution**
1. Discuss privately and respectfully with the person involved.  
2. If unresolved, raise it in a team meeting.  
3. If still unresolved, escalate to the course organiser (Alistair).  

These norms help avoid miscommunication and keep collaboration professional across time zones and backgrounds.

---

## 🔄 5. Workflow & Decision-Making

- **Weekly full-team meeting (~1.5 h):** planning, review, decisions.  
- **Ad-hoc dev syncs:** for integration or debugging as needed.  
- **Client meetings:** scheduled to clarify requirements and validate direction.  
- **GitLab workflow:** Issue → Branch → MR → Review → Merge.

**Decision process**
- Aim for **consensus** on major design/scope decisions.  
- Document decisions in meeting minutes and/or linked GitLab Issues.  
- If consensus cannot be reached, the **Project Manager (Olivia)** makes the final decision after consulting relevant leads.

This balances shared ownership with clear accountability so the project can keep moving.

---

## 🧪 6. Quality, Testing & Risk

- Automated tests live in `tests/`.  
- Test Plan, usability scripts, and summaries live in `/docs/testing`.  
- A **Risk Register** is maintained and reviewed periodically.  
- Merge Requests require at least one peer review before merging.

Because the timeline logic and data model are central and non-trivial, this structure helps catch regressions early and reduces integration surprises.

---

## 🤝 7. Team Values

We commit to:
- Respectful, inclusive, and professional communication  
- Transparency about progress, blockers, and capacity  
- Supporting each other’s learning goals and skill development  
- Maintaining healthy boundaries (no expectation of out-of-hours replies)  
- Protecting client confidentiality and using only agreed tools

---

## ✍️ 8. Maintenance

This charter is reviewed at each milestone or when major process changes occur.  
Updates require agreement from all team members.

_Last revised: 22 Nov 2025._