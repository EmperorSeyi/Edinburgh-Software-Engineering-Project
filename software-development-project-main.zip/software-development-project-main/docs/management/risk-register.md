# Risk Register (V3- Prototype Risks)

This risk register reflects risks relevant to the implemented CLI-based MVP
prototype. Risks associated with the client’s full future product vision
(e.g. multi-user systems, legal compliance, commercial deployment) are
intentionally excluded as out of scope for this assessment.

# Risk Likelihood scale (1-5)

certain = 5

probable = 4

possible = 2.5

less likely = 2

rare = 1


# Risk Impact Scale

catastrophic = 5

severe = 4

moderate = 3

minor = 2

negligible = 1

**Project Management Risks**

| Risk | Likelihood | Impact | Mitigation | Owner | Severity (L x I) |
|------|-------------|---------|-------------|--------|--------|
| Scope creep | possible (2.5) | moderate (3) | well defined scope and out of scope | Oluseyi | 7 |
| Limited technical expertise | certain (5) | severe (4) | provide training or consult subject matter experts | Oluseyi | 7 |


## Out-of-Scope Risks (Considered but Not Tracked)

The following risk categories were considered during early planning but are
intentionally excluded from this register because they relate to the client’s
future, non-implemented product vision:

- Multi-user security and authentication risks
- Legal and regulatory compliance (e.g. GDPR)
- Commercial and financial viability
- Large-scale deployment and operational resilience

These risks are discussed at a conceptual level in the future architecture
documentation but were not tracked here, as they do not apply to the
implemented MVP prototype assessed in this course.

**Product Risks**

| Risk | Likelihood | Impact | Mitigation | Owner | Severity (Likelihood x Impact) |
|------|-------------|---------|-------------|--------|--------|
| Bugs in the code | probable (4) | moderate (3) | Unit tests | Gabriele | 12
| Lack of expertise | probable (4) | severe (4) | Contingency plans (easy-to-use alternatives to ideal option) | Gabriele | 16 
| Chosen technology unsuitable | possible (2.5) | severe (4) | Replace JSON with Mongo DB for portability  | Gabriele | 9 |
| Performance bottleneck | probable (4) | moderate (3) | scalable backend, stress test for concurrent users | Gabriele | 12 |
---
