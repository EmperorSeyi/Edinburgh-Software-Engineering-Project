# 🧭 Project Management Overview

This directory contains the **project management artefacts** used to plan, track, and
coordinate the *Scotch Broth* software development project.

These materials provide evidence of how the team managed **scope, risk, time, and
coordination** throughout the project lifecycle.

---

## 📂 Contents

- [`team-charter.md`](team-charter.md)  
  Team roles, responsibilities, and working agreements.

- [`risk-register.md`](risk-register.md)  
  Identified project risks, impact assessment, and mitigation strategies.

- [`progress-tracker.md`](progress-tracker.md)  
  Week-by-week progress tracking, task ownership, and workload allocation.

- [`project-timeline.png`](project-timeline.png)  
  Visual summary of the project phases from initial setup through final evaluation.

- [`minutes/`](minutes/)  
  Records of internal team meetings and client meetings, providing evidence of
  coordination and decision-making.

---

## 🔄 Project Management Approach

Project management followed a **lightweight Agile approach**, using **iterative
development cycles** aligned to milestone deliverables. This approach was appropriate
for a small academic development team working within fixed time and budget
constraints.

Management artefacts were used throughout the project to support:

- **Scope control** — ensuring the prototype remained focused and achievable  
- **Risk mitigation** — identifying and responding to emerging issues  
- **Team coordination** — maintaining shared understanding and accountability  

These documents demonstrate **active, ongoing project management**, rather than
serving as static or purely ceremonial artefacts.

---

## 🔗 Related Documentation

- Design documentation: [`docs/design/`](../design/)  
- Testing documentation: [`docs/testing/`](../testing/)  
- Final evaluation: [`docs/final-evaluation-multiple-authors/`](../final-evaluation-multiple-authors/)