# 🧭 Progress Tracker (Internal)

**Project:** Creative Transformation Support (CTS) – Scotch Broth  
**Course:** MSc DSTI – Software Development (2025–2026)  
**Team:** Olivia · Gabriele · Kangsu · Oluseyi · Cathy   

This document summarises **workload**, **meetings**, **time budget**, **task ownership**, and **final responsibilities** for the CTS project. It was updated regularly throughout development to support coordination and scope control.

## 📌 Contents

- [1. Project Phases](#1-project-phases)
- [2. Hours Budget](#2-hours-budget)
- [3. Task Breakdown](#3-task-breakdown)
- [4. Meeting Summary](#4-meeting-summary)
- [5. Weekly Meeting Schedule](#5-weekly-meeting-schedule)
- [6. Constraints](#6-constraints)
- [7. Weekly Work Plan — Who Does What](#7-weekly-work-plan--who-does-what)
- [8. Review & Quality Assurance Responsibilities](#8-review--quality-assurance-responsibilities)

---

# 1. Project Phases

| Phase | Focus | Leads |
|-------|--------|--------|
| **Setup** | Repo setup, charter, risk register | Olivia, Cathy, Oluseyi |
| **Requirements & Design** | Client meetings, requirements, ERD, wireframes, MVP slice | Oluseyi, Cathy, Kangsu, Olivia |
| **Implementation** | CLI, models, persistence, timeline logic, HTML export, refactoring | Olivia, Gabriele, Kangsu, Cathy |
| **Testing** | Test plan, functional + usability testing | Oluseyi, Olivia, Cathy |
| **Evaluation** | Final report, documentation, submission | Cathy, Gabriele, Olivia |

A visual summary of these phases is provided in docs/management/project-timeline.png.

---

# 2. Hours Budget

We count **all work + all meetings** toward the **~200h** team limit.  
Independent hours reflect confirmed contributions; late-stage Jan extension work is intentionally light and focused on polish, testing, and evaluation.

| Member | Independent | Meetings | **Total Hours** |
|--------|------------:|---------:|----------------:|
| **Olivia** | ~20.6 | **23.0** | **42.6** |
| **Cathy** | ~19.3 | **21.5** | **40.8** |
| **Oluseyi** | ~19.8 | **20.5** | **40.3** |
| **Gabriele** | ~22.8 | **22.5** | **45.3** |
| **Kangsu** | ~17.1 | **23.0** | **40.1** |

### Team total: **≈210 hours**

> Note:  
> - The additional ~10 hours arise from two short extension meetings and limited
>   asynchronous coordination during the extension period.
> - This reflects actual project effort rather than padded estimates.

---

# 3. Task Breakdown

*(“Actual” hours updated as the project continues.)*

| Task | Planned | Actual | Assigned To | Lead |
|------|--------:|-------:|--------------|------|
| Repo setup & structure | 3 | **4** | Olivia | Olivia |
| Team Charter | 2 | **2** | Cathy | Cathy |
| Project Plan + Timeline | 4 | **4** | All | Olivia |
| Risk Register | 2 | **2** | Oluseyi | Oluseyi |
| Requirements v1/v2 | 5 | **5** | O., K., O. | Oluseyi |
| User Stories | 3 | **4** | All | Cathy |
| Data Model | 5 | **5** | K., O., O., G. | Kangsu |
| Wireframes | 5 | **5** | C., O., G. | Cathy |
| Prototype Scope | 2 | **2** | G., C., O. | Gabriele |
| Environment Setup | 4 | **4** | G., O., K., O. | Gabriele |
| Prototype Skeleton | 8 | **4** | G., O., K. | Olivia |
| CLI Slice | — | **6** | Olivia | Olivia |
| MongoDB Persistence | 4 | **4** | K., G. | Kangsu |
| **Refactoring** | 4 | **4** | Gabriele | Gabriele |
| Timeline Logic | 10 | **10** | All | Olivia |
| HTML Export | 3 | **4.5** | C., O. | Cathy |
| Version Control | 2 | **2** | All | Gabriele |
| Test Plan & Functional Testing | 6 | **6** | O., O., C., K. | Oluseyi |
| Usability Testing | 3 | **3** | O., G., O. | Olivia |
| CI/CD Automation | 3 | **2** | O., G. | Olivia |
| Dev/User Guides | 5 | **5** | C., G. | Cathy |
| Final Report | 6 | **6** | All | Cathy |
| Submission Prep | 4 | **4** | All | Gabriele |

Task–to–individual attribution model:
Task “Actual” hours represent the total combined effort required to complete that task. For tasks with multiple assignees, hours are attributed disproportionately, with the Lead accounting for the majority of effort and other assignees contributing supporting, review, or partial implementation work. Individual workloads in the Hours Budget table are derived from each member’s confirmed contributions across tasks, rather than from equal division of task totals, ensuring accurate reflection of uneven effort while avoiding double-counting.

---

# 4. Meeting Summary

### Weekly Team Meetings  
- Weeks 5–9 → **1.5 h × 5 = 7.5 h**  
- Weeks 10–16 → **1 h × 7 = 7 h**  
- **Extension weeks (17–18)** → **1 h × 2 = 2 h**  
**Total per member → 16.5 h**

### Client Meetings  
- 23 Oct — Requirements (1h)  
- 29 Oct — M1 Feedback (1h)  
- 5 Nov — UI/Wireframes (1h)  
- 27 Nov — M2 Feedback (1h)

### Developer Syncs  
- 13 Nov — O (1.5h), K (1.5h), G (1h)  
- 26 Nov — G (1h), K (1h)

### UX Sync  
- 20 Nov — Olivia & Cathy (1h)

### Extension Review Meetings  
- **11 Jan 2026 — Final Testing & Consistency Review (1h)**  
- **18 Jan 2026 — Submission Readiness & Retrospective (1h)**

---

# 5. Meeting Schedule

Meetings are numbered sequentially to align directly with the recorded
meeting minutes in `docs/management/minutes/`.
Dates are included for clarity. Academic week numbers are provided for
context only.

---

## **Meeting 01 — Kick-Off & Setup**  
**Date:** Thu 16 Oct 2025  
**Academic week:** Week 5 (Fall Term)  
**Facilitator:** Olivia  

---

## **Meeting 02 — Planning & Prototype Ideation**  
**Date:** Sun 26 Oct 2025  
**Academic week:** Week 6 (Fall Term)  
**Facilitator:** Oluseyi  

---

## **Meeting 03 — Requirements & Design Review + Client Debrief**  
**Date:** Sun 2 Nov 2025  
**Academic week:** Week 7 (Fall Term)  
**Facilitator:** Cathy  

---

## **Meeting 04 — Early Design & Architecture**  
**Date:** Sat 8 Nov 2025  
**Academic week:** Week 8 (Fall Term)  
**Facilitator:** Gabriele  

---

## **Meeting 05 — Core Feature Development**  
**Date:** Sat 15 Nov 2025  
**Academic week:** Week 9 (Fall Term)  
**Facilitator:** Olivia  

---

## **Meeting 06 — Milestone 2 Delivery**  
**Date:** Sun 23 Nov 2025  
**Academic week:** Week 10 (Fall Term)  
**Facilitator:** Oluseyi  

---

## **Meeting 07 — Testing & Refinement**  
**Date:** Sun 30 Nov 2025  
**Academic week:** Week 11 (Fall Term)  
**Facilitator:** Kangsu  

---

## **Meeting 08 — Usability Testing & Documentation**  
**Date:** Sat 6 Dec 2025  
**Academic week:** Week 12 (Fall Term)  
**Facilitator:** Cathy  

---

## **Meeting 09 — Evaluation & Wrap-Up**  
**Date:** Sun 14 Dec 2025  
**Academic week:** Week 13 (Fall Term)  
**Facilitator:** Gabriele  

---

## **Meeting 10 — Final Submission Preparation**  
**Date:** Sun 4 Jan 2026  
**Academic week:** Winter Term  
**Facilitator:** Olivia  

---

## **Meeting 11 — Extension Review & Final Readiness**  
**Date:** Sun 11 Jan 2026  
**Academic week:** Winter Term (Extension)  
**Facilitator:** Olivia  

---

## **Meeting 12 — Submission & Reflection**  
**Date:** Sun 18 Jan 2026  
**Academic week:** Winter Term (Extension)  
**Facilitator:** Olivia  

---

# 6. Constraints

| Member | Constraint | Mitigation |
|--------|------------|------------|
| Olivia | Retreat 19–27 Nov | Front-load work |
| Gabriele | Leave 22 Dec–6 Jan | Complete refactoring + final tasks early |
| Others | — | — |

---

# 7. Weekly Work Plan — Who Does What

This section outlines the planned and actual focus of each team meeting and the
corresponding work carried out between meetings. Meeting numbers correspond to
the files in `docs/management/minutes/`.

---

## **Meeting 01 — Kick-off & Setup**  
**Date:** 16 Oct 2025  
**Focus:** Project setup, coordination, and initial planning

- **Olivia:** Create repository, define structure, coordinate kickoff  
- **Gabriele:** VM and Git setup  
- **Kangsu:** Review tools and development approach  
- **Cathy:** Draft Team Charter v1  
- **Oluseyi:** Create Risk Register v1  

---

## **Meeting 02 — Planning & Prototype Ideation**  
**Date:** 26 Oct 2025  
**Focus:** Early requirements and MVP direction

- **Olivia:** Contribute to Requirements v1; Milestone 1 preparation  
- **Gabriele:** Team support (repo / VM)  
- **Kangsu:** Requirements contributions  
- **Cathy:** Charter and requirements refinement  
- **Oluseyi:** Lead Requirements v1; update Risk Register  

---

## **Meeting 03 — Client Feedback & Design Alignment**  
**Date:** 2 Nov 2025  
**Focus:** Client debrief, data model, MVP slice

- **Olivia:** Data model support; MVP slice decision  
- **Gabriele:** Facilitate MVP scope decisions  
- **Kangsu:** Lead ERD and data model  
- **Cathy:** Lead wireframes  
- **Oluseyi:** Requirements and story refinement  

---

## **Meeting 04 — Architecture & Prototype Setup**  
**Date:** 8 Nov 2025  
**Focus:** Environment setup and architectural alignment

- **Olivia:** Prototype skeleton work  
- **Gabriele:** Lead environment setup and code scaffold  
- **Kangsu:** Support data model and environment  
- **Cathy:** Align UX with system structure  
- **Oluseyi:** Update Risk Register  

---

## **Meeting 05 — Core Feature Development**  
**Date:** 15 Nov 2025  
**Focus:** CLI slice and CRUD wiring

- **Olivia:** Implement CLI slice  
- **Gabriele:** Repository and CLI support  
- **Kangsu:** MongoDB CRUD (initial)  
- **Cathy:** CLI UX preparation  
- **Oluseyi:** Draft Test Plan outline  

---

## **Meeting 06 — Alpha Prototype & Milestone 2**  
**Date:** 23 Nov 2025  
**Focus:** Working MVP slice and scope confirmation

- **Olivia:** Complete CLI slice; present alpha prototype  
- **Gabriele:** Repository stability and support  
- **Kangsu:** Finalise CRUD for core features  
- **Cathy:** UX support for demo  
- **Oluseyi:** Test Plan v1  

---

## **Meeting 07 — Testing & Refinement**  
**Date:** 30 Nov 2025  
**Focus:** Bug fixes and timeline logic

- **Olivia:** Implement and refine timeline logic  
- **Gabriele:** Support debugging; begin refactoring  
- **Kangsu:** Persistence bug fixes  
- **Cathy:** Start Developer and User Guides  
- **Oluseyi:** Coordinate test execution  

---

## **Meeting 08 — Usability Testing & Documentation**  
**Date:** 6 Dec 2025  
**Focus:** Usability testing, HTML export, documentation

- **Olivia:** Run usability tests; implement quick fixes  
- **Gabriele:** Support usability setup  
- **Kangsu:** Validate data model and persistence stability  
- **Cathy:** Implement HTML export; draft guides  
- **Oluseyi:** Document usability findings  

---

## **Meeting 09 — Evaluation & Reporting**  
**Date:** 14 Dec 2025  
**Focus:** Evaluation and final report preparation

- **Olivia:** Reflection contributions  
- **Gabriele:** Technical review and refactoring wrap-up  
- **Kangsu:** Persistence and data validation  
- **Cathy:** Lead final report  
- **Oluseyi:** Risks, testing, and evaluation sections  

---

## **Meeting 10 — Final Submission Preparation**  
**Date:** 4 Jan 2026  
**Focus:** Repository freeze, packaging, and validation

- **Olivia:** Final repository checks; submission checklist  
- **Gabriele:** Lead repo freeze and packaging  
- **Kangsu:** Final persistence documentation  
- **Cathy:** Proofread all documentation  
- **Oluseyi:** Final risk and testing checks  
- **All:** Execute and refine unit tests during the winter break to validate core domain logic and CLI behaviour  
- **Olivia:** Configure CI/CD pipeline for automated unit test execution (early January)  

---

## **Meeting 11 — Extension Review & Submission Readiness**  
**Date:** 11 Jan 2026  
**Focus:** Final testing, consistency checks, and readiness review

- Run full unit test suite (including tests developed and refined during the winter break)  
- Verify Developer Guide and User Guide against a clean setup  
- Resolve remaining environment-related usability issues  
- Close outstanding GitLab issues  
- Confirm submission readiness and individual Turnitin requirements  

## 8. Review & Quality Assurance Responsibilities

To ensure quality and cross-checking across all deliverables, review and testing responsibilities were agreed in team meetings and are summarised below. These roles focus on verification and clarity and do not imply primary authorship or additional workload accounting besides the Final Review before submission.

### 8.1 Reviewer Allocations (Written Deliverables)

| Area | Reviewer |
|------|----------|
| Design | Gabriele |
| Management + README | Kangsu |
| Software (Developer Guide, Coding Standards), User Guide, Final Report | Olivia |
| Testing | Cathy |
| UX | Oluseyi |

- Authors do **not** make unilateral changes without review alignment
- Escalation point for coordination issues: **Olivia**

### 8.2 Unit Testing Assignments

| Component | Test Author | Test Runner |
|----------|------------|-------------|
| CLI | Olivia | Gabriele |
| Timeline | Olivia | Kangsu |
| Models | Gabriele | Olivia |
| Persistence | Kangsu | Cathy |
| Presentation / Export | Cathy | Oluseyi |

- Unit tests are authored and executed by different team members where possible to ensure independent verification.
- Any issues identified during testing are logged as GitLab issues.
- Unit test results serve as the formal record of testing activity.

---
