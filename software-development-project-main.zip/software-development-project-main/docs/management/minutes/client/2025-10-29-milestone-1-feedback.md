# 🧭 Client Meeting – Milestone 1 Feedback  
**Date:** 29 October  
**Attendees:** All team members & Alistair  

Full notes available at: https://docs.google.com/document/d/1jD0pqkgLAH5-UDs3N7fNpBOXZd1XUYgqS71T13mZe0k/edit?tab=t.0 

---

## ⚡ TL;DR Summary  

### **Overall Feedback**
- Project direction is excellent — one of the best early projects he’s seen in years!  
- Currently at **B–C borderline**, mainly held back by missing explanations (“why” behind choices).  
- Documentation is strong but needs to better **support** the work, not **be** the work.  
- Focus on reasoning, conciseness, and organization — less duplication, more clarity.  

### **Key Priorities**
- **Explain decisions** clearly: why certain tools, features, and design choices were made.  
- **Improve structure**: consolidate repeated info, add links between pages, and make repo navigation intuitive.  
- **Add success criteria** and reasoning throughout: how will we know a task or feature is “done”?  
- **Prototype focus**: narrow scope to maximize quality. Clearly separate full product design vs prototype detail.  

### **Next Steps**
- Strengthen **requirements** and **risk methodology** (show scaling/ranking approach).  
- Add **glossary**, **user flow diagrams**, and **prototype walkthroughs**.  
- Clarify **technology rationale** (why Python, why this stack).  
- Update **issues**, **progress tracker**, and **repo structure** to show consistent reasoning and progress tracking.  

---

## 🧩 Detailed Notes  

### **Overarching Key Ideas**
- Explain *why* you’re doing things — justification is what’s missing.  
- Avoid repetition and unnecessary text; organize better as you go (not in one giant clean-up).  
- Documentation should **support** the project, not replace it.  
- “A lot of good things here — overall direction is great!”  
- Would be at **B–C level** if graded today; excellent start for Milestone 1.  
- *Quote:* “One of the best early ones I’ve seen in four years!” 🎉  

---

### **Progress Tracker**
- Ask: *Is this too much work?* Don’t overcommit.  
- Track **estimate vs actual** time — helps evaluate scope and pacing.  
- Add **success criteria** for each task — what does “done” look like?  
- Include rationale behind **time estimates**.  
- Avoid long, repetitive pages — streamline explanations.  
- Client (Alistair) should be able to see progress and reasoning easily.  

---

### **Risk Register**
- Explain *how* you’re ranking/scaling risks — e.g., numeric scale or qualitative labels.  
- Include a short section on **risk methodology** (probability × impact, etc.).  
- Note: *“If it’s certain, it’s not a risk.”* 😄  
- Olivia to send Oluseyi data protection tools for risk reference.  

---

### **Requirements**
- Avoid **compound** requirements (split into clear, testable statements).  
- For **performance requirements**, explain *where they came from*:  
  - Industry standards?  
  - Logical reasoning?  
  - Importance to users?  
- Always answer *why*.  
- Audience for requirements is your “client” — not a developer.  
  - Write as if Alistair were your real client: focus on **domain knowledge and business goals**, not technical jargon.  

---

### **Design**
- Be specific — one vague line can lead to five different interpretations.  
- Consider **role permissions** (e.g., who can delete shared stories?).  
- Add a **glossary** to standardize terminology and reduce repetition.  
- Good feedback on the “key takeaways” section — shows how insights shaped requirements.  
- Currently presentation is “a bit all over the place” — aim for clarity and flow.  
- Remove `_archive` folder — don’t keep old or unused content.  

---

### **Technology Overview**
- Choosing Python is fine — just **justify why**.  
  - What alternatives were considered?  
  - Why was Python best suited for the prototype?  
  - Would the final system also use Python?  
- Rename **VM Guide** → **Development Guide** to reflect practical use.  

---

### **Prototype Scope & User Flow**
- Add **user journey diagrams** and walkthroughs (e.g., “How to create a character”).  
- Include **user instructions** and test plans.  
- More detail on what happens step-by-step:  
  - What options appear?  
  - What happens on save/delete?  
- Keep going — idea is solid, now focus on **reasoning and consistency**.  

---

### **Repository & Documentation**
- Too much replicated info — consolidate and **link** instead of duplicating.  
- Ensure every element has **one canonical source**.  
- Use top-level **README** to direct navigation (“Start here” for client).  
- Remember: This isn’t a personal workspace; it’s a **shared repo with your client**.  
- Project overview should orient new readers within ~2 hours.  
- Assume a **competent developer** (not a professor) is reviewing your repo.  

---

### **Design Focus: Full Product vs Prototype**
- Deliverables should include:  
  1. **High-level product design** (low detail, full vision).  
  2. **Detailed prototype design** (narrow scope, high quality).  
- Focus on producing **excellent quality** within constraints — not doing everything.  
- Strategic reduction of scope = higher quality marks.  

---

### **Issues & Task Management**
- Each issue should include:  
  - Description/context  
  - Tasks or actions (use checklists ✅)  
  - Success criteria  
  - Time estimate  
  - Updates in comments (record changes or blockers)  
- “Our progress tracker is basically a set of issues.”  
- Issues stem from **requirements** — they represent actionable tasks.  
Example photos are available in the full notes on the Google Doc: https://docs.google.com/document/d/1jD0pqkgLAH5-UDs3N7fNpBOXZd1XUYgqS71T13mZe0k/edit?tab=t.0

---

### **Documentation Philosophy**
- If a new person joined, could they understand what we’re doing in ~2 hours?  
- The **project overview** should summarize — not duplicate — everything.  
- In the UK, academic expectation isn’t just *doing* good work, but *explaining why*.  
- Alistair = “Dr. Grant,” not “Professor.” 😉  
- Key takeaway: *Being a good software developer isn’t just about coding — it’s about reasoning and communication.*  

---