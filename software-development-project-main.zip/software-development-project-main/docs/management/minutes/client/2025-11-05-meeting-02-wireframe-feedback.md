# 🧩 Client Meeting #2 – Wireframe / UI Review  
**Date:** 5 November 2025  
**Duration:** ~1 hour  
**Attendees:** All team members & Alistair  
**Location:** Microsoft Teams  

Full notes available at https://docs.google.com/document/d/1aUysKG35dWgtin_qn2nw0_uop1N3cr0QqQyAYfM_kWc/edit?tab=t.0

---

## ⚡ TL;DR Summary

- Alistair liked both wireframes and the narrowed **prototype scope** (characters + timeline).  
- Confirmed it’s okay to **prototype in one tech stack** (e.g., Python) while planning another for the full system.  
- Suggested using **MongoDB in a container** over JSON files for data management.  
- Recommended **usability testing** over performance testing.  
- Key UI notes: clarify map/timeline interactions, add “archive project” and “delete” logic, avoid using color alone for meaning.  
- Encouraged clear reasoning for design and dev choices (e.g., Spiral vs Waterfall).  

---

## 🗓 Agenda  

- Cathy: Wireframe demonstration (Full Project)  
- Gabriele: Prototype (MVP) wireframe demonstration  

---

## 💬 Questions for Alistair  

### From **Kangsu**
- Which slides (or webpages) are necessary?  
- What functional improvements can be made in those slides?  
  - **Alistair:** Ability to move the timeline and see changes reflected in other streams is the most valuable feature.  
- Relationship model: how do relationships change over time?  
  - **Alistair:** More complex relational model = more useful and engaging for users; it ties everything together.  
- Since we’re evaluated on choices like programming language and database, is it okay to just *plan* using some tools but *develop* with others?  
  - **Alistair:** Yes, that’s fine. It’s normal to prototype in one thing and later change tools. Focus on proving the concept.  
  - (Also, “I don’t like JavaScript,” he joked.)  
- Should we keep all code (front-end, back-end, etc.) in one repository?  
  - **Alistair:** No, you can split them across repos within your group.  
  - Just ensure a clear **README** guides the user (“Where do I start? How is it organized?”).  

---

### From **Olivia**
- Is this wireframe format acceptable for final submission?  
  - **Alistair:** Yes. It’s great — same style he uses with clients. Just make sure it’s included in the repo.  
  - You can export the source and upload that too if you want.  

**Additional Notes:**  
- Should discuss **user gamification** later — avatars, usernames, etc.  
- Add “Are you sure you want to delete?” confirmation pop-up.  
- Add an **item list/bag** (inventory) as part of character attributes.  
- Clicking on the timeline could update the map dynamically (think “Marauder’s Map”).  
- Color scheme idea: **royal purple**, **mocha**, and **beige**.  
  - Neutral-only palette might feel too dull for a creative tool.  
  - Aim for 5–6 tonal values and define hex codes for consistency.  

---

### From **Gabriele**
- Do you want a **working prototype**?  
  - **Alistair:** Yes — something that *functions*.  
    - Should allow creation of **simple characters** and **simple events** on a timeline.  
    - Queries will be challenging but are the most interesting part.  
    - Likes the narrowed focus.  

**Technical advice:**  
- Instead of writing JSON files, run a **MongoDB database** in a container (e.g., on the VM).  
  - Mongo makes data handling easier and more scalable.  
  - JSON fine for testing, but database shows better architecture in evaluation.  
- File-based systems don’t scale well.  
- Overall feedback:  
  - “Makes sense — no big warning flags.”  
  - “Good narrowed scope.”  
  - “Characters and timeline are exactly what I wanted.”  
  - “Focus on quality, not volume.”  

---

### From **Oluseyi**
- Which development model is best — Waterfall or Spiral?  
  - **Alistair:** Up to you — but justify it clearly.  
  - The assessment looks for reasoning, not a “right” answer.  
  - Waterfall isn’t ideal for this kind of project, but any model is fine if justified.  
  - “Weigh the pros and cons and show critical thinking.”  

---

### From **Cathy**
- What kinds of tests should we conduct for the prototype?  
  - **Alistair:** Focus on **usability testing**.  
    - Get someone (like a writer) to try using it — can they understand it?  
    - What feedback do they give?  
    - Does it make sense and help their process?  
  - Also test your **setup instructions**.  
  - This course isn’t about performance testing — it’s about **correctness and usability**.  

**Olivia’s note:** I can get writer friends to test this for us.  

---

## 🧠 Initial Notes / Feedback from Alistair  

### Wireframe – Full Project
- Login system: great (but not needed for prototype).  
- User flows: clear and strong.  
- Add **Archive Project** button (hide rather than delete).  
- For single-person projects, “Delete” can remain literal.  
- Enable **character location changes over time** — map updates at a selected timeline point.  
- Clarify **map interactions**:  
  - How to add or edit locations?  
  - What’s the entry point?  
  - Could add a simple tutorial on first use.  
- Clarify how to understand the **state of the world** at any given time.  
- Confirm if **timeline** is the project entry point.  
- Character **relationships** should evolve over time.  
- **Color use:** Don’t rely solely on color to convey meaning (accessibility issue).  

---

### Prototype (MVP)
- Good narrowed **scope**.  
- Use **MongoDB** container (rather than flat files).  
- JSON fine for initial structure but database shows better engineering.  
- File storage is weak at scale — database approach demonstrates stronger architecture.  
- **Queries and testing** will be the critical part of evaluation.  
- Maintain strong coding standards.  
- Remember: “It’s not about volume — it’s about quality.”  
- “A few good tests are better than a hundred bad ones.”  
- Overall: clear, feasible plan with no major red flags.  

---

### Testing Notes
- Testing **queries** (timeline + character interaction) will be the most important.  
- Timeline/query interaction is what will “make or break” the project.  
- Include a few strong, meaningful tests rather than many weak ones.  

---

## 💡 Other Thoughts & Ideas
- Add **user gamification** (avatars, usernames, icons).  
- Color palette: **royal purple**, **mocha**, **beige** (define hex codes).  
- UX improvements:
  - Hover over nodes to expand info.  
  - “Are you sure?” delete prompt.  
  - Add item inventory for characters.  
  - Clicking a timeline point updates the map view.  

---

### Overall Summary
Alistair is happy with progress — both the full project wireframe and the MVP design.  
He emphasized **clarity, usability, and justification of decisions** over volume or aesthetics.  
The focus should now shift to:
- Finalizing prototype structure and wireframes (V2).  
- Planning usability testing.  
- Maintaining clear documentation and reasoning in the repo.  