# 🧾 Client Meeting 1 Summary

**Date:** 23 October 2025  
**Time:** 9:00 AM GMT  
**Attendees:** CTS Client (Alistair Grant), Olivia Heale, Gabriele Dalla Torre, Kangsu Lee, Oluseyi Olaniyi, Cathy Xia  
**Platform:** Microsoft Teams  
**Full Notes Available at: ** https://docs.google.com/document/d/1WVN3jYOpQrn2CdHw1Y7RvkCqm84Vw9X4STnJ4vXp8Xs/edit?tab=t.0#heading=h.hhevn0icya3z

---

## TL;DR

- **Main goal:** Develop a **collaborative storytelling platform** to help creative teams (writers, game developers, artists) organize and synchronize story elements — characters, timelines, worldbuilding, and feedback.  
- **Prototype focus:**  
  - Integrate **timelines with characters** (who knows what, when, and how characters evolve).  
  - Demonstrate **concept feasibility**, not completeness.  
- **Scope:**  
  - Keep it **narrow and functional** — even a command-line prototype is fine.  
  - Show **core functionality** clearly and coherently.  
- **Design philosophy:**  
  - Avoid forcing one creative process or workflow.  
  - Prioritize usability that **supports creativity** rather than constraining it.  
- **Technical guidance:**  
  - Platform-agnostic (ideally browser-based or progressive web app).  
  - Simple or no license.  
  - Security can be basic — focus on functionality and data model clarity.  
- **Project management:**  
  - Maintain concise docs: **Project Plan**, **Risk Register**, **Issue Log**.  
  - Use **GitLab** for updates and tag **Alistair on Teams** for feedback.  
- **Assessment priorities:**  
  - Clarity and reasoning matter more than scale — “**the why is the biggest thing**.”  
  - Code should be well-structured, commented, and justified.  
- **Users & UX:**  
  - Support **writers, artists, and designers** collaborating on shared stories.  
  - Enable **multimedia content**, live feedback, and draft modes.  
  - Avoid “user-friendly” fluff — focus on clear, intuitive use that doesn’t block creativity.  
- **Risks to consider:**  
  - IP ownership and long-term security.  
  - Adoption resistance — make it easy and rewarding to use.  

---

## 🧩 1. Project Management

### Creative and Collaboration Challenges
- Different team members (writers, artists, etc.) approach story creation differently — hard to unify their workflows.  
- Teams (e.g., in games or collaborative fiction) struggle to track **shared worldbuilding**, **character histories**, and **timeline consistency**.  
- Current methods (e.g., post-it notes, loose documents) are messy and inconsistent.  

### Project Priorities & Success Criteria
- **Top priority:** integrating **timelines with character data** — tracking who knows what, when, and how characters evolve.  
- Prototype success = showing what’s possible, not doing everything.  
- Should **demonstrate potential**, feel **conceptually smooth** (“don’t make it clunky”), and **not force a single process** on users.  
- Should support **different creative roles** interacting fluidly — e.g., writer and artist working iteratively.  

### Communication & Feedback
- Use **GitHub/GitLab** as the main record.  
- Tag Alistair in **Teams** when feedback or input is needed.  

### Indicators of Success
- A functional prototype illustrating the concept of timeline–character integration.  
- Demonstrated understanding of requirements and thoughtful justification for design decisions.  
- Professional communication and clarity of reasoning.  

---

## ⚙️ 2. Technology Focus and Limitations

### Core Functionalities
- Produce a **prototype** demonstrating the main concepts — not a full commercial product.  
- Focus on **core functionality**, not completeness.  
- If it’s **command-line based**, that’s acceptable — it doesn’t need to be web-polished.  
- Show the **data model** clearly, especially how characters and timelines are handled.  

### Scope & Platform
- Should support **fiction creation** across multiple genres (games, stories, etc.).  
- Must **not** take on too much — keep the scope narrow and meaningful.  
- Ideally **accessible from any platform** (browser/PWA preferred).  
- **Progressive web app** approach encouraged if possible.  

### Licensing & Security
- License: **Simple or none** preferred.  
- Security: Prototype should show awareness of data privacy but doesn’t need full implementation (e.g., logins optional).  
- Data handling: Ensure data store design implies **privacy, isolation**, and **industry standards** for future scalability.  

### Quality & Assessment
- Alistair (as assessor) values:
  - Code quality and structure.  
  - Clear documentation and comments.  
  - Reasoned decision-making.  
- “The *why* is the biggest thing” — show clear links between requirements and design choices.  

---

## ⚖️ 3. Risk Management

### Expectations
- Team should maintain a **Risk Register**, **Risk Management Plan**, and **Issue Log**.  
- Keep all documents **concise and relevant** to the project’s scale (no excessive length).  

### Identified Risks
- **Intellectual property (IP)** ownership and creative rights are long-term risks.  
- **Security risks** are low for prototype but relevant for future development.  
- **User adoption** is a universal risk — creative teams may resist new tools.  
  - Consider **incentives or ease-of-use** features to encourage uptake.  

---

## 🧩 4. User Stories, Performance & UX

### Users & Workflows
- Main users: **writers, artists, designers, and collaborators**, all needing to view the same story data in a way that makes sense to their roles.  
- The system should allow **multimedia inputs** (text, visuals, sound) with **live updates** and potentially **draft modes** for work-in-progress.  

### Current Workflow Challenges
- Currently, each person creates their own separate story material — there’s no shared framework.  
- Goal: allow teams to **construct shared stories**, with traceable progression from **starting conditions → character development → end states**.  

### Example User Story
> “As a writer, I want to track a character’s development along a timeline so I can notice inconsistencies in their story arc.”  

### Usability Priorities
- Alistair dislikes the vague term “user-friendly.”  
- The design should **not interfere with creativity**, but **support it seamlessly**.  
- A good interface is one that **gets out of the way** and lets users focus on storytelling.  
- Clear instructions and intuitive workflows are more valuable than aesthetic polish.  
- “Just wants to be able to use it” — simple, functional usability wins.  

---

### 🧾 Grading Insights
- To achieve a strong grade:
  - Do it well, explain it clearly, and **show context**.  
  - Isolated “good explanations” don’t help unless tied to your project’s goals and design decisions.  
  - Demonstrate end-to-end understanding — from requirements → design → implementation → reflection.  