# Milestone 2 Feedback – Client Meeting  
**Date:** 27 November 2025  
**Time:** 10:00 AM GMT  
**Attendees:** Kangsu, Alistair (Client), Olivia, Cathy  

Link to full notes:
https://docs.google.com/document/d/1sSukg_A923dnVa4q8veP2ga1qVdcWH-FqYW-p86iirc/edit?tab=t.0#heading=h.bx9u4mwuq9wu

---

## 1. Documentation Structure & Organization

### Issues Identified
- Documentation feels **fragmented** and contains **repeated elements** across multiple files.  
- Hard to understand how documents relate (e.g., brainstorming → user stories → requirements → design).  
- Some sections appear duplicated (e.g., architecture overview in multiple places).  
- UX could be a subset of design.  
- Client notes and minutes might be combined or reorganized.

### Recommendations
- Create **clear traceability** between documents:
  - Brainstorming → Epic User Stories → Requirements → Prototype Scope  
- Consider **combining Epic User Stories + Requirements** into one unified document.  
- Clearly label documents as **Prototype** vs **Full Product** vision.  
- Move **Architecture** docs into the *Design* directory.  
- Add **links everywhere** (within and between docs) so Alistair doesn’t need to hunt for information.  
- Justify document separation (e.g., Team Charter vs Roles & Responsibilities) or link one within the other.
- The README is a bit **verbose** — reduce clutter and strengthen navigation.

### Reasoning Emphasis
- Expand the “**why**” in all documents:
  - Why we chose each technology  
  - Why we structured the prototype as we did  
  - Why requirements appear as they are  
  - Why we prioritized particular features  

> “The documentation is good — but the reasoning behind decisions needs to be more explicit.”

---

## 2. Requirements & Traceability

### Issues Identified
- Requirements, brainstorming, and deliverables feel like **three separate islands**.  
- Requirements contain **compound items** — must be broken down.  
- Hard to see “how we got from A → B → C.”

### Recommendations
- Improve **requirements traceability**:  
  - Source → Requirement → Design Element → Prototype Feature  
- Add brief explanations of **what we included**, **what we excluded**, and **why**.
- Include “**sourcing**”: show where requirements came from (client notes, user stories, brainstorming).

---

## 3. Architecture & Prototype Implementation

### Positives
- High-level architecture is solid.  
- MongoDB is a good choice.  
- Command-line approach is appropriate for the MVP.  
- No major concerns with technical direction.  

### Specific Suggestions
- Clarify difference between:
  - **Prototype Architecture**  
  - **Future (Full Product) Architecture**  

- Highlight the **timeline layer** explicitly:
  - Logic  
  - Flow  
  - Data structure decisions  

- Architecture documentation should appear under **Design** and be clearly referenced.

---

## 4. Coding & Branching Process

### Recommendations
- Use **feature branches** for all development work.  
- Merge only when a feature is complete and reviewed.  
- Reviewers should focus on **design and code**, not small formatting issues.  
- Always get at least one teammate to review before merging.

---

## 5. Testing & Usability

### User Testing
- OK to test with **external users** (1–2 people).  
- Preferably **creative professionals** or users representative of CTS.  
- Must include **consent** for use of responses in analysis.

### Testing Documentation
- Current plans are theoretical; need more “why.”  
- For each test:
  - What is being tested?  
  - Why is it important?  
  - How does it link back to requirements?  

- Include demographic considerations only if relevant.  
- Need to clearly describe the **testing scope** and the **feature-freeze date**.

---

## 6. Risk Register & Management Docs

### Issues
- Claims weekly updates, but no visible evidence.  
- Time log and progress tracker relation unclear.  
- Management folder needs clearer navigation.

### Recommendations
- Add timestamps or update notes in risk register.  
- Clarify purpose of each management document.  
- Ensure it’s easy for a new person to orient themselves quickly:
  - clean layout  
  - links  
  - short explanations of each doc  

---

## 7. General Feedback from Alistair

- **Overall quality is good** — nothing worrying.  
- But much of your **thinking is not documented**, making it difficult to understand decisions.  
- He can only mark what is **written down**, not what was said in meetings.  
- “**Visualize/document your reasoning**” for an A-grade submission.  
- Should not take him **two hours** to figure out how documents connect.  
- He will be mostly unavailable during holiday season; final guidance needed this week.

---

# Summary of Key Action Areas (for future edits)

### 🔧 Documentation Cleanup
- Reduce duplication  
- Merge or link related docs  
- Strengthen folder hierarchy  
- Add navigation + links

### 🔎 Reasoning & Traceability
- Provide “why” explanations for everything  
- Add source → requirement → design → prototype chain  
- Document decision justification clearly

### 🧩 Architecture
- Clarify prototype vs full-product  
- Highlight timeline logic  
- Move into Design folder

### 🧪 Testing
- Add 1–2 external creative testers  
- Include consent  
- Clarify test goals and rationale  
- Define feature-freeze date

### 📝 Management
- Make management docs easier to navigate  
- Add update logs  
- Unify/document time log vs progress tracker

---

Let me know when you want help rewriting any specific documents so they align with this feedback — I can help you systematically update:

- Requirements  
- Design Overview  
- Risk Register  
- Progress Tracker  
- Architecture docs  
- Testing  
- UX folder  
- README  

Just tell me where you want to start.