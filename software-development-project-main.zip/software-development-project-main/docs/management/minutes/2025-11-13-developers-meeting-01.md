# Developer Meeting Minutes  
**Date:** 13 November 2025  
**Attendees:** Olivia Heale, Gabriele Dalla Torre, Kangsu Lee  
**Type:** Developer Team Meeting (with HR Check-In Component)  
**Duration:** ~1 hour Gabriele, 1.5 hours Kangsu and Olivia

---

## 1. Summary of Concerns (HR Check-In)

### Kangsu’s Perspective
- Felt that **normal prototypes** should *look like* the final product.
- Current CLI-based prototype does not resemble the final UX.
- Proposed alternative plan:
  - Build a **simple website** by Saturday.
  - Website would visually resemble the final platform (“model car”).
  - Does not need full functionality—only critical parts.
- Interprets the assignment as:
  - Build a **small version of the whole system**, not a functional slice.

### Discussion & Clarification
- Olivia explained the team's perspective on the required academic approach:
  - Prototype represents **one working subsystem** (“engine”),  
    supported by design diagrams for the rest of the product (“car”).
  - Building a website is out of scope for Milestone 2 and not feasible.
- Highlighted that:
  - We need **one shared prototype**, not parallel versions.
  - HTML export will still provide a **visual output** for evaluation.
  - We focus on architecture + core data flow, not full UI.

### Additional Points Raised
- Concern about building components that may not connect later.
- Emphasis on needing a **skeleton first** before expanding.
- Agreement that alignment with course expectations is important.

### Takeaways
- Came to agreement on Kangsu building a full future architecture, but also contributing his portion (C)
to the prototype design as laid out by Gabriele. 
- Kangsu will clarify further with Alistair. 

---

## 2. Action Items (High Priority)

| Action | Owner | Notes |
|--------|--------|--------|
| **Follow up with Alistair** to clarify official interpretation of “prototype” requirements | **Kangsu** | To message Alistair via Teams for confirmation. |
| **Architecture API (full-system perspective)** — future-facing conceptual design | **Kangsu** | High-level API/endpoints for the “full car.” NOT a separate implementation or website. Will feed into final design. |
| **Backend tasks for MVP** — confirm participation | **Kangsu** | To proceed with Application Layer / CLI integration tasks per developer assignment. |
| Confirm MongoDB & Data Model tasks | Olivia (DB), Gabriele (Models) | As assigned in earlier technical breakdown. |
| Reconfirm shared understanding of M2 scope | All | Once Alistair clarifies. |

---

## 3. Developer Meeting Agenda Review (1-Hour Plan)

### 1. Quick Check-In (5 min)
- Each person shared:
  - Progress
  - Blockers
  - Support needs
- Purpose: ensure no team member feels disconnected.

---

### 2. Define the Milestone 2 Prototype (10 min)  
**Lead:** Olivia  
Clarified scope for M2:
- **CLI commands**  
- **MongoDB integration**  
- **Timeline logic (basic)**  
- **Simple HTML export**  
- Out-of-scope for M2:
  - Full UI or website
  - Rich interactivity
  - Multiple views beyond minimal HTML  

**Decision:** All agreed on a clear, unified definition of the M2 prototype.

---

### 3. Roles & Responsibilities Confirmation (5 min)  
**Lead:** Olivia  
Reviewed updated technical responsibilities:
- **Application Layer Lead:** Kangsu  
- **Data Models:** Gabriele  
- **Database / MongoDB:** Olivia  
- **UX & Export Layout:** Cathy  
- **Testing & Planning:** Oluseyi  

Clarified:
- “Frontend engineering” for M2 = **HTML export**, not website development.
- Application Layer is a **lead role**, not secondary.

**Decision:** All roles confirmed; no further revisions needed at this time.

---

## 4. Overall Outcomes

- Team reached shared understanding of M2 scope.
- Kangsu’s concerns were acknowledged and addressed.
- Assigned task (architecture API) gives him influence on full-system design **without splitting prototypes**.
- Backend responsibilities and prototype tasks reaffirmed as shared commitments.
- Awaiting final clarification from Alistair to fully resolve prototype interpretation.

---

## 5. Next Steps
- Olivia: Post meeting summary to GitLab.
- Kangsu:
    -  Await Alistair’s clarification.
    - Continue implementing assigned M2 tasks immediately.
    - Revisit architecture document and update once API concepts are drafted.

---

**Minutes prepared by:** Olivia Heale  
**Next developer sync:** Sunday meeting (weekly)