# Coding Standards

>  *This document outlines the coding standards that developers of the Scotch Broth team will follow, based on the best practices for scientific computing by Wilson et. al (paper can be found [here](https://journals.plos.org/plosbiology/article?id=10.1371/journal.pbio.1001745). 

**Reasoning:** This is key to align developers' different coding experience to a defined standard and allow to produce readable and reproducible code that can serve as building block for future developement. The content of this document serves as guidance to develop the main code in src/ and unit tests in tests/ .  *

---

## 1. Core coding practices

We adopt the “eight big ideas” from Wilson *et al.*:

1. **Write programs for people, not computers.**
   Keep cognitive load low: small, single-purpose functions; clear, distinctive names; consistent style and formatting.

2. **Let the computer do the work.**
   Automate repetition: script commands, keep reusable histories, and use a build/workflow tool (e.g., **Make** or **Snakemake**. **CI/CD** for testing)

3. **Make incremental changes.**
   Work in small steps with frequent feedback. Put everything under version control (**Git**). Keep all manually created artifacts in the repo.

4. **Don’t repeat yourself (or others).**
   Have a single authoritative source for each piece of data; modularize instead of copy-pasting; reuse robust libraries instead of reinventing the wheel. 

5. **Plan for mistakes.**
   Use assertions, typed interfaces, and error handling (defensive programming). Adopt a unit-testing framework. Turn every bug into a regression test.

6. **Optimise only after it works.**
   Make it correct first, then profile to find bottlenecks. Prefer the highest-level language that meets needs, dropping to lower-level only when profiling justifies it.

7. **Document design and purpose, not mechanics.**
   Explain **what** and **why** (interfaces, assumptions, rationale), not line-by-line restatements. Refactor confusing code rather than explaining around it.

8. **Collaborate.**
   Use pre-merge code reviews. Pair program to onboard newcomers or tackle tricky areas. Share decisions in issues/MRs.


---

## 2. GitLab repository management

**Branching & flow**

* Protect `main`. Develop on short-lived **feature branches** named `feat/<slug>`, `fix/<slug>`, `docs/<slug>`, etc.
* Open an **Issue** for each unit of work; link the branch and the eventual **Merge Request (MR)** to that issue.
* Use conventional commits where feasible (e.g., `feat: add timeline renderer`).

**Merge Requests (MRs)**

* MRs must be small, focused, and linked to exactly one issue.
* Include: purpose, scope, screenshots/logs if relevant, test coverage notes, and migration notes.
* Require at least one reviewer (two for risky changes). MRs should merge only when **CI is green** and review comments are resolved.

**Reviews**

* Review for correctness, readability, tests, performance risks, and security basics.

**Repository hygiene**

* Keep a clear top-level structure (e.g., `src/`, `tests/`, `docs/`, `scripts/`, `env/`, `containers/`).
* Include `README.md`, `CONTRIBUTING.md`, `LICENSE' to the course policy.

---

## 3. Virtual machine (VM) management

A designated **sysadmin** will:

* Maintain user access (SSH keys, sudo where appropriate) and ensure all team members can clone/pull the repo.
* Provide the shared software stack (e.g., **Conda/Mambaforge** environment) with locked dependencies; publish an `environment.yml` (and lock file) and `make`/`snakemake` targets for setup.
* Build and publish a **Docker** image (and, if needed, a `docker-compose.yml`) once the MVP is ready; ensure parity between local dev, CI, and VM.
* Support testing and profiling (e.g., pytest, coverage, timing/profilers) and ensure required resources are available.
* Manage logs/monitoring for the running prototype; rotate logs and track resource use for demos.
* Back up critical configuration and document restore steps; avoid storing secrets in the repo (use VM env vars or GitLab CI variables).

---
**NOTE:** more details can be found in the [developer guide](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/software/developer-guide.md?ref_type=heads)


## References

* Wilson, G., Aruliah, D.A., Brown, C.T., *et al.* (2014). **Best Practices for Scientific Computing.** *PLOS Biology* 12(1): e1001745. [https://doi.org/10.1371/journal.pbio.1001745](https://doi.org/10.1371/journal.pbio.1001745)



