# Technology Exploration

> *This document outlines **technology exploration and final choices made for the Scotch Broth prototype** (mvp), focused on character timeline development. All decisions prioritize prototype scope (see [prototype scope](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/design/mvp/prototype-architecture-overview.md?ref_type=heads)), team capabilities, scaling with final product plan (see [future architecture](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/design/mvp/prototype-architecture-overview.md?ref_type=heads)) and alignment with Wilson et al.'s best practices for software developent (see [coding standards](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/software/coding-standards.md?ref_type=heads)).

**Reasoning:** The purpose is to provide a rationale on the reasons that led to choosing some tools and to discard some others, providing a foundation for the final design of our prototype architecture that can be found [here](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/design/mvp/prototype-architecture-overview.md?ref_type=heads) *

---

## Technology Stack Summary

| Layer | Technology | Primary Rationale |
|-------|-----------|-------------------|
| Application | Typer | Type-safe CLI with auto-generated help |
| Domain Models | Pydantic v2 | Runtime validation with clear errors |
| Persistence | MongoDB + pymongo | Document DB with native Python support |
| Timeline Logic | Pure Python | Team skillset, testability |
| Presentation | Jinja2 + HTML | Static export, no server required |
| Containerization | Docker + docker-compose | Portable, reproducible deployment |

---

## Programming language for development

### Technology choice: Python 3.11

**Advantages:**
- Fits with teams's expertise
- High level popular language rich of built-in and external libraries
- High degree of compatibility with the majority of cutting-edge technologies
- Easy to customize and integrate between between different code layers
- Rich community and online documentation to solve c ommon and less common issues

**Reasoning:**
Python was chosen primarily because it fits with the developer team's internal expertise. Importantly,  it mmets the requirements of  the desired scope (simple prototype), it allows scaling up to the final product (web-based collaborative storytelling platform) by means of refactoring (i.e. by using frameworks such as Django) and it brings  extensive availability of predefined libraries to tackle different problems (i.e. no need to reinvent the wheel). While this choice has some shortcomings, such asy its dynamically typed memory intensive nature, for the scope of the prototype design performance is not a main concern.
Version 3.11 has been selected as a "safe" option to guarantee maximum compatibility across different library and technology choices (outlined in the sections below).

**Alternatives considered:** We did not consider an alternative programming language as there was no other consensus choice among the developer team than Python.

---

## Development Environment: Local Development

### Technology Choice: Miniforge (Conda) Environment

**Advantages of conda (Development Only):**
- Cross-platform Python version management
- Hardware agnostic (full c ompatibility)
- Team consistency (everyone uses same environment)
- Easy packages/dependency management for complex software stack
- Easy customizability, transferability (e.g. local laptop) and interfacing (e.g. Docker) via environment files (see [environment.yml](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/env/environment.yml?ref_type=heads))

**Reasoning:** 
Conda provides comfortable shared development experience for developers focusing on Python. It is one of the current best standards due to its ease of use and custom Python ecosystem creation. The choice of miniforge over anaconda/miniconda is due to the presence ofconda-forge as default channel, that allows to overcome the limitations of the recent conda-default channel licensing rules.

**Alternatives considered:** The only alternative we considered is the manual installation of Python and the required libraries in the VM (e.g. via dnf/pip) and to provide documented instructions to each developer on how to access them. The main limitation is that this approach forces developers to work inside the VM for the sake of reproducibility, preventing the possibility to have a local (laptop) setuo.

---

## Application Layer: Command Line Interface

### Technology choice Choice: Typer

**Advantages:**
- Auto-generated `--help` documentation (discoverable interface)
- Type-hinted parameters integrate with Pydantic models
-11 - Minimal dependencies, pure Python
- Clean UX for demos and testing

**Reasoning:**
Typer is a fully integrated UX compared to classic argparse, it integrates well with Pydantic models and generates automatically --help documenttion. This is in scope with the prototype goals as it allows for easy and quick implementation of a simple command line interface for demo runs.

**Alternatives Considered:**
**argparse:** Requires more coding and implementtion from scratch of all cli-related features. It does not add any advantage/user experience over a typer-based cli.

---

## Domain Layer: Data Validation

### Choice: Pydantic v2

**Advantages:**
- Runtime validation with clear error messages
- Native MongoDB ObjectId support via BSON
- Industry-standard tool aligning with Python best practices
- Excellent documentation and team familiarity

**Reasoning:**
Pydantic is one of the best standards for dataintegrity and types validation. This choice aligns with the team's skillset and, importantly, it integrates very well with the other layers of the prototype (e.g. typer, MongoDB).

**Alternatives Considered:**
Simple Python Dataclasses, which however lack embedded error handling features (more coding, out of scope). SQL-based models are also out of scope due to lack of team's skillset.

---

## Persistence Layer: Database

### Choice: MongoDB + pymongo (synchronous)

**Advantages:**
- Full integration with Pydantic data modesl, Typer and Docker containerization
- Native query capabilities (compared to simple JSON)
- Efficient Python integration via pymongo
- Simplicity as a progessional database
- Can be scaled up to more complex SQL oriented databases for the final product (refactoring rather than redesigning)

**Reasoning:**
Interaction with the client allowed to identify MongoDB, and pymongo, as the best database solution over simple JSON files to fit story files (charachters, events, changes). Pymongo integrates well with the other prototype layers and with Docker, allowing for the creation of a simple and portable containerized database that fits with the prototype scope. The main shortcoming of pymongo is its synchronous nature that may prevents simultaneous data access on the database from different users (e.g. collaborative storytelling).

**Alternatives Considered:**
JSON files require zero setup and are human-readable but lack No indexing capabilities, essential for database-like features managing story entities. Asynchronous MongoDB libraries such as motor were discarded as they add coding complexity and therefore are out of scope.

---

## Timeline Layer: Business Logic

### Choice: Pure Python Functions

**Why Pure Python:**
- Team has consistent Python experience (no dedicated software developers)
- Testability: Functions are easy to unit test (pytest)
- Aligns with Wilson et al.'s principle: "Use functions over classes"
- Simple state computation algorithm fits procedural style

**Reasoning:**
Python-based functions to implement a simple state computation core algorithm that integrates with the other four layers fits with the prototype scope. This algorithm can be asily scaled up to a more complex one handling additional story capabilities (e.g. mutable changes) by means of refactoring.

**Alternatives considered:** We did not consider any other alternative than simple Python-based core functions.

---

## Presentation Layer: Export Format

### Choice: Jinja2 + Static HTML

**Advantages:**
- Single self-contained file (portable demo artifact)
- No server required (works on EIDF VM and reviewer machines)
- Demonstrates "multi-modal export" requirement
- Can embed CSS for basic timeline visualization
- Jinja2 provides standard Python templating engine

**Reasoning:**
Jinja2 provides a fully integrating Python tenplating framework for creating simple static HTML visual output of the character development over a timeline, aligning with the prototype scope and teeam's skillset. This is the ideal choice to create a portable output artifact that can be viewed by the client and demonstrate the capabilities of the developed prototype. The HTML format aligns with the final product vision of a fully-integrated we-based storytelling platform.

**Alternatives Considered:**
A simple cli summary output is not sufficient as concrete product output to showcase the prototype. A simple text output, while in scope, is not visual nor attractive enough to convince the client to invest in our idea.

---

## Containerization: Deployment

### Choice: Docker + docker-compose

**Advantages:**
- **Portability:** Runs identically on dev machines, EIDF VM, and reviewers' systems
- **Reproducibility:** `docker-compose up` creates exact same environment every time
- **Isolation:** No conflicts with host Python versions or MongoDB installations
- **Professional practice:** Industry-standard deployment approach
- **Testing:** Easy to spin up clean database for integration tests
- **Documentation:** Dockerfile serves as explicit dependency specification
- **Integration:** Easy build of dev Python ecosystem via environment files

**Reasoning:** Containerization is the current industry gold standard for portability and reproducibility  of development environments, aligning with the client's requirement of a fully portable prototype tool. Docker has been selected according to the team's internal skillset and because it allows the orchestration of multiple instances (e.g. Python image and Mongo database) via Docker-compose, preventing conflicts with host machine configuration. Additionally, official Python and MongoDB Docker images are freely available, making it the optimal technology choice for our scope.

**Alternatives considered:** If time/budget constraints do not allow setup and testing of the containers orchestration architecture the B plas was to ship the prototype app via conda/pip end user configuration for the app and local Mongodb database in the VM, with instructions on how to access the VM and run the app.

---

