# Scotch-Broth Developer Guide

_Last updated: 10-11-2025 19:11 (GMT)_

>  *This document is meant to be the official guide for the developers of the Scorch Broth team. It contains guidelines on how to connect to and setup our VM, the Git repo and the software stack that will be used during the prototype development, including docker containerization. 

**Reasoning:** The purpose is to help to access and use the chosen developer tools and technologies and to align the developer team to common practices and standards, ensuring full compatibility and reproducibility of the development tasks. This guide explains how to install and use the tools outlined in [technology exploration](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/software/Technology-exploration.md?ref_type=heads).*

---

## TLDR

**What:** Developer setup for StoryForge character timeline prototype on EIDF VM  
**Who:** Scotch Broth team members  
**Stack:** Python 3.11 via Miniforge3 + MongoDB via Docker

**Prerequisites:**
- SAFE account with MFA enabled
- SSH key added to SAFE and GitLab

**Quick Start:**
```bash
# 1. SSH to VM (via gateway and lander)
ssh -J username-sdol@eidf-gateway.epcc.ed.ac.uk username-sdol@10.24.2.245
ssh username-sdol@10.24.5.62

# 2. Activate shared conda environment
source /home/eidf018/software/miniforge3/etc/profile.d/conda.sh
conda activate prototype_packages

# 3. Navigate to project and run Docker containers
cd ~/software-development-project/docker
docker compose up -d
docker exec -it prototype-app bash
python -m src.main --help
```

**Key Locations:**
- Shared Miniforge: `/home/eidf018/software/miniforge3`
- MongoDB data: `/opt/prototype-data/mongodb`
- Environment spec: `s/home/eidf018/software/environment.yml`

**Full details below **

---


## Table of Contents

- [1. Preliminary Steps](#1-preliminary-steps)
- [2. VDI (GUI) Access](#2-vdi-gui-access)
- [3. SSH (Terminal) Access to the VM](#3-ssh-terminal-access-to-the-vm)
- [4. VM Specs](#4-vm-specs)
- [5. SSH Key + Git VM Setup](#5-ssh-key--git-vm-setup)
- [6. Prototype Programming Language](#6-prototype-programming-language)
- [7. Software Stack](#7-software-stack)
- [8. Development Environment](#8-development-environment)
- [9. Docker Installation](#9-docker-installation)
- [10. Activation Quick Reference](#10-activation-quick-reference)
- [11. CLI Quickstart](#11-cli-quickstart)

---

> Replace placeholders like `username-sdol` with your actual username (e.g., `s2765669-sdol`). IPs/hosts are those observed during setup—adjust if your environment differs.

<a id="1-preliminary-steps"></a>
## 1. Preliminary Steps

<details>
<summary>Click to expand</summary>

1. Go to **SAFE**: <https://safe.epcc.ed.ac.uk/> and choose your `username-sdol@eidf` login account.  
2. **Set a public key** (you can add/update your SSH key there).  
3. **Enable multi-factor authentication (MFA)**.

---
</details>

<a id="2-vdi-gui-access"></a>
## 2. VDI (GUI) Access

<details>
<summary>Click to expand</summary>

Follow the official instructions: <https://docs.eidf.ac.uk/access/virtualmachines-vdi/>

---
</details>

<a id="3-ssh-terminal-access-to-the-vm"></a>
## 3. SSH (Terminal) Access to the VM

<details>
<summary>Click to expand</summary>

1. Follow security set-up given in [this website](https://docs.eidf.ac.uk/access/ssh/).

2. Jump through the gateway to the lander:

```bash
ssh -J username-sdol@eidf-gateway.epcc.ed.ac.uk username-sdol@10.24.2.245
```

*Note: direct ssh to the gateway did not automatically jump into the lander in our setup.*

3. From the lander, SSH into our VM:

```bash
ssh username-sdol@10.24.5.62
```

---
</details>

<a id="4-vm-specs"></a>

## 4. VM Specs

<details>
<summary>Click to expand</summary>

* **OS:** Ubuntu 24.04 LTS
* **CPU cores:** 4
* **RAM:** 8 GB
* **Total disk quota:** 77 GB

---
</details>

<a id="5-ssh-key--git-vm-setup"></a>

## 5. SSH Key + Git VM Setup

<details>
<summary>Click to expand</summary>

This section shows only the minimal steps to create your SSH key, add it to GitLab, test the connection, and clone our project  repository. No SSH agent or `~/.ssh/config` tweaks are required.

### 1) Create `~/.ssh` with correct permissions

```bash
mkdir -p ~/.ssh
chmod 700 ~/.ssh
```

### 2) Generate a new SSH key (Ed25519 recommended)

Use your email (university email is fine) for the comment:

```bash
ssh-keygen -t ed25519 -C "your_email@uni.ac.uk" -f ~/.ssh/id_ed25519
```

When prompted, you may set a passphrase (recommended) or leave it empty.

### 3) Copy your **public** key

```bash
cat ~/.ssh/id_ed25519.pub
```

Copy the entire single line (starts with `ssh-ed25519` … ends with your email/comment).

### 4) Add the key to GitLab (EIDF instance)

Go to preferences, open the SSH Keys page and paste the key:
`https://gitlab.eidf.ac.uk/-/profile/keys`
Give it a title (e.g., “VM ed25519”). Click **Add key**.

### 5) Test the connection to GitLab

```bash
ssh -T git@gitlab.eidf.ac.uk
```

* On first connection, type `yes` to trust the host fingerprint.
* A success message should look like: `Welcome to GitLab, @YOURNAME!`

If you see `Permission denied (publickey).`, ensure you pasted the correct key on the **same** GitLab instance (`gitlab.eidf.ac.uk`).

### 6) Clone the repository (SSH URL)

From the directory where you want the project:

```bash
git clone git@gitlab.eidf.ac.uk:epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project.git
```

### 7) Quick sanity checks (only if something fails)

```bash
# Permissions
chmod 700 ~/.ssh
chmod 600 ~/.ssh/id_ed25519
chmod 644 ~/.ssh/id_ed25519.pub ~/.ssh/known_hosts
```

---
</details>

<a id="6-prototype-programming-language"></a>

## 6. Prototype Programming Language

<details>
<summary>Click to expand</summary>

We will develop in **Python 3.11** (currently **3.11.14**). This aligns with the team’s skills and supports the client’s requested features. Python’s rich ecosystem and readability make it a strong fit for a fast, high-quality prototype.

Where helpful for presentation or export, we may generate outputs in other formats (e.g., **HTML**) using Python templating (e.g., **Jinja2**).

---
</details>

<a id="7-software-stack"></a>

## 7. Software Stack

<details>
<summary>Click to expand</summary>

We use **Miniforge3** (**25.3.0-3**) as our Conda distribution. This ensures **conda-forge** is the default channel, avoiding licensing restrictions associated with other proprietary Conda channels.

A minimal environment named **`prototype_packages`** includes **Python 3.11**, **pip**, and **pytest**.
The full, version-pinned specification is tracked in the repository at:

```
software-development-project/software/environment.yml
```

This file is the canonical record of our dependencies and a backup of the environment specification.

---
</details>

<a id="8-development-environment"></a>

## 8. Development Environment

<details>
<summary>Click to expand</summary>

Our **team VM** is the primary development environment.

* **Installation path:** Miniforge3 is installed at

```
/home/eidf018/software/miniforge3
```

* **Shared environment:** The `prototype_packages` environment is available via this Miniforge installation.
* **Permissions:** The Miniforge directory is owned by `root`; the `eidf018` group has r+s permissions so all team members can use the shared environment. One designated developer will be **in charge of managing** the Conda environment (installing/updating packages and updating the `environment.yml` file as needed).

```
sudo chgrp -R root:eidf018 /home/eidf018/software/miniforge3

sudo chmod -R g+rx  /home/eidf018/software/miniforge3

total 12K
drwxr-xr-x  3 root eidf018 4.0K Oct 26 15:37 .
drwxr-xr-x 19 root eidf018 4.0K Oct 26 15:01 miniforge3
drwxr-xr-t  5 root eidf018 4.0K Oct 26 13:22 ..
```

This arrangement ensures all developers work against **the exact same interpreter and libraries**, supporting reproducible scientific computing. Additionally, a centralised software stack improves security and reduces compatibility and user intervention risks.

Developers may use local IDEs (e.g., IntelliJ, PyCharm, VS Code). In that case, the up-to-date `environment.yml` allows recreating the same interpreter and stack locally. All testing and performance evaluation and optimization tasks will be performed using our VM hardware.

VM Instructions for creating SSH keys, cloning the repository, and activating the Conda environment are also available in:

```
/home/eidf018/software/README.md
```

---
</details>

<a id="9-docker-installation"></a>

## 9. Docker Installation

<details>
<summary>Click to expand</summary>

### Architecture Summary

![Docker architecture diagram](docker.png)

### Docker Installation

### Prerequisites

- Ubuntu 24.04 LTS (EIDF VM)
- Sudo privileges
- Internet connectivity

### Installation Steps

#### Step 1: Update System & Install Prerequisites

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg lsb-release
```

**Purpose:** Install required packages for adding Docker's official repository.

#### Step 2: Add Docker's Official GPG Key

```bash
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
  sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
```

**Purpose:** Add Docker's GPG key to verify package authenticity.

#### Step 3: Add Docker Repository

```bash
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
```

**Purpose:** Add Docker's official Ubuntu repository to APT sources.

#### Step 4: Install Docker Engine

```bash
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io \
  docker-buildx-plugin docker-compose-plugin
```

**Installed components: **

- Docker Engine (Community Edition):              `29.0.0`
- Docker Compose (Multi-container orchestration): `2.40.3`

#### Step 5: Configure User Permissions

```bash
sudo usermod -aG docker $USER
```

**Purpose:** Add current user to `docker` group to run Docker commands without `sudo`.

**Note:** need to Log out and back in for group membership to take effect.

#### Step 6: Verify Installation

```bash
docker --version
docker compose version
docker run hello-world
```

**Expected Output:**
```
Docker version 29.0.0, build 3d4129b
Docker Compose version v2.40.3
Hello from Docker!
```

---

## Multi-User Data Directory Setup

For development purposes, the persistent MongoDB is set local in the EIDF VM as a **shared team environment** where multiple developers can access the MongoDB data. Shared group permissions must be set accordingly.

#### Step 1: Create System-Level Data Directory

```bash
sudo mkdir -p /opt/prototype-data/mongodb
```

#### Step 2: Set Group Ownership

```bash
sudo chgrp eidf018 /opt/prototype-data/mongodb
```

**Team Group:** `eidf018` (all project members belong to this group)

**Verify team membership:**
```bash
groups  # Should show: eidf018 docker ...
```

#### Step 3: Configure Permissions with Setgid

```bash
sudo chmod 2775 /opt/prototype-data/mongodb
```

**Note:** `2`is for  Setgid bit files inheritance of  group ownership

**Verify:**
```bash
ls -ld /opt/prototype-data/mongodb
# Expected: drwxrwsr-x 2 dnsmasq eidf018 4096 ... 's' indicates setgid bit is set
```

### MongoDB Container User Mapping

**Note:** MongoDB's official Docker image runs as UID 999, which maps to the `dnsmasq` user on the host.

---

## Docker Configuration Architecture

### Repository Structure

```
├── docker/                      
   ├── docker-compose.yml        # Container orchestration (Python-3.11 image and MongoDB image)
   └── app-container/
       └── Dockerfile            # Python app image definition (custom setup)
```

**Dockerfile:** Defines the Python application container image.

**docker-compose.yml:** Orchestrates the 2 containers (Python app and MongoDB) and defines their relationships.

**.dockerignore:** Exclude unnecessary files from Docker build context (faster builds, smaller images, prevents path mismatchers).

---

### Networking: Two types of access

1. **Container-to-container:**
   ```python
   # From app container
   MongoClient("mongodb://mongodb:27017")  # Uses Docker network
   ```

2. **Host-to-container:**
   ```bash
   # From VM terminal
   mongosh mongodb://localhost:27017  # Uses port mapping
   ```

---
</details>

<a id="10-activation-quick-reference"></a>

## 10. Activation Quick Reference

<details>
<summary>Click to expand</summary>

To use the shared environment on the VM:

```bash
# Load Conda for the current shell
source /home/eidf018/software/miniforge3/etc/profile.d/conda.sh

# Activate the shared environment
conda activate prototype_packages
```

---
</details>

<a id="11-cli-quickstart"></a>`

## 11. Prototype Quickstart (VM development mode)

<details>
<summary>Click to expand</summary>

This section explains how to run the prototype app in development mode to demonstrates core concept:  
**character development over a timeline of events.**

**NOTE: full documentation can be found in the official [user-guide](https://gitlab.eidf.ac.uk/epcc-msc/software-development/onlineacademicyear2526/scotch-broth/software-development-project/-/blob/main/docs/user-guide.md?ref_type=heads)**

### 11.2 Running the CLI

Go to the docker/ directory of the repo:

```bash
# spin up the two docker containers
docker compose up -d

# check containers status
docker compose ps

# enter the app container in bash mode
docker exec -it prototype-app bash

# get the list of app commands
python -m src.main --help

# run the app
python -m serc.main run-timeline-demo

```

---

