# Software

This folder is meant to store a mirror backup of our software environment aand setup - this is needed because the VM is not backed up. Here we store an up-to-date version of our working conda environment, up-to-date environment.yml file and any additional bootstrap scripts we will develop to customize and maintain out software stack .

---
