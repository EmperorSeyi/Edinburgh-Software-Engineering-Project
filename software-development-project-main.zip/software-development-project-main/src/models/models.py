"""
Domain models for Scotch Broth prototype.
Defines Character, Event, and Change entities with MongoDB integration.
"""


from pydantic import BaseModel, Field
from typing import Literal, Any
from datetime import datetime


class Character(BaseModel):
    """
    Represents a story character with core attributes.    
    Attributes evolve and develop over time through Change records at Events.
    Note: for the prototype, only two events and one attribute change per event are implemented.

    
    Example:
        {
            "character_id": "char_abc12345",
            "story_id": "darkness-awakening",
            "name": "Ellhara Osyris",
            "bio": "The Queen of gloom, born by the moonlight shadows, daughter of the storm 
                    and the thunder, heir of the Elfsong magics”,
            "created_at": datetime(2024, 11, 14),
            "main_class": "Wizard",
            "age": 50,
            "trait": "Chaotic",
            "skill": "Ancestor Sword of Tears"
        }
    """
    # Gives uniqueness to character both inside and outside of the database
    character_id: str = Field(..., description="Unique character identifier (e.g., char_abc12345)")
    story_id: str = Field(..., description="Story/title identifier (user-provided tag)")
    name: str = Field(..., min_length=1, description="Character name")
    bio: str = Field(..., description="Character biography/backstory")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation timestamp")
    
    # Character attributes (can be modified via Changes)
    main_class: str = Field(..., description="Character class/role (e.g., Wizard, Warrior, etc.)")
    age: int = Field(..., ge=0, description="Character age in years")
    trait: str = Field(..., description="Primary character trait (e.g., Evil, Chaotic, Noble, etc.)")
    skill: str = Field(default="", description="Special skill or ability")
    

class Event(BaseModel):
    """
    Represents a point in the story timeline.
    Events are ordered by order_index and have a single  Changes associated.
    
    Example:
        {
            "event_id": "event_xyz789",
            "story_id": "darkness-awakening",
            "event_name": "Attack on the Towers of Sadness",
            "order_index": 6,
            "description": "Ghouls troops attempt to conquer the Towers of Sadness"
        }
    """
    # Gives uniqueness to an event both inside and outside of the database
    event_id: str = Field(..., description="Unique event identifier (e.g., event_xyz789)")
    story_id: str = Field(..., description="Story/title identifier (user-provided tag)")
    event_name: str = Field(..., min_length=1, description="Event name/title")
    order_index: int = Field(..., ge=0, description="Timeline position (0-based, lower = earlier)")
    description: str = Field(..., description="Detailed event description")
    

class Change(BaseModel):
    """
    Records a character single attribute modification at a specific event.
    Note: for the prototype, changes are immutable - never updated or deleted, only appended.
    This enables event-based character evolution over the timeline.
    
    Operations:
        - "set": Replace attribute value (e.g., age 30 → 35)
        - "increment": Add to numeric attribute (e.g., age + 5)
    
    Example:
        {
            "change_id": "change_def456",
            "story_id": "darkness-awakening",
            "character_id": "char_abc12345",
            "event_id": "event_xyz789",
            "attribute_name": "skill",
            "new_value": "Elfsong",
            "operation": "set"
        }
    """
    # Note: not needed for query purposes (query by character_id and event_id)
    change_id: str = Field(..., description="Unique change identifier (e.g., change_def456)")
    story_id: str = Field(..., description="Story/title identifier (user-provided tag)")
    character_id: str = Field(
        ...,
        description="Reference to Character by character_id (for prototype only one character)",
    )
    event_id: str = Field(
        ...,
        description="Reference to Event by event_id (for prototype only two events)",
    )   
    attribute_name: Literal["main_class", "age", "trait", "skill"] = Field(
        ..., 
        description="Which character attribute to modify"
    )
    
    # type Any needs be validated in cli.py to prevent wrong data type
    new_value: Any = Field(..., description="New value (type depends on attribute)")
    operation: Literal["set", "increment"] = Field(
        default="set",
        description="How to apply: 'set' (replace) or 'increment' (add/subtract for numbers)"
    )
    

