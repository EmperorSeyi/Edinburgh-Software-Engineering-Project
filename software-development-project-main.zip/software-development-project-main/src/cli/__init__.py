"""
CLI entrypoint for the Scotch Broth project.

Run with:
    python -m cli
or
    python -m cli run-timeline-demo
"""

from .commands import app


def main() -> None:
    """Main entrypoint for `python -m cli`."""
    app()


if __name__ == "__main__":
    main()