"""CLI command implementations – must be user friendly."""


from typing import Any, Literal, Tuple, List
import typer
from src.cli.utility import generate_character_id, generate_event_id, generate_change_id
from src.timeline.core import build_character_timeline
from src.persistence.database import MongoIo
from src.models.models import Character, Event, Change
from src.presentation.html_export import HTMLExporter
import os


app = typer.Typer(help="Story helper: manage simple character timelines.")


# ---------- Config ----------

VALID_ATTRIBUTES: Tuple[str, ...] = ("main_class", "age", "trait", "skill")
VALID_OPERATIONS: Tuple[str, ...] = ("set", "increment")
MAX_ORDER_INDEX: int = 10


# ---------- Input helpers (defensive) ----------


def prompt_non_empty_string(prompt_text: str) -> str:
    """Prompt the user for a non-empty string."""
    while True:
        value = typer.prompt(prompt_text).strip()
        if value:
            return value
        typer.echo("Please enter a non-empty value.")


def prompt_positive_int(prompt_text: str, max_value: int | None = None) -> int:
    """Prompt the user for a positive integer > 0, with optional upper bound."""
    while True:
        raw = typer.prompt(prompt_text).strip()
        try:
            value = int(raw)
        except ValueError:
            typer.echo("Please enter a whole number (integer).")
            continue

        if value <= 0:
            typer.echo("Please input a number bigger than 0.")
            continue

        if max_value is not None and value > max_value:
            typer.echo(f"Please input a number between 1 and {max_value}.")
            continue

        return value


def prompt_attribute() -> Literal["main_class", "age", "trait", "skill"]:
    """
    Prompt the user to choose one of the attributes that can change.

    Case-insensitive on input; returns canonical lowercase field name.
    """
    options_display = "/".join(VALID_ATTRIBUTES)
    while True:
        raw = prompt_non_empty_string(f"Attribute to change [{options_display}]")
        candidate = raw.casefold()

        for attr in VALID_ATTRIBUTES:
            if candidate == attr.casefold():
                return attr  # type: ignore[return-value]

        typer.echo(f"'{raw}' is not a valid attribute. Choose one of: {options_display}.")


def prompt_operation(attribute: str) -> Literal["set", "increment"]:
    """
    Prompt for the operation.

    - For 'age', allow 'set' or 'increment'.
    - For other attributes, always use 'set'.
    """
    if attribute == "age":
        options_display = "/".join(VALID_OPERATIONS)
        while True:
            raw = prompt_non_empty_string(f"Operation for age [{options_display}]")
            candidate = raw.casefold()
            if candidate in VALID_OPERATIONS:
                return candidate  # type: ignore[return-value]
            typer.echo("Please choose either 'set' or 'increment'.")
    else:
        typer.echo("Operation for non-age attributes is 'set' (replacing the old value).")
        return "set"


def prompt_new_value(attribute: str, operation: str, current_value: Any = None) -> Any:
    """
    Prompt for the new value depending on attribute & operation.

    - age + set       -> new absolute age > 0
    - age + increment -> positive increment > 0
    - others          -> new string value
    """
    if attribute == "age":
        if operation == "set":
            while True:
                new_age = prompt_positive_int("New age (years, > 0)")
                if current_value is not None and new_age == current_value:
                    typer.echo(f"Age is already {current_value}. Please enter a different value.")
                    continue
                return new_age
        else:  # increment
            return prompt_positive_int("How many years should age increase by?")
    else:
        while True:
            new_val = prompt_non_empty_string(f"New value for {attribute}")
            if current_value is not None and new_val.casefold() == str(current_value).casefold():
                typer.echo(f"{attribute} is already '{current_value}'. Please enter a different value.")
                continue
            return new_val


# ---------- Timeline helper (proto timeline layer) ----------


def print_timeline(
    character: Character,
    events: List[Event],
    changes: List[Change],
) -> None:
    """
    Print character timeline using timeline/core.py
    """
    typer.echo("\n\n=== Character Timeline ===\n")
    typer.echo(f"Name: {character.name}")
    typer.echo(f"Story ID: {character.story_id}")
    typer.echo(f"Bio: {character.bio}\n")

    # Build timeline using timeline layer
    timeline = build_character_timeline(character, events, changes)

    # Display each point
    for point_data in timeline:
        point_num = point_data["point"]
        state = point_data["state"]
        event = point_data["event"]

        if point_num == 0:
            typer.echo("Point 0 – Initial State")
        else:
            typer.echo(f"Point {point_num} – After Event {point_num}")
            typer.echo(f"  Event: {event.event_name} (order {event.order_index})")
            typer.echo(f"  Description: {event.description}")

        typer.echo(
            f"  Class: {state['main_class']}, "
            f"Age: {state['age']}, "
            f"Trait: {state['trait']}, "
            f"Skill: {state['skill']}\n"
        )


# ---------- CLI command ----------


@app.command("run-timeline-demo")
def run_timeline_demo() -> None:
    """
    Interactive demo:

    - Ask user for 1 Character
    - Ask for 2 Events (order_index 1–10)
    - Ask for 2 Changes (one per event)
    - Print a 3-point timeline showing character development
    """
    
    typer.echo("\nWelcome to the Scotch Broth character timeline demo!\n")

    # Character input
    typer.echo("First, let's create your character.\n")

    story_id = prompt_non_empty_string("Story ID")
    name = prompt_non_empty_string("Character name")
    bio = prompt_non_empty_string("Short character bio")
    main_class = prompt_non_empty_string("Main class (e.g., Wizard, Warrior)")
    age = prompt_positive_int("Age (years, > 0)")
    trait = prompt_non_empty_string("Key trait")
    skill = prompt_non_empty_string("Key skill")

    character_id = generate_character_id()
    character = Character(
        character_id=character_id,
        story_id=story_id,
        name=name,
        bio=bio,
        main_class=main_class,
        age=age,
        trait=trait,
        skill=skill,
    )

    events: List[Event] = []
    changes: List[Change] = []
    used_order_indices: set[int] = set()

    for i in range(1, 3):
        typer.echo(f"\nNow let's define Event {i}.")

        event_name = prompt_non_empty_string(f"Event {i} name")
        
        #  Validate unique order_index
        while True:
            order_index = prompt_positive_int(
                f"Event {i} order index (1–{MAX_ORDER_INDEX})",
                max_value=MAX_ORDER_INDEX,
            )
            if order_index in used_order_indices:
                typer.echo(f"Order index {order_index} is already used. Please choose a different number.")
                continue
            break
        
        used_order_indices.add(order_index)

        description = prompt_non_empty_string(f"Event {i} description")

        event_id = generate_event_id()
        event = Event(
            event_id=event_id,
            story_id=story_id,
            event_name=event_name,
            order_index=order_index,
            description=description,
        )
        events.append(event)

        typer.echo(f"\nNow define the Change caused by '{event.event_name}'.")
        attribute = prompt_attribute()
        operation = prompt_operation(attribute)
        current_value = getattr(character, attribute)
        new_value = prompt_new_value(attribute, operation, current_value)  

        change_id = generate_change_id()
        change = Change(
            change_id=change_id,
            story_id=story_id,
            character_id=character_id,
            event_id=event_id,
            attribute_name=attribute,
            new_value=new_value,
            operation=operation,
        )
        changes.append(change)

    # Save to database
    typer.echo("\nSaving to database...")
    db = MongoIo()
    db.insert_data(character)
    for event in events:
        db.insert_data(event)
    for change in changes:
        db.insert_data(change)
    typer.echo("✓ Saved successfully!\n")

    print_timeline(character, events, changes)


@app.command("list-data")
def list_data() -> None:
    """
    List all stories and characters in database.
    """
    db = MongoIo()

    typer.echo("\n=== Database Contents ===\n")

    # Get all characters
    all_characters = db.get_all_characters()

    if not all_characters:
        typer.echo("No data found in database.\n")
        return

    # Group by story
    stories_map = {}
    for char in all_characters:
        story = char.story_id
        if story not in stories_map:
            stories_map[story] = []
        stories_map[story].append(char)

    # Display
    for story_id, characters in stories_map.items():
        typer.echo(f"Story: {story_id} ({len(characters)} character(s))")
        for char in characters:
            typer.echo(f"  - {char.character_id}: {char.name}")
        typer.echo()


@app.command("export-html")
def export_html(
    character_id: str = typer.Option(None, "--character", "-c", help="Character ID to export"),
    export_all: bool = typer.Option(False, "--all", "-a", help="Export all characters"),
    output_dir: str = typer.Option("exports", "--output-dir", "-d", help="Output directory"),
) -> None:
    """
    Export character timeline(s) to HTML.

    Examples:
      - Export single character: --character char_abc123
      - Export all characters: --all

    Output filename: character_name.html (e.g., ellhara_osyris.html)
    """
    if not character_id and not export_all:
        typer.echo("Error: Please specify either --character or --all")
        return

    if character_id and export_all:
        typer.echo("Error: Cannot use --character and --all together")
        return

    db = MongoIo()
    exporter = HTMLExporter(db)

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    # Determine which characters to export
    if character_id:
        characters = [db.get_character(character_id)]
        if not characters[0]:
            typer.echo(f"Error: Character '{character_id}' not found")
            return
    else:
        characters = db.get_all_characters()
        if not characters:
            typer.echo("Error: No characters found in database")
            return

    typer.echo(f"\nExporting {len(characters)} character(s)...\n")

    # Export each character
    for character in characters:
        # Generate filename from character name
        safe_name = character.name.lower().replace(' ', '_')
        output_path = os.path.join(output_dir, f"{safe_name}.html")

        try:
            exporter.render_html(character.character_id, output_path)
            typer.echo(f"✓ {character.name} → {output_path}")
        except Exception as e:
            typer.echo(f"✗ Failed to export {character.name}: {e}")

    typer.echo(f"\n✓ Export complete! Files saved to '{output_dir}/'\n")


