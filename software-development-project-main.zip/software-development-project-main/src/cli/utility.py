# ID generator utility for mongodb data retrieval

import uuid


def generate_character_id() -> str:
    """Generate character unique ID"""
    return f"char_{uuid.uuid4().hex[:8]}"


def generate_event_id() -> str:
    """Generate event unique ID"""
    return f"event_{uuid.uuid4().hex[:8]}"


def generate_change_id() -> str:
    """Generate change unique ID"""
    return f"change_{uuid.uuid4().hex[:8]}"
