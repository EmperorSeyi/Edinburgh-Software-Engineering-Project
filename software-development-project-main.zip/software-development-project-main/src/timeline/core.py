"""
Pure, in-memory timeline logic for the Scotch Broth prototype.

This module is deliberately independent of:
- CLI (Typer)
- Persistence (MongoDB)
- Presentation (HTML)

It operates only on the project's domain models (Character, Event, Change),
and returns plain Python data structures (dicts/lists) suitable for CLI output
or HTML export.
"""

from __future__ import annotations

from typing import Any, Dict, List, TYPE_CHECKING

if TYPE_CHECKING:
    from src.models.models import Character, Event, Change


VALID_ATTRIBUTES = {"main_class", "age", "trait", "skill"}


def _get_attr(obj: Any, *names: str) -> Any:
    """
    Return the first attribute found on `obj` from `names`.

    This keeps the timeline layer tolerant to minor naming differences
    (e.g., `id` vs `character_id`, `id` vs `event_id`) across refactors/tests.
    """
    for name in names:
        if hasattr(obj, name):
            return getattr(obj, name)
    raise AttributeError(f"Missing expected attributes {names} on {obj!r}")


def character_to_state(character: Character) -> Dict[str, Any]:
    cid = _get_attr(character, "character_id", "id")
    return {
        "character_id": cid,      # <-- add
        "id": cid,                # <-- keep for backwards-compat
        "story_id": character.story_id,
        "name": character.name,
        "bio": character.bio,
        "created_at": character.created_at,
        "main_class": character.main_class,
        "age": character.age,
        "trait": character.trait,
        "skill": character.skill,
    }


def apply_change(character_state: Dict[str, Any], change: Change) -> Dict[str, Any]:
    """
    Apply a single Change to a character_state dict and return a NEW dict.

    Supported attributes: main_class, age, trait, skill
    Supported operations:
      - "set":       replace the value
      - "increment": add to current value (age only)

    Invalid combinations (unknown attribute, increment on non-age, etc.)
    raise ValueError.
    """
    attr = change.attribute_name
    op = change.operation

    if attr not in VALID_ATTRIBUTES:
        raise ValueError(f"Unknown attribute '{attr}' in Change.")

    new_state = dict(character_state)  # do not mutate caller state

    if attr == "age":
        current_age = int(new_state.get("age", 0))

        if op == "increment":
            new_age = current_age + int(change.new_value)
        elif op == "set":
            new_age = int(change.new_value)
        else:
            raise ValueError(f"Unsupported operation '{op}' for age.")

        if new_age <= 0:
            raise ValueError(f"Resulting age would be <= 0 (got {new_age}).")

        new_state["age"] = new_age
        return new_state

    # Non-age attributes only support "set"
    if op != "set":
        raise ValueError(
            f"Operation '{op}' not supported for attribute '{attr}'. Use 'set' for non-age attributes."
        )

    new_state[attr] = str(change.new_value)
    return new_state


def get_character_at_event(
    character: Character,
    changes: List[Change],
    target_event: Event,
    all_events: List[Event],
) -> Dict[str, Any]:
    """
    Reconstruct the character's state at (and including) `target_event`.

    Algorithm:
      1) start from initial character state
      2) consider all events up to target_event.order_index (inclusive)
      3) apply all changes belonging to those events, in event order

    If multiple changes affect the same attribute at the same event, the later
    change in sorted order wins (stable + deterministic).
    """
    state = character_to_state(character)
    target_index = target_event.order_index

    # Build lookup: event_id -> event (tolerate `id` vs `event_id`)
    events_by_id = {_get_attr(e, "id", "event_id"): e for e in all_events}

    allowed_event_ids = {
        _get_attr(e, "id", "event_id")
        for e in all_events
        if e.order_index <= target_index
    }

    relevant_changes = [ch for ch in changes if ch.event_id in allowed_event_ids]

    def sort_key(ch: Change) -> Any:
        ev = events_by_id.get(ch.event_id)
        return (ev.order_index if ev is not None else 10**9, ch.attribute_name)

    relevant_changes.sort(key=sort_key)

    for ch in relevant_changes:
        state = apply_change(state, ch)

    return state


def build_character_timeline(
    character: Character,
    events: List[Event],
    changes: List[Change],
) -> List[Dict[str, Any]]:
    """
    Build the full character timeline as a list of timeline points.

    Each point has:
      - point: int (0..N)
      - event: Event | None
      - state: dict

    Point 0 is always the initial state (event=None).
    Subsequent points are ordered by event.order_index.
    """
    sorted_events = sorted(events, key=lambda e: e.order_index)

    timeline: List[Dict[str, Any]] = [
        {"point": 0, "event": None, "state": character_to_state(character)}
    ]

    for idx, event in enumerate(sorted_events, start=1):
        timeline.append(
            {
                "point": idx,
                "event": event,
                "state": get_character_at_event(
                    character=character,
                    changes=changes,
                    target_event=event,
                    all_events=sorted_events,
                ),
            }
        )

    return timeline