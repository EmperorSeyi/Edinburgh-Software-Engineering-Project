""" MongoDB database layer (story storage layer)"""


import os
import pymongo
from src.models.models import Character, Event, Change


class MongoIo:
    """MongoDB persistence for StoryForge prototype"""


    def __init__(self, mongodb_uri=None):
        """
        Connect to MongoDB (Docker container or local).
        :param mongodb_uri: MongoDB connection string (defaults to Docker env)
        """
        uri = mongodb_uri or os.getenv('MONGODB_URI', 'mongodb://mongodb:27017/prototype')
        self.client = pymongo.MongoClient(uri)

        # Extract database name from URI
        db_name = uri.split('/')[-1] if '/' in uri else 'prototype'
        self.database = self.client[db_name]


    def insert_data(self, data_model):
        '''Insert a model (Character, Event, or Change) into database'''
        collection_name = data_model.__class__.__name__
        self.database[collection_name].insert_one(data_model.model_dump())


    def get_character(self, character_id) -> Character:
        '''
        Fetch character data by character_id (domain ID)
        '''
        collection = self.database['Character']
        query_dict = {'character_id': character_id}
        fetched_data_dict = collection.find_one(query_dict, {'_id': 0})
        if not fetched_data_dict:
            return None
        return Character(**fetched_data_dict)


    def get_event(self, event_id) -> Event:
        '''
        Fetch event data by event_id (domain ID)
        '''
        collection = self.database['Event']
        query_dict = {'event_id': event_id}
        fetched_data_dict = collection.find_one(query_dict, {'_id': 0})
        if not fetched_data_dict:
            return None
        return Event(**fetched_data_dict)


    def get_changes_by_story(self, story_id) -> list:
        '''
        Fetch all changes for a story (used by timeline layer)
        '''
        collection = self.database['Change']
        query_dict = {'story_id': story_id}
        cursor = collection.find(query_dict, {'_id': 0})
        return [Change(**doc) for doc in cursor]


    def get_events_by_story(self, story_id) -> list:
        '''Fetch all events for a story'''
        collection = self.database['Event']
        query_dict = {'story_id': story_id}
        cursor = collection.find(query_dict, {'_id': 0})
        return [Event(**doc) for doc in cursor]


    def get_all_characters(self) -> list:
        '''
        Fetch all characters from database
        '''
        cursor = self.database['Character'].find({}, {'_id': 0})
        return [Character(**doc) for doc in cursor]
