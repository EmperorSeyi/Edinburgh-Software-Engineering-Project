""" HTML generation functions with Jinja"""

"""
Scotch Broth Timeline Prototype
Functional Character Timeline HTML Export 
Connects MongoDB, fetches data and to be calculated and updated from models and core.py and renders HTML with flip card effect 
"""


from typing import List, Dict, Any
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
import os
import sys
from pathlib import Path
from src.models.models import Character, Event, Change
from src.timeline.core import build_character_timeline
from src.persistence.database import MongoIo


# Find the root folder for the project
project_root = Path(__file__).parent.parent.parent # can be replaced by parent[2] 
sys.path.insert(0, str(project_root))

# Adding helpers that don't raise of the attribute doesn't exist
def _get_attr(obj, *names):
    for name in names:
        if hasattr(obj, name):
            return getattr(obj, name)
    raise AttributeError(f"Missing expected attributes {names} on {obj!r}")

def _maybe_get_attr(obj, *names, default=None):
    for name in names:
        if hasattr(obj, name):
            return getattr(obj, name)
    return default

class HTMLExporter:
    """Export character timelines to HTML"""

    def __init__(self, db: MongoIo):
        """Initialize with MongoIo persistence layer"""
        self.db = db
        
        # Setup Jinja2 environment
        template_dir = os.path.join(os.path.dirname(__file__), 'templates')
        self.jinja_env = Environment(loader=FileSystemLoader(template_dir)) 


    def fetch_character(self, character_id: str) -> Character:
        """Fetch a character from persistence layer"""
        character = self.db.get_character(character_id)
        if not character:
            raise ValueError(f"Character '{character_id}' not found.")
        return character


    def fetch_events(self, story_id: str) -> List[Event]:
        """Fetch all events for a story""" 
        events =  self.db.get_events_by_story(story_id)
        if not events:
            raise ValueError(f"'{story_id}' not found.")
        return events

    
    def fetch_changes(self, story_id: str) -> List[Change]:
        """Fetch all changes for a story"""
        changes = self.db.get_changes_by_story(story_id)
        if not changes:
            raise ValueError(f"'{story_id}' not found.")
        return changes


    def calculate_timeline(self, character_id: str) -> List[Dict[str, Any]]:
        """Calculate timeline for a character"""
        character = self.fetch_character(character_id)
        story_id = character.story_id
        events = self.fetch_events(story_id)
        changes = self.fetch_changes(story_id)    
        
        timeline = build_character_timeline(character, events, changes)
        return timeline

    
    def render_html(self, character_id: str, output_path: str = None) -> str:
        """Render timeline as HTML with flip card effect"""
        # Fetch all raw data
        character = self.fetch_character(character_id)
        story_id = character.story_id
        
        # ONLY this character’s changes (filter story-scoped changes)
        all_changes = self.fetch_changes(story_id)
        char_id = _get_attr(character, "character_id", "id")

        changes = []
        for c in all_changes:
            c_char = _maybe_get_attr(c, "character_id", "char_id", default=None)

            # If the Change object has no character field (FakeDB),
            # treat it as already character-scoped
            if c_char is None or c_char == char_id:
                changes.append(c)

        # Derive event IDs from those changes
        event_ids = {_get_attr(c, "event_id", "id") for c in changes}

        # ONLY events referenced by this character
        all_events = self.fetch_events(story_id)
        events = [
            e for e in all_events
            if _get_attr(e, "event_id", "id") in event_ids
        ]
        
        # Calculate core timeline (states)
        core_timeline = build_character_timeline(character, events, changes)


        # Transform for Template:
        # Group changes by event_id for easy lookup and convert IDs to string for reliable matching
        changes_map = {}
        for c in changes:
            eid = str(_get_attr(c, "event_id", "id"))
            if eid not in changes_map:
                changes_map[eid] = []
            changes_map[eid].append(c)
            
        # Build view events list
        view_events = []
        for item in core_timeline:
            evt_obj = item['event']
            state = item['state']
            point_idx = item['point']
            
            view_item = {
                "order": point_idx,
                "is_initial": (point_idx == 0),
                "state": state,
                "changes": []
            }
            
            if evt_obj:
                view_item["name"] = evt_obj.event_name
                view_item["description"] = evt_obj.description
                
                # Find changes for this event
                eid = str(_get_attr(evt_obj, "event_id", "id"))
                related_changes = changes_map.get(eid, [])
                
                for rc in related_changes:
                    view_item["changes"].append({
                        "attribute": rc.attribute_name,
                        "new_value": rc.new_value,
                        "operation": rc.operation
                    })
            else:
                # Initial state
                view_item["name"] = "Initial Character State"
                view_item["description"] = character.bio
            
            view_events.append(view_item)

        # Prepare data for template
        template_data = {
            "story": {
                "title": character.story_id.replace('-', ' ').title(),
                "id": character.story_id
            },
            "character": {
                "id": character.character_id,
                "name": character.name,    
                "description": character.bio,
                "bio": character.bio,
                "story_id": character.story_id,
            },
            "timeline": {
                "events": view_events
            },
            "export_date": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
            "total_points": len(view_events),
        }
        
        # Render template
        template = self.jinja_env.get_template('timeline.html')
        html_content = template.render(**template_data)
        
        # Save to file if output path provided
        if output_path:
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            print(f"Timeline exported to: {output_path}")
        
        return html_content
    
    
