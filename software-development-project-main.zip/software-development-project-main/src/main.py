#!/usr/bin/env python3
"""
Scotch Broth prototype app - Main Entry Point

This is the entry point for the Scotch Broth prototype app.
How to run: python main.py [command] [options]

To get the full list of commands: 
    python main.py --help

Examples:
    python main.py run-timeline-demo
    python main.py list-data
    python main.py export-html --character
"""


from src.cli.commands import app


if __name__ == "__main__":
    app()


