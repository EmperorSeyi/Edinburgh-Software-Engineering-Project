# README

This file contains an overview of the Scotch Broth prototype structure and instructions on how to install and deploy it.

---

