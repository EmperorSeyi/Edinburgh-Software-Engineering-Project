""" Presentation layer unit tests """

"""
Unit tests for html_export.HTMLExporter

Scope:
- ONLY tests HTML rendering
- NO MongoDB
- NO timeline calculation logic
- Uses fake data + dependency injection

Use "pytest test_export.py" to run the test
"""

import sys
import types
from datetime import datetime

from pathlib import Path

# ---------------------------------------------------------------------
# Fake modules to align html_export imports
# ---------------------------------------------------------------------

# Fake src
fake_src = types.ModuleType("src")
sys.modules["src"] = fake_src

# Fake src.models.models
fake_models = types.ModuleType("src.models.models")
sys.modules["src.models"] = types.ModuleType("src.models")
sys.modules["src.models.models"] = fake_models

class Character:
    def __init__(self, character_id, name, bio, story_id):
        self.character_id = character_id
        self.name = name
        self.bio = bio
        self.story_id = story_id

class Event:
    def __init__(self, event_id, event_name, description, order):
        self.event_id = event_id
        self.event_name = event_name
        self.description = description
        self.order = order

class Change:
    def __init__(self, event_id, attribute_name, new_value, operation):
        self.event_id = event_id
        self.attribute_name = attribute_name
        self.new_value = new_value
        self.operation = operation

fake_models.Character = Character
fake_models.Event = Event
fake_models.Change = Change

# Fake src.timeline.core
fake_timeline_core = types.ModuleType("src.timeline.core")
sys.modules["src.timeline"] = types.ModuleType("src.timeline")
sys.modules["src.timeline.core"] = fake_timeline_core

def fake_build_character_timeline(character, events, changes):
    """
    Return a minimal, deterministic timeline structure
    matching what html_export expects.
    """
    return [
        {
            "point": 0,
            "event": None,
            "state": {
                "class": "Security Consultant",
                "age": 29,
                "trait": "Analytical",
                "skill": "Risk Assessment",
            },
        },
        {
            "point": 1,
            "event": events[0],
            "state": {
                "class": "Security Consultant",
                "age": 29,
                "trait": "Analytical",
                "skill": "Digital Forensics",
            },
        },
    ]

fake_timeline_core.build_character_timeline = fake_build_character_timeline

# Fake src.persistence.database
fake_persistence = types.ModuleType("src.persistence.database")
sys.modules["src.persistence"] = types.ModuleType("src.persistence")
sys.modules["src.persistence.database"] = fake_persistence

class MongoIo:
    pass

fake_persistence.MongoIo = MongoIo

# Add src/presentation to Python path (so html_export can be imported)
PROJECT_ROOT = Path(__file__).resolve().parents[1]
PRESENTATION_DIR = PROJECT_ROOT / "src" / "presentation"
sys.path.insert(0, str(PRESENTATION_DIR))

from html_export import HTMLExporter

# ---------------------------------------------------------------------
# Implement Fake DB 
# ---------------------------------------------------------------------

class FakeDB:
    """Minimal fake DB providing only what HTMLExporter needs."""

    def get_character(self, character_id):
        return Character(
            character_id=character_id,
            name="Sara",
            bio="A seasoned security consultant specializing in corporate threat assessment",
            story_id="security-chronicles",
        )

    # ---- REQUIRED by HTMLExporter ----
    def get_events_by_story(self, story_id):
        return [
            Event(
                event_id="event-1",
                event_name="Cyber breach investigation",
                description="Sara uncovers a sophisticated insider threat.",
                order=1,
            )
        ]

    def get_changes_by_story(self, story_id):
        return [
            Change(
                event_id="event-1",
                attribute_name="skill",
                new_value="Digital Forensics",
                operation="update",
            )
        ]

class EmptyDB(FakeDB):
    def get_events_by_story(self, story_id):
        return []

    def get_changes_by_story(self, story_id):
        return []


# ---------------------------------------------------------------------
# The Tests
# ---------------------------------------------------------------------

def test_render_html_basic_structure():
    exporter = HTMLExporter(db=FakeDB())
    html = exporter.render_html(character_id="sara-001")

    assert "<html" in html.lower()
    assert "timeline" in html.lower()
    assert "Sara" in html


def test_render_html_contains_initial_state():
    exporter = HTMLExporter(db=FakeDB())
    html = exporter.render_html("sara-001")

    assert "Initial Character State" in html
    assert "Risk Assessment" in html


def test_render_html_contains_event_and_change():
    exporter = HTMLExporter(db=FakeDB())
    html = exporter.render_html("sara-001")

    assert "Cyber breach investigation" in html
    assert "Digital Forensics" in html
    assert "skill" in html.lower()


def test_render_html_is_deterministic():
    exporter = HTMLExporter(db=FakeDB())

    html_1 = exporter.render_html("sara-001")
    html_2 = exporter.render_html("sara-001")

    assert html_1 == html_2


def test_render_html_with_output_file(tmp_path):
    exporter = HTMLExporter(db=FakeDB())

    output_file = tmp_path / "sara.html"
    html = exporter.render_html("sara-001", output_path=str(output_file))

    assert output_file.exists()
    assert html == output_file.read_text(encoding="utf-8")
