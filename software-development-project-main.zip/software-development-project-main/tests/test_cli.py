"""
CLI tests for the Scotch Broth Typer app.

Includes:
- smoke test for run-timeline-demo using monkeypatched prompt helpers
"""

from typer.testing import CliRunner
import pytest
from src.cli.commands import app
from unittest.mock import MagicMock

runner = CliRunner()


def _iterator(values):
    """
    Return a function that yields successive values when called.

    Used to replace prompt_* helpers so the CLI can run non-interactively.
    """
    it = iter(values)

    def _next(*args, **kwargs):
        return next(it)

    return _next


@pytest.fixture
def patched_prompts(monkeypatch):
    """
    Patch all interactive helpers used in run_timeline_demo so the command
    can run automatically in tests.
    """
    import src.cli.commands as commands

    # prompt_non_empty_string calls (in order):
    # 1. Story ID
    # 2. Character name
    # 3. Bio
    # 4. Main class
    # 5. Trait
    # 6. Skill
    # 7. Event 1 name
    # 8. Event 1 description
    # 9. **Operation for age (Event 1)** ← NEW!
    # 10. Event 2 name
    # 11. Event 2 description
    non_empty_values = [
        "story-xyz",             # Story ID
        "Aeris",                 # Character name
        "A wandering mage",      # Bio
        "Mage",                  # Main class
        "curious",               # Trait
        "alchemy",               # Skill
        "First Battle",          # Event 1 name
        "Faces a dragon",        # Event 1 description
        "increment",             # ← ADD THIS: Operation for age (Event 1)
        "Second Trial",          # Event 2 name
        "Learns ancient magic",  # Event 2 description
    ]
    monkeypatch.setattr(
        commands,
        "prompt_non_empty_string",
        _iterator(non_empty_values),
    )

    # prompt_positive_int calls:
    # 1. Age
    # 2. Event 1 order_index
    # 3. Event 2 order_index
    positive_int_values = [
        20,  # age
        1,   # event 1 order
        2,   # event 2 order
    ]
    monkeypatch.setattr(
        commands,
        "prompt_positive_int",
        _iterator(positive_int_values),
    )

    # prompt_attribute is called twice (once per event)
    attribute_values = [
        "age",    # change for event 1
        "trait",  # change for event 2
    ]
    monkeypatch.setattr(
        commands,
        "prompt_attribute",
        _iterator(attribute_values),
    )

    # NOTE: prompt_operation is NOT directly patched because when attribute=="age"
    # it internally calls prompt_non_empty_string (already patched above)

    # prompt_new_value called twice:
    # 1. new_value for age increment
    # 2. new_value for trait
    new_value_values = [
        5,           # increment age by 5
        "braver",    # new trait
    ]
    monkeypatch.setattr(
        commands,
        "prompt_new_value",
        _iterator(new_value_values),
    )

    return commands 


@pytest.fixture
def mock_database(monkeypatch):
    """
    Mock the MongoIo database class so tests don't need a real MongoDB connection.
    This allows to run a containerless unit test for the run_timeline_demo function. 
    """
    import src.cli.commands as commands
    
    # Create a mock MongoIo instance
    mock_db = MagicMock()
    
    # Mock the insert_data method to do nothing
    mock_db.insert_data.return_value = None
    
    monkeypatch.setattr(
        commands,
        "MongoIo",
        lambda: mock_db
    )
    
    return mock_db


def test_run_timeline_demo_smoke(patched_prompts, mock_database):
    """
    Smoke test for the run-timeline-demo command.

    Verifies:
    - Command runs without crashing.
    - Output includes character info, events, and state changes.
    """
    result = runner.invoke(app, ["run-timeline-demo"])

    assert result.exit_code == 0

    out = result.stdout

    # Intro + header
    assert "Welcome to the Scotch Broth character timeline demo!" in out
    assert "=== Character Timeline ===" in out

    # Character details
    assert "Name: Aeris" in out
    assert "Story ID: story-xyz" in out
    assert "Bio: A wandering mage" in out

    # Timeline points
    assert "Point 0 – Initial State" in out
    assert "Point 1 – After Event 1" in out
    assert "Point 2 – After Event 2" in out

    # Events
    assert "Event: First Battle (order 1)" in out
    assert "Event: Second Trial (order 2)" in out

    # Changes
    assert "Age: 20" in out  
    assert "Age: 25" in out  
    assert "Trait: curious" in out  
    assert "Trait: braver" in out
   
    # check that the mock object receives 5 calls (1 character, 2 events and 2 changes)
    assert mock_database.insert_data.call_count == 5

