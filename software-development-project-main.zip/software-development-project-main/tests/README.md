# Tests Overview

This folder contains unit tests for:
- timeline logic
- CLI
- models
- persistence
- presentation

To run all tests:
    pytest -q