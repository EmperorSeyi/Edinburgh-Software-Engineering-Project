"""
Unit tests for the domain models defined in src/models/models.py.

Focus:
- Character
- Event
- Change

Notes:
- These tests validate model structure, required fields, and basic instantiation.
"""

from pathlib import Path
import importlib.util

MODELS_PATH = Path(__file__).resolve().parents[1] / "src" / "models" / "models.py"
spec = importlib.util.spec_from_file_location("models", MODELS_PATH)
models = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(models)

Character = models.Character
Event = models.Event
Change = models.Change

from datetime import datetime

# ============================================================================
# CHARACTER TESTS
# ============================================================================

def test_create_valid_character():
    char = Character(
        character_id="char_123",
        story_id="my-story",
        name="John Doe",
        bio="The chosen one",
        main_class="Rogue",
        age=44,
        trait="Silent",
    )

    assert char.character_id == "char_123"
    assert char.story_id == "my-story"
    assert char.main_class == "Rogue"
    assert isinstance(char.created_at, datetime)


def test_character_model_dump_contains_expected_fields():
    char = Character(
        character_id="char_321",
        story_id="my-story",
        name="Venus",
        bio="Goddess of love",
        main_class="God",
        age=33,
        trait="Empathic",
    )

    d = char.model_dump()

    for field in [
        "character_id",
        "story_id",
        "name",
        "bio",
        "main_class",
        "age",
        "trait",
        "created_at",
    ]:
        assert field in d


# ============================================================================
# EVENT TESTS
# ============================================================================

def test_create_valid_event():
    event = Event(
        event_id="event_123",
        story_id="my-story",
        event_name="The beginning",
        order_index=5,
        description="The rise of the Force",
    )

    assert event.event_id == "event_123"
    assert event.story_id == "my-story"
    assert event.order_index == 5


def test_event_model_dump_contains_expected_fields():
    event = Event(
        event_id="event_321",
        story_id="my-story",
        event_name="The fall of Babylon",
        order_index=1,
        description="Conquer of Babylon",
    )

    d = event.model_dump()

    for field in [
        "event_id",
        "story_id",
        "event_name",
        "order_index",
        "description",
    ]:
        assert field in d

# ============================================================================
# CHANGE TESTS
# ============================================================================

def test_create_change_set_operation():
    change = Change(
        change_id="change_123",
        story_id="my-story",
        character_id="char_123",
        event_id="event_123",
        attribute_name="skill",
        new_value="Fireball",
    )

    assert change.operation == "set"
    assert change.attribute_name == "skill"


def test_create_change_increment_operation():
    change = Change(
        change_id="change_321",
        story_id="my-story",
        character_id="char_123",
        event_id="event_123",
        attribute_name="age",
        new_value=5,
        operation="increment",
    )

    assert change.operation == "increment"


def test_change_model_dump_contains_expected_fields():
    change = Change(
        change_id="change_222",
        story_id="my-story",
        character_id="char_123",
        event_id="event_123",
        attribute_name="trait",
        new_value="Brave",
    )

    d = change.model_dump()

    for field in [
        "change_id",
        "story_id",
        "character_id",
        "event_id",
        "attribute_name",
        "new_value",
        "operation",
    ]:
        assert field in d