"""
Persistence (MongoDB) integration tests.

These tests verify that the persistence layer can:
- Connect to a running MongoDB instance
- Insert documents
- Retrieve documents

IMPORTANT:
------------
These are **integration tests**, not pure unit tests.

They require a live MongoDB server to be running (e.g. locally via Docker
or a system service). In CI environments (such as GitLab CI), MongoDB is
not available by default.

To ensure the test suite is portable and deterministic across machines:
- The tests are automatically SKIPPED when MongoDB is not reachable
- This prevents false failures in CI and on teammates' machines

When MongoDB *is* available, the tests run normally and validate behaviour.
"""

import os
import pytest
from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError

URI = os.getenv("MONGODB_URI", "mongodb://127.0.0.1:27017")


def mongo_available() -> bool:
    try:
        MongoClient(URI, serverSelectionTimeoutMS=1000).admin.command("ping")
        return True
    except ServerSelectionTimeoutError:
        return False


pytestmark = pytest.mark.skipif(
    not mongo_available(),
    reason="MongoDB not reachable in this environment (skipping integration tests)",
)


def test_mongodb_connection():
    """Tests the MongoDB connection using the ping command."""
    client = MongoClient(URI)
    assert client.admin.command("ping")["ok"] == 1.0


def test_mongodb_insertion():
    """Tests the MongoDB insertion."""
    client = MongoClient(URI)
    assert client["test"]["test"].insert_one({"test": 1}).acknowledged


def test_mongodb_fetching():
    """Tests the MongoDB fetching data by find_one."""
    client = MongoClient(URI)
    assert len(client["test"]["test"].find_one({"test": 1}, {"_id": 0})) == 1