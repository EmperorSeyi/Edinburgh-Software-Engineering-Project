"""
Unit tests for the pure timeline logic in src/timeline/core.py.

Focus:
- character_to_state
- apply_change
- get_character_at_event
- build_character_timeline
"""
from __future__ import annotations

from typing import Any, List
from pathlib import Path
import importlib.util

import pytest

# ---------------------------------------------------------------------------
# Import models in a CI-safe way
# ---------------------------------------------------------------------------
_MODELS_PATH = Path(__file__).resolve().parents[1] / "src" / "models" / "models.py"
_models_spec = importlib.util.spec_from_file_location("models_module", _MODELS_PATH)
models = importlib.util.module_from_spec(_models_spec)
assert _models_spec and _models_spec.loader
_models_spec.loader.exec_module(models)

Character = models.Character
Event = models.Event
Change = models.Change

# ---------------------------------------------------------------------------
# Import timeline core in a CI-safe way
# ---------------------------------------------------------------------------
_CORE_PATH = Path(__file__).resolve().parents[1] / "src" / "timeline" / "core.py"
_core_spec = importlib.util.spec_from_file_location("timeline_core", _CORE_PATH)
core = importlib.util.module_from_spec(_core_spec)
assert _core_spec and _core_spec.loader
_core_spec.loader.exec_module(core)

character_to_state = core.character_to_state
apply_change = core.apply_change
get_character_at_event = core.get_character_at_event
build_character_timeline = core.build_character_timeline


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_character(**overrides: Any) -> Character:
    """Create a minimal Character instance for tests."""
    base = dict(
        character_id="char-1",
        story_id="story-1",
        name="Aeris",
        bio="Test hero",
        main_class="Mage",
        age=20,
        trait="curious",
        skill="alchemy",
        # created_at handled by default_factory in the model
    )
    base.update(overrides)
    return Character(**base)


def make_event(**overrides: Any) -> Event:
    """Create a minimal Event instance for tests."""
    base = dict(
        event_id="event-1",
        story_id="story-1",
        event_name="First Battle",
        order_index=1,
        description="Faces a dragon",
    )
    base.update(overrides)
    return Event(**base)


def make_change(**overrides: Any) -> Change:
    """Create a minimal Change instance for tests."""
    base = dict(
        change_id="change-1",
        story_id="story-1",
        character_id="char-1",
        event_id="event-1",
        attribute_name="age",
        new_value=1,
        operation="increment",
    )
    base.update(overrides)
    return Change(**base)


# ---------------------------------------------------------------------------
# character_to_state
# ---------------------------------------------------------------------------

def test_character_to_state_includes_key_fields():
    char = make_character(age=25, trait="brave", skill="swordplay")

    state = core.character_to_state(char)

    # Adjust these keys if your core uses character_id vs id in the state dict.
    # Given the models, character_id is the stable identifier.
    assert state["character_id"] == "char-1"
    assert state["story_id"] == "story-1"
    assert state["name"] == "Aeris"
    assert state["bio"] == "Test hero"
    assert state["main_class"] == "Mage"
    assert state["age"] == 25
    assert state["trait"] == "brave"
    assert state["skill"] == "swordplay"
    assert "created_at" in state


# ---------------------------------------------------------------------------
# apply_change
# ---------------------------------------------------------------------------

def test_apply_change_age_increment():
    state = {"age": 20}
    change = make_change(attribute_name="age", new_value=5, operation="increment")

    new_state = core.apply_change(state, change)

    assert state["age"] == 20
    assert new_state["age"] == 25


def test_apply_change_age_set():
    state = {"age": 20}
    change = make_change(attribute_name="age", new_value=30, operation="set")

    new_state = core.apply_change(state, change)

    assert new_state["age"] == 30


def test_apply_change_non_age_attribute_set():
    state = {"trait": "kind"}
    change = make_change(attribute_name="trait", new_value="brave", operation="set")

    new_state = core.apply_change(state, change)

    assert new_state["trait"] == "brave"


def test_apply_change_unknown_attribute_raises_value_error():
    state = {}

    class DummyChange:
        attribute_name = "unknown_attr"
        new_value = "x"
        operation = "set"

    with pytest.raises(ValueError):
        core.apply_change(state, DummyChange())


def test_apply_change_invalid_operation_for_non_age_raises():
    state = {"trait": "kind"}
    change = make_change(attribute_name="trait", new_value="brave", operation="increment")

    with pytest.raises(ValueError):
        core.apply_change(state, change)


def test_apply_change_resulting_non_positive_age_raises():
    state = {"age": 10}
    change = make_change(attribute_name="age", new_value=-1, operation="set")

    with pytest.raises(ValueError):
        core.apply_change(state, change)


# ---------------------------------------------------------------------------
# get_character_at_event
# ---------------------------------------------------------------------------

def test_get_character_at_event_applies_changes_up_to_target_event_only():
    char = make_character(age=20)

    e1 = make_event(event_id="event-1", order_index=1, event_name="Childhood")
    e2 = make_event(event_id="event-2", order_index=2, event_name="Training")
    e3 = make_event(event_id="event-3", order_index=3, event_name="Battle")

    c1 = make_change(change_id="change-1", event_id="event-1", attribute_name="age", new_value=5, operation="increment")
    c2 = make_change(change_id="change-2", event_id="event-2", attribute_name="age", new_value=10, operation="increment")
    c3 = make_change(change_id="change-3", event_id="event-3", attribute_name="trait", new_value="brave", operation="set")

    all_events = [e1, e2, e3]
    changes = [c1, c2, c3]

    state_at_e2 = core.get_character_at_event(
        character=char,
        changes=changes,
        target_event=e2,
        all_events=all_events,
    )

    assert state_at_e2["age"] == 35
    assert state_at_e2["trait"] == "curious"


def test_get_character_at_event_multiple_changes_same_attribute_last_wins():
    char = make_character(age=10)
    e1 = make_event(event_id="event-1", order_index=1)

    c1 = make_change(change_id="change-1", event_id="event-1", attribute_name="trait", new_value="shy", operation="set")
    c2 = make_change(change_id="change-2", event_id="event-1", attribute_name="trait", new_value="brave", operation="set")

    state_at_e1 = core.get_character_at_event(
        character=char,
        changes=[c1, c2],
        target_event=e1,
        all_events=[e1],
    )

    assert state_at_e1["trait"] == "brave"


# ---------------------------------------------------------------------------
# build_character_timeline
# ---------------------------------------------------------------------------

def test_build_character_timeline_no_events_returns_initial_only():
    char = make_character(age=20)
    events: List[Event] = []
    changes: List[Change] = []

    timeline = core.build_character_timeline(char, events, changes)

    assert len(timeline) == 1
    point0 = timeline[0]
    assert point0["point"] == 0
    assert point0["event"] is None
    assert point0["state"]["age"] == 20


def test_build_character_timeline_orders_events_and_states_progress():
    char = make_character(age=20)

    e1 = make_event(event_id="event-1", order_index=2, event_name="Second")
    e2 = make_event(event_id="event-2", order_index=1, event_name="First")

    c1 = make_change(change_id="change-1", event_id="event-2", attribute_name="age", new_value=5, operation="increment")
    c2 = make_change(change_id="change-2", event_id="event-1", attribute_name="trait", new_value="brave", operation="set")

    events = [e1, e2]  # deliberately unsorted
    changes = [c1, c2]

    timeline = core.build_character_timeline(char, events, changes)

    assert [p["point"] for p in timeline] == [0, 1, 2]
    assert timeline[1]["event"].event_name == "First"
    assert timeline[2]["event"].event_name == "Second"
    assert timeline[1]["state"]["age"] == 25
    assert timeline[1]["state"]["trait"] == "curious"
    assert timeline[2]["state"]["trait"] == "brave"